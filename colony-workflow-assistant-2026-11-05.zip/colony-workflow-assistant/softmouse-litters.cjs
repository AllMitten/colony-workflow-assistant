// Packaged helper: launch the reviewed app with npm start; legacy standalone runs are disabled.
if (require.main === module) throw new Error('Launch this package with npm start. Standalone legacy scripts are disabled.');
'use strict';
// Normal-form litter creation and weaning. Input adapters are separate from UI work.
const fs = require('node:fs');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { chromium } = require('playwright');
const { clickFill, setCalendarDate, dateISO, findRecords: findRecordsOnce } = require('./softmouse-one-male.cjs');
const { readRows, fieldValue, selectLabel } = require('./softmouse-batch.cjs');
const { matingRows } = require('./softmouse-profile-matings.cjs');
const value = fieldValue;
const hash = data => crypto.createHash('sha256').update(JSON.stringify(data)).digest('hex');
const dialogs=new WeakMap();
async function findRecords(context,kind,identifier,options) {
  // Retain the shared reader's all-state, pagination and completeness checks.
  // A timed-out UI read may be repeated; never repeat a failed save here.
  for(let attempt=0;attempt<3;attempt++) {
    try { return await findRecordsOnce(context,kind,identifier,options); }
    catch(error) {
      if(attempt===2 || !/Timeout|ERR_ABORTED/.test(error.message))throw error;
      console.log(`Read-only ${kind} lookup interrupted; restarting the complete lookup.`);
      const page=context.pages().find(p=>p.url().includes('/smdb/'));
      assert.ok(page);
      await page.goto(`https://www.softmouse.net/smdb/${kind}/list.do`,{waitUntil:'domcontentloaded'});
      await page.waitForLoadState('networkidle');
    }
  }
}
function allowedCageConfirmation(message,tags) {
  const match=/^The cage tag\(s\) (.+) is\/are already in use with an active cage in your facility, are you sure you want to use it again\?$/.exec(message);
  return !!match && match[1].split(/\s*,\s*/).every(tag=>tags.includes(tag));
}
function installDialogs(page,stage) {
  if(dialogs.has(page))return dialogs.get(page);
  const guard={tags:[],error:''};dialogs.set(page,guard);
  page.on('dialog',async d=>{
    try {
      const accept=d.type()==='confirm' && allowedCageConfirmation(d.message(),guard.tags);
      stage('browser_dialog',{message:d.message(),accepted:accept});
      if(accept)await d.accept();else {guard.error=d.message();await d.dismiss();}
    } catch(e){guard.error=e.message;}
  });return guard;
}
function validDate(date, label) {
  assert.match(date || '', /^\d{4}-\d{2}-\d{2}$/, `${label}: use YYYY-MM-DD`);
  assert.equal(new Date(`${date}T12:00:00Z`).toISOString().slice(0,10), date, `${label}: invalid date`);
}
function normalize(input) {
  assert.ok([1,2].includes(input.schemaVersion||1),'Unsupported input schema');
  assert.match(input.runId || '', /^[a-zA-Z0-9_-]{1,14}$/);
  assert.ok(input.owner && input.ownerId); validDate(input.asOf, 'asOf');
  assert.ok(Array.isArray(input.litters) && input.litters.length);
  const tags = new Set(), pupTags = new Set();
  const litters = input.litters.map((source,index) => {
    const l={...source,tag:source.tag || `${input.runId}-L${index+1}`};
    assert.ok(l.tag && l.tag.length <= 25 && !tags.has(l.tag), 'Litter tags must be unique and <=25 characters'); tags.add(l.tag);
    assert.ok(l.matingId || l.matingCageTag,'Identify the mating by ID or cage tag');
    for(const field of ['matingId','sireId','damId'])if(l[field])assert.match(String(l[field]),/^\d+$/);
    validDate(l.birthDate, 'birthDate'); validDate(l.weanDate, 'weanDate');
    assert.ok(l.birthDate <= input.asOf && l.weanDate >= l.birthDate, 'Invalid birth/wean chronology');
    const result = { ...l, comment: l.comment || '' };
    for(const field of ['matingId','sireId','damId'])if(l[field])result[field]=String(l[field]);
    if (l.weaning) {
      validDate(l.weaning.date, 'actual wean date');
      assert.ok(l.weaning.date >= l.birthDate && l.weaning.date <= input.asOf, 'Actual wean date must be between DOB and asOf');
      assert.ok(Array.isArray(l.weaning.pups) && l.weaning.pups.length > 0);
      if (l.weaning.count !== undefined) assert.equal(l.weaning.count, l.weaning.pups.length, 'Weanling count differs from individual assignments');
      result.weaning = { ...l.weaning, pups: l.weaning.pups.map(p => {
        assert.ok(['M','F'].includes(p.sex), 'Every weanling needs M/F');
        assert.ok(p.cage && p.cage.tag && p.cage.tag.length <= 25 && ['new','existing'].includes(p.cage.mode), 'Explicit new/existing destination required');
        if (p.tag) { assert.ok(p.tag.length <= 25 && !pupTags.has(p.tag), 'Duplicate/long pup tag'); pupTags.add(p.tag); }
        if(p.altId && p.cage.rackPosition)assert.equal(p.altId,p.cage.rackPosition,'Conflicting rack/Alt.ID');
        const fallback=input.schemaVersion===2?null:'';
        return { ...p, tag: p.tag ?? fallback, comment: p.comment ?? fallback, altId: p.altId ?? p.cage.rackPosition ?? fallback };
      }) };
      for(const sex of ['M','F'])assert.ok(result.weaning.pups.filter(p=>p.sex===sex).length<=25,'Add pups supports at most 25 per sex');
      destinationGroups(result,{pupIds:result.weaning.pups.map((_,i)=>String(i)),pupSids:result.weaning.pups.map((_,i)=>String(i))});
    }
    return result;
  });
  return { ...input, ownerId: String(input.ownerId), litters };
}
async function litterRows(page) {
  // A save's delayed redirect can interrupt navigation after networkidle.
  // Retry only this read-only normal page GET, never a form submission.
  for(let attempt=0;attempt<3;attempt++) {
    try {
      await page.goto('https://www.softmouse.net/smdb/litter/list.do',{waitUntil:'domcontentloaded'});
      await page.locator('#editOpenCloseImage').waitFor();
      await page.waitForLoadState('networkidle');break;
    } catch(error) {
      if(attempt===2 || !/ERR_ABORTED|Timeout/.test(error.message))throw error;
      console.log('Read-only litter navigation interrupted; checking the list again.');
      await page.waitForLoadState('domcontentloaded').catch(()=>{});
    }
  }
  if (!await page.locator('#filterClear').isVisible()) await page.locator('#editOpenCloseImage').click();
  await page.locator('#filterClear').click(); await page.locator('#litterStates + button').click();
  const all = page.locator('.ui-multiselect-menu:visible label').filter({ hasText:/^All$/ });
  if (!await all.locator('input').isChecked()) await all.click();
  assert.ok(await page.locator('#litterStates').evaluate(e=>Array.from(e.options).filter(o=>o.value!=='All').every(o=>o.selected)));
  const resultPromise=page.waitForResponse(r=>{
    const url=new URL(r.url());
    return url.pathname==='/litter/list.jqgrid'&&url.searchParams.get('saveFilter')==='true';
  });
  await page.locator('#filterApply').click();
  const response=await resultPromise;assert.ok(response.ok(),'Litter inventory request failed');
  const result=await response.json();assert.ok(Array.isArray(result.list),'Invalid litter inventory');
  // The filter queues its grid load after the click has returned. Waiting only
  // for networkidle can read the previous Active-only rows. Match fresh IDs.
  await page.waitForFunction(expected=>{
    const rows=Array.from(document.querySelectorAll('#litter_table tr.jqgrow'));
    return rows.length===expected.length&&expected.every(item=>{
      const row=rows.find(r=>r.id===String(item.id));
      return row&&row.querySelector('[aria-describedby="litter_table_litterstate"]')?.textContent.trim()===item.litterstate;
    });
  },result.list.map(r=>({id:r.id,litterstate:r.litterstate})));
  const rows = await readRows(page.locator('#litter_table tr.jqgrow'));
  const next = page.locator('#next_t_litter_table_toppager');
  while(await next.count() && !(await next.getAttribute('class')||'').includes('disabled')) {
    const old=(await readRows(page.locator('#litter_table tr.jqgrow'))).map(r=>r.id).join(',');await next.click();
    await page.waitForFunction(old=>Array.from(document.querySelectorAll('#litter_table tr.jqgrow')).map(r=>r.id).join(',')!==old,old);
    const more=await readRows(page.locator('#litter_table tr.jqgrow'));assert.ok(more.length);
    assert.ok(more.every(r=>!rows.some(old=>old.id===r.id)),'Duplicate litter result pages');rows.push(...more);
  }
  assert.equal(rows.length,Number(result.records),'Litter inventory is incomplete');
  return rows;
}
function matchLitter(rows, litter) {
  const found = rows.filter(r=>value(r.fields,'littertag') === litter.tag);
  assert.ok(found.length <= 1, `Duplicate litter tag ${litter.tag}`);
  if (found.length) {
    assert.equal(dateISO(value(found[0].fields,'dateofbirth')), litter.birthDate);
    assert.equal(value(found[0].fields,'fatherid'), litter.sireId);
    assert.equal(value(found[0].fields,'motherid'), litter.damId);
  }
  return found[0];
}
async function openLitter(page, id) {
  await page.goto(`https://www.softmouse.net/smdb/litter/edit.do?litterId=${id}&litterType=0`);
  await page.locator('#weanDatePicker').waitFor(); await page.waitForLoadState('networkidle');
}
async function createLitter(page, plan, litter, stage) {
  let rows = await litterRows(page), found = matchLitter(rows,litter);
  if (!found) {
    const matings = await matingRows(page); const mating = matings.find(r=>r.id===litter.matingId); assert.ok(mating,'Mating missing');
    assert.equal(value(mating.fields,'state'),'Active'); assert.equal(value(mating.fields,'maleId'),litter.sireId);
    assert.deepEqual(value(mating.fields,'femaleIds').match(/\d+/g),[litter.damId], 'Multi-dam litter needs a separately tested mother-selection branch');
    assert.ok(litter.birthDate >= dateISO(value(mating.fields,'setupdate')));
    await page.locator(`#jqg_matinglist_table_${litter.matingId}`).check();
    await page.getByRole('link',{name:'New Litter',exact:true}).click();
    await page.locator('#postnatalNumberOfUnknownMice').waitFor();
    assert.equal(await page.locator('#litterOwnerId').inputValue(),plan.ownerId);
    for (const selector of ['#postnatalNumberOfUnknownMice','#postnatalNumberOfMaleMice','#postnatalNumberOfFemaleMice']) {
      await page.locator(selector).click(); await page.locator(selector).selectOption('0');
    }
    await page.locator(`#jqg_MatingListTable_${litter.matingId}`).check();
    await setCalendarDate(page,page.locator('#birthDatePicker'),litter.birthDate,()=>page.locator('#birthDatePicker').click());
    await clickFill(page.locator('#litterTag'),litter.tag); await clickFill(page.locator('#litterComment'),litter.comment);
    stage('litter_create_attempt',{tag:litter.tag}); await page.locator('#editSaveNewLitter').click();
    const ok=page.locator('.ui-dialog:visible').getByRole('button',{name:'OK',exact:true});
    await ok.waitFor(); await ok.click();
    rows=await litterRows(page); found=matchLitter(rows,litter); assert.ok(found,'Litter save outcome not verified');
    assert.equal(value(found.fields,'pupmouseid'),'','Minimal birth record unexpectedly created pups');
  }
  if(value(found.fields,'litterstate')==='Weaned') {
    assert.ok(litter.weaning,'Already-weaned litter requires its actual weaning input');
    assert.equal(dateISO(value(found.fields,'weandate')),litter.weaning.date,'Actual wean date differs');
    stage('existing_weaned_litter_reconciled',{tag:litter.tag,id:found.id});return found;
  }
  if (dateISO(value(found.fields,'weandate')) !== litter.weanDate) {
    await openLitter(page,found.id);
    await setCalendarDate(page,page.locator('#weanDatePicker'),litter.weanDate,()=>page.locator('#weanDatePicker').click());
    stage('planned_wean_date_save_attempt',{tag:litter.tag,id:found.id});
    await page.locator('#editSave').click(); await page.waitForLoadState('networkidle');
    rows=await litterRows(page); found=matchLitter(rows,litter);
  }
  assert.equal(dateISO(value(found.fields,'weandate')),litter.weanDate);
  stage('litter_birth_verified',{tag:litter.tag,id:found.id}); return found;
}
async function ensurePups(page,litter,record,state,stage) {
  const weanHash=hash(litter.weaning);
  if(state.weanHash)assert.equal(state.weanHash,weanHash,'Weaning input changed after work started');
  else {state.weanHash=weanHash;stage('wean_input_locked',{tag:litter.tag});}
  await openLitter(page,record.id);
  let pups=await readRows(page.locator('#pupTable tr.jqgrow'));
  if(!pups.length) {
    assert.ok(!state.pupIds?.length,'Previously saved pups disappeared');
    await page.locator('#addPupsActionTrigger:visible').click();
    for(const [selector,sex] of [['#males','M'],['#females','F'],['#unknowns','U']]) {
      await page.locator(selector).click();await page.locator(selector).selectOption(String(litter.weaning.pups.filter(p=>p.sex===sex).length));
    }
    stage('pups_add_attempt',{tag:litter.tag,count:litter.weaning.pups.length});
    await page.locator('#addPupsActionApply').click(); await page.waitForLoadState('networkidle');
    await openLitter(page,record.id);pups=await readRows(page.locator('#pupTable tr.jqgrow'));
  }
  assert.equal(pups.length,litter.weaning.pups.length,'Existing pup count differs; do not add replacements or discard pups');
  if(!state.pupIds) {
    const available=[...pups].sort((a,b)=>Number(a.id)-Number(b.id));
    state.pupIds=litter.weaning.pups.map(p=>{
      const at=available.findIndex(r=>value(r.fields,'sex')===p.sex);assert.ok(at>=0,'Saved sex counts differ');
      return available.splice(at,1)[0].id;
    });stage('pup_id_mapping_saved',{tag:litter.tag,ids:state.pupIds});
  }
  assert.deepEqual(pups.map(p=>p.id).sort(),[...state.pupIds].sort());
  if(!state.originals)state.originals=state.pupIds.map(id=>{
    const fields=pups.find(r=>r.id===id).fields;
    return {tag:value(fields,'physicaltag'),comment:value(fields,'comment'),altId:value(fields,'mouseearmark')};
  });
  state.pupSids=state.pupIds.map(id=>value(pups.find(r=>r.id===id).fields,'sid'));
  stage('pup_sids_verified',{tag:litter.tag,sids:state.pupSids});
  for(let i=0;i<state.pupIds.length;i++) {
    const pup=pups.find(p=>p.id===state.pupIds[i]);assert.equal(value(pup.fields,'sex'),litter.weaning.pups[i].sex);
    assert.equal(dateISO(value(pup.fields,'dateofbirth')),litter.birthDate);
    assert.equal(value(pup.fields,'fatherid'),litter.sireId);assert.equal(value(pup.fields,'motherid'),litter.damId);
  }
  return pups;
}
async function editPups(page,litter,state,stage) {
  for(let i=0;i<state.pupIds.length;i++) {
    const id=state.pupIds[i],pup=litter.weaning.pups[i];
    await page.goto(`https://www.softmouse.net/smdb/mouse/edit.do?mouseId=${id}`);
    await page.locator('#physicalTag').waitFor();await page.waitForLoadState('networkidle');
    assert.equal(dateISO(await page.locator('#birthDatePicker').inputValue()),litter.birthDate);
    const currentTag=await page.locator('#physicalTag').inputValue();
    const tag=pup.tag ?? state.originals[i].tag, comment=pup.comment ?? state.originals[i].comment, altId=pup.altId ?? state.originals[i].altId;
    assert.ok(!currentTag || currentTag===tag,'Existing pup tag differs; do not overwrite another identity');
    const currentAlt=await page.locator('#mouseEarmarkId').evaluate(e=>e.options[e.selectedIndex]?.textContent.trim()||'');
    if(currentTag===tag && currentAlt===altId && await page.locator('#comment').inputValue()===comment)continue;
    await clickFill(page.locator('#physicalTag'),tag);
    await selectLabel(page.locator('#mouseEarmarkId'),altId);
    await clickFill(page.locator('#comment'),comment);
    stage('pup_details_save_attempt',{tag:litter.tag,id});
    await page.locator('#editSave').click();await page.waitForLoadState('networkidle');
    await page.goto(`https://www.softmouse.net/smdb/mouse/edit.do?mouseId=${id}`);await page.waitForLoadState('networkidle');
    assert.equal(await page.locator('#physicalTag').inputValue(),tag);
    assert.equal(await page.locator('#comment').inputValue(),comment);
  }
  stage('pup_details_verified',{tag:litter.tag});
}
function destinationGroups(litter,state) {
  const groups=new Map();
  litter.weaning.pups.forEach((p,i)=>{
    if(!groups.has(p.cage.tag))groups.set(p.cage.tag,{...p.cage,sids:[],ids:[],sex:p.sex,altId:p.altId});
    const group=groups.get(p.cage.tag);
    assert.equal(group.mode,p.cage.mode);assert.equal(group.sex,p.sex,'Mixed-sex weanling cages require an explicit breeding workflow');
    assert.equal(group.altId,p.altId,'One cage has conflicting rack positions');
    group.sids.push(state.pupSids[i]);group.ids.push(state.pupIds[i]);
    assert.ok(group.ids.length <= (group.capacity||5),'Requested cage capacity exceeded');
  });
  return [...groups.values()];
}
const rowSids=row=>(value(row.fields,'residentSids').match(/\d+/g)||[]).sort();
async function allocate(page,litter,state,destinations,stage) {
  const guard=installDialogs(page,stage);
  const rows=page.locator('#cageAssignmentTable tr.jqgrow');await rows.first().waitFor();
  const initial=await readRows(rows);
  assert.deepEqual(initial.flatMap(rowSids).sort(),[...state.pupSids].sort(),'Allocation differs from exact cohort');
  for(const box of await rows.locator('input[type="checkbox"]').all())await box.check();
  await page.locator('#ungroup').click();
  await page.waitForFunction(n=>document.querySelectorAll('#cageAssignmentTable tr.jqgrow').length===n,state.pupIds.length);
  for(const dest of destinations) {
    for(const box of await rows.locator('input[type="checkbox"]').all())await box.uncheck();
    const current=await readRows(rows);
    const selected=current.filter(r=>rowSids(r).some(s=>dest.sids.includes(s)));
    assert.deepEqual(selected.flatMap(rowSids).sort(),[...dest.sids].sort());
    for(const r of selected)await page.locator(`#jqg_cageAssignmentTable_${r.id}`).check();
    if(selected.length>1) {
      const count=current.length-selected.length+1;await page.locator('#group').click();
      await page.waitForFunction(n=>document.querySelectorAll('#cageAssignmentTable tr.jqgrow').length===n,count);
    }
  }
  assert.equal(await rows.count(),destinations.length);
  // Select all final destination rows before filling any fields: selection resets fields.
  for(const box of await rows.locator('input[type="checkbox"]').all())await box.check();
  for(const dest of destinations) {
    const current=await readRows(rows);
    const matches=current.filter(r=>JSON.stringify(rowSids(r))===JSON.stringify([...dest.sids].sort()));assert.equal(matches.length,1);
    const row=page.locator(`#cageAssignmentTable tr[id="${matches[0].id}"]`);
    const tagInput=row.locator('input[name="cageTag"]');
    if(dest.existingId) {
      await tagInput.click();await tagInput.fill('');await tagInput.pressSequentially(dest.tag,{delay:35});
      const option=page.locator('.ui-autocomplete:visible').getByText(`${dest.tag} (Cage SID: ${dest.existingSid})`,{exact:true});
      await option.waitFor();await option.click();
      assert.equal((await row.locator('span.sid').innerText()).trim(),dest.existingSid,'Existing cage selection was not bound');
    } else await clickFill(tagInput,dest.tag);
    const date=row.locator('input[name="entercageDate"]');
    if(dateISO(await date.inputValue())!==litter.weaning.date)
      await setCalendarDate(page,date,litter.weaning.date,()=>row.getByRole('img',{name:'...',exact:true}).click());
  }
  for(const dest of destinations) {
    const current=await readRows(rows);const match=current.find(r=>JSON.stringify(rowSids(r))===JSON.stringify([...dest.sids].sort()));
    const row=page.locator(`#cageAssignmentTable tr[id="${match.id}"]`);
    assert.equal(await row.locator('input[name="cageTag"]').inputValue(),dest.tag);
    assert.equal(dateISO(await row.locator('input[name="entercageDate"]').inputValue()),litter.weaning.date);
    assert.ok(await row.locator('input[type="checkbox"]').first().isChecked());
    if(dest.existingId)assert.equal((await row.locator('span.sid').innerText()).trim(),dest.existingSid);
  }
  stage('cage_move_save_attempt',{tag:litter.tag,destinations:destinations.map(d=>({tag:d.tag,ids:d.ids,existingId:d.existingId||null}))});
  guard.tags=destinations.filter(d=>d.existingId).map(d=>d.tag);
  try {
    await page.getByRole('button',{name:'Create / Update Cages',exact:true}).click();
    assert.ok(!guard.error,guard.error);
    await page.waitForURL(u=>u.pathname==='/smdb/cage/alloc.do'&&u.searchParams.get('dispatch')==='result');
    assert.ok(!guard.error,guard.error);
  }finally{guard.tags=[];}
  for(const dest of destinations)await page.getByText(dest.tag,{exact:true}).waitFor();
  await page.getByText('Done',{exact:true}).click();
}
async function resolveDestinations(page,litter,state,journal,stage) {
  const cages=await findRecords(page.context(),'cage','',{allowPages:true,details:true});
  const groups=destinationGroups(litter,state);
  for(const group of groups) {
    const matches=cages.filter(c=>value(c.fields,'cagetag')===group.tag);
    assert.ok(matches.length<=1,`Ambiguous cage tag ${group.tag}; use a unique destination`);
    if(matches.length) {
      const existing=matches[0];
      if(group.id)assert.equal(existing.id,String(group.id),'Destination cage ID differs');
      if(group.mode==='new')assert.equal(journal.cages[group.tag]?.id,existing.id,'New cage tag already exists outside this run');
      group.existingId=existing.id;group.existingSid=value(existing.fields,'cagesid');
      const current=(value(existing.fields,'residentmouseids').match(/\d+/g)||[]);
      const extra=group.ids.filter(id=>!current.includes(id));
      const limit=Number(/\d+/.exec(value(existing.fields,'cagetype'))?.[0]) || 5;
      assert.ok(current.length+extra.length <= Math.min(group.capacity||limit,limit),'Destination capacity would be exceeded');
      group.priorIds=current;
    }else assert.equal(group.mode,'new',`Existing cage ${group.tag} was not found`);
  }
  stage('destinations_resolved',{tag:litter.tag,destinations:groups.map(g=>({tag:g.tag,id:g.existingId||null}))});return groups;
}
async function moveSelected(page,ids) {
  // All-state read leaves the last page selected; walk backward while preserving
  // the application's normal cross-page checkbox selection.
  await findRecords(page.context(),'mouse','',{allowPages:true,details:true});
  const selected=new Set();
  while(true) {
    const rows=await readRows(page.locator('#mouseTable tr.jqgrow'));
    for(const row of rows)if(ids.includes(row.id)){await page.locator(`#jqg_mouseTable_${row.id}`).check();selected.add(row.id);}
    if(selected.size===ids.length)break;
    const previous=page.locator('#prev_t_mouseTable_toppager');
    assert.ok(!(await previous.getAttribute('class')||'').includes('disabled'),'Expected weanling not visible in complete list');
    const old=rows.map(r=>r.id).join(',');await previous.click();
    await page.waitForFunction(old=>Array.from(document.querySelectorAll('#mouseTable tr.jqgrow')).map(r=>r.id).join(',')!==old,old);
  }
  await page.getByRole('link',{name:'Move Animals',exact:true}).click();
  await page.waitForURL(u=>u.pathname==='/smdb/cage/alloc.do'&&u.searchParams.get('dispatch')==='setup');
}
async function verifyWeaning(page,plan,litter,state,journal,stage) {
  const mice=await findRecords(page.context(),'mouse','',{allowPages:true,details:true});
  const cages=await findRecords(page.context(),'cage','',{allowPages:true,details:true});
  const actual=matchLitter(await litterRows(page),litter);assert.ok(actual);
  assert.equal(value(actual.fields,'litterstate'),'Weaned');
  assert.equal(dateISO(value(actual.fields,'weandate')),litter.weaning.date);
  assert.deepEqual((value(actual.fields,'pupmouseid').match(/\d+/g)||[]).sort(),[...state.pupIds].sort());
  for(let i=0;i<state.pupIds.length;i++) {
    const mouse=mice.find(r=>r.id===state.pupIds[i]),pup=litter.weaning.pups[i];assert.ok(mouse);
    const original=state.originals?.[i]||{tag:'',comment:'',altId:''};
    for(const [col,expected] of [['sex',pup.sex],['physicaltag',pup.tag??original.tag],['comment',pup.comment??original.comment],['mouseearmark',pup.altId??original.altId],['fatherid',litter.sireId],['motherid',litter.damId],['cagetag',pup.cage.tag]])
      assert.equal(value(mouse.fields,col),expected,`${mouse.id} ${col} differs`);
    assert.equal(dateISO(value(mouse.fields,'dateofbirth')),litter.birthDate);
    assert.equal(dateISO(value(mouse.fields,'weandate')),litter.weaning.date);
    const mature=dateISO(value(mouse.fields,'maturedate'));
    assert.equal(value(mouse.fields,'mousestate'),mature && mature<=today(plan)?'Stock':'Weanling');
    const target=cages.filter(c=>value(c.fields,'cagetag')===pup.cage.tag);assert.equal(target.length,1);
    assert.equal(value(mouse.fields,'cageid'),target[0].id);
    assert.ok((value(target[0].fields,'residentmouseids').match(/\d+/g)||[]).includes(mouse.id));
    if(pup.cage.mode==='new'&&!journal.cages[pup.cage.tag])journal.cages[pup.cage.tag]={id:target[0].id,createdByRun:true};
  }
  state.weanedVerified=true;stage('weaning_verified',{tag:litter.tag,ids:state.pupIds});return {litter:actual,mice:mice.filter(r=>state.pupIds.includes(r.id)),cages:cages.filter(c=>litter.weaning.pups.some(p=>p.cage.tag===value(c.fields,'cagetag')))};
}
async function weanLitter(page,plan,litter,journal,stage) {
  assert.ok(litter.weaning,'Weaning assignments are missing');
  const state=journal.litters[litter.tag];let found=matchLitter(await litterRows(page),litter);assert.ok(found,'Create the litter first');
  state.litterId=found.id;if(state.weanHash)assert.equal(state.weanHash,hash(litter.weaning),'Weaning input changed');
  if(state.weanedVerified)return verifyWeaning(page,plan,litter,state,journal,stage);
  await ensurePups(page,litter,found,state,stage);
  const destinations=await resolveDestinations(page,litter,state,journal,stage);
  await editPups(page,litter,state,stage);
  found=matchLitter(await litterRows(page),litter);
  if(value(found.fields,'litterstate')!=='Weaned') {
    assert.equal(value(found.fields,'litterstate'),'Active');
    await openLitter(page,found.id);await page.locator('#weanPupsActionTrigger:visible').click();
    for(const id of state.pupIds)await page.locator(`#jqg_pupTable_${id}`).check();
    assert.equal(await page.locator('#pupTable tr.jqgrow input:checked').count(),state.pupIds.length);
    await setCalendarDate(page,page.locator('#weanActionDatePicker'),litter.weaning.date,()=>page.locator('#weanActionDatePicker').click());
    stage('wean_save_attempt',{tag:litter.tag});await page.locator('#weanPupsActionApply').click();await page.waitForLoadState('networkidle');
    found=matchLitter(await litterRows(page),litter);assert.equal(value(found.fields,'litterstate'),'Weaned');
  }
  assert.equal(dateISO(value(found.fields,'weandate')),litter.weaning.date,'Already-weaned record has a different actual date');
  const mice=await findRecords(page.context(),'mouse','',{allowPages:true,details:true});
  const pending=state.pupIds.filter((id,i)=>value(mice.find(r=>r.id===id).fields,'cagetag')!==litter.weaning.pups[i].cage.tag);
  if(pending.length) {
    assert.equal(pending.length,state.pupIds.length,'Partially moved cohort requires explicit reconciliation before another move');
    await moveSelected(page,pending);await allocate(page,litter,state,destinations,stage);
  }
  return verifyWeaning(page,plan,litter,state,journal,stage);
}
function today(plan) {return new Intl.DateTimeFormat('en-CA',{timeZone:plan.timeZone||'America/New_York'}).format(new Date());}
async function hydrateMatings(page,plan) {
  const rows=await matingRows(page);
  for(const litter of plan.litters) {
    const matches=rows.filter(r=>litter.matingId?r.id===litter.matingId:value(r.fields,'cagetag').split(/\s+/).includes(litter.matingCageTag));
    assert.equal(matches.length,1,'Mating reference missing or ambiguous');const row=matches[0];
    assert.equal(value(row.fields,'state'),'Active');
    const sire=value(row.fields,'maleId'),dams=value(row.fields,'femaleIds').match(/\d+/g)||[];
    assert.equal(dams.length,1,'This workflow requires one identified dam; multi-dam selection is not enabled');
    if(litter.sireId)assert.equal(litter.sireId,sire);if(litter.damId)assert.equal(litter.damId,dams[0]);
    litter.matingId=row.id;litter.sireId=sire;litter.damId=dams[0];litter.strain=value(row.fields,'mouseline');
  }
}
async function preflight(page,plan) {
  assert.ok(plan.asOf<=today(plan),'asOf must not be in the future');
  await page.getByRole('link',{name:'Animals',exact:true}).first().click();
  await page.getByRole('link',{name:'New Animals',exact:true}).click();await page.locator('#ownerId').waitFor();
  assert.equal(await page.locator('#ownerId').inputValue(),plan.ownerId);
  assert.ok((await page.locator('#ownerId').evaluate(e=>e.options[e.selectedIndex].textContent)).includes(plan.owner));
  assert.equal(await page.locator('#batchPreviewTable tr.jqgrow').count(),0,'Unfinished New Animals preview');
  const labels=await page.locator('#mouseEarmarkId option').allTextContents();
  for(const litter of plan.litters)for(const pup of litter.weaning?.pups||[])if(pup.altId!==null)
    assert.equal(labels.filter(t=>t.trim()===pup.altId).length,1,`Missing rack/Alt.ID option ${pup.altId}`);
}
async function snapshot(page) {
  return {mice:await findRecords(page.context(),'mouse','',{allowPages:true,details:true}),
    cages:await findRecords(page.context(),'cage','',{allowPages:true,details:true}),litters:await litterRows(page),matings:await matingRows(page)};
}
function auditSnapshot(before,after,plan,journal) {
  const ownPups=new Set(Object.values(journal.litters).flatMap(s=>s.pupIds||[]));
  const ownLitters=new Set(Object.values(journal.litters).map(s=>s.litterId).filter(Boolean));
  const columns={mice:['physicaltag','sex','dateofbirth','mousestate','mouseearmark','comment','cageid','fatherid','motherid','genotype','protocol'],
    cages:['cagetag','comment','cagestate','cageProtocol'],litters:['littertag','dateofbirth','weandate','fatherid','motherid','pupmouseid','litterstate','comment'],
    matings:['maleId','femaleIds','setupdate','state','mouseline','comment','cagetag']};
  for(const kind of Object.keys(columns))for(const old of before[kind]) {
    if(kind==='mice'&&ownPups.has(old.id)||kind==='litters'&&ownLitters.has(old.id))continue;
    const found=after[kind].find(r=>r.id===old.id);assert.ok(found,`Existing ${kind} record disappeared`);
    for(const col of columns[kind])assert.equal(value(found.fields,col),value(old.fields,col),`Unrelated ${kind} ${old.id} ${col} changed`);
  }
  const newPups=[...ownPups].filter(id=>!before.mice.some(r=>r.id===id));
  const newLitters=[...ownLitters].filter(id=>!before.litters.some(r=>r.id===id));
  const newCages=Object.values(journal.cages).filter(c=>!before.cages.some(r=>r.id===c.id));
  assert.equal(after.mice.length,before.mice.length+newPups.length,'Unexpected animal count');
  assert.equal(after.litters.length,before.litters.length+newLitters.length,'Unexpected litter count');
  assert.equal(after.cages.length,before.cages.length+newCages.length,'Unexpected cage count');
  assert.equal(after.matings.length,before.matings.length,'Unexpected mating count');
  for(const old of before.cages) {
    const expected=new Set(value(old.fields,'residentmouseids').match(/\d+/g)||[]);
    for(const litter of plan.litters)litter.weaning?.pups.forEach((p,i)=>{
      const id=journal.litters[litter.tag]?.pupIds?.[i];if(id&&p.cage.tag===value(old.fields,'cagetag'))expected.add(id);
    });
    const actual=after.cages.find(c=>c.id===old.id);
    assert.deepEqual((value(actual.fields,'residentmouseids').match(/\d+/g)||[]).sort(),[...expected].sort(),'Existing cage membership changed unexpectedly');
  }
  return {added:{mice:newPups.length,litters:newLitters.length,cages:newCages.length},totals:Object.fromEntries(Object.entries(after).map(([k,v])=>[k,v.length])),unrelatedRecordsUnchanged:true};
}
async function main() {
  const args=process.argv.slice(2), arg=k=>{const i=args.indexOf(k);return i<0?null:args[i+1];};
  const plan=normalize(JSON.parse(fs.readFileSync(arg('--input'),'utf8')));
  const action=arg('--action') || 'create'; assert.ok(['create','wean','all','verify'].includes(action));
  assert.ok(action==='verify' || args.includes('--save') && args.includes('--authorized-practice'));
  const path=`softmouse-litters-${plan.runId}-journal.json`;
  const journal=fs.existsSync(path)?JSON.parse(fs.readFileSync(path,'utf8')):{runId:plan.runId,actions:[],litters:{},cages:{}};
  const stage=(status,details={})=>{journal.actions.push({status,...details,at:new Date().toISOString()});fs.writeFileSync(path,JSON.stringify(journal,null,2));console.log(status,details.tag||'');};
  const browser=await chromium.connectOverCDP(arg('--cdp')||'http://127.0.0.1:9222');
  const pages=browser.contexts().flatMap(c=>c.pages()).filter(p=>p.url().includes('softmouse.net'));assert.equal(pages.length,1);
  const page=pages[0]; page.setDefaultTimeout(20000);
  installDialogs(page,stage);
  const lock=`${path}.lock`;fs.closeSync(fs.openSync(lock,'wx'));
  try {
    await hydrateMatings(page,plan);
    if(action!=='verify')await preflight(page,plan);
    if(!journal.baseline){journal.baseline=await snapshot(page);stage('baseline_saved');}
    const results=[];
    for(const litter of plan.litters) {
      const identityHash=hash({tag:litter.tag,matingId:litter.matingId,sireId:litter.sireId,damId:litter.damId,birthDate:litter.birthDate,weanDate:litter.weanDate});
      if(journal.litters[litter.tag])assert.equal(journal.litters[litter.tag].identityHash,identityHash,'Birth input changed under saved tag');
      else journal.litters[litter.tag]={identityHash};
      if(action==='create'||action==='all') {const created=await createLitter(page,plan,litter,stage);journal.litters[litter.tag].litterId=created.id;}
      if(action==='wean'||action==='all')results.push(await weanLitter(page,plan,litter,journal,stage));
      if(action==='verify')results.push(await verifyWeaning(page,plan,litter,journal.litters[litter.tag],journal,stage));
    }
    if(action!=='create') {
      const after=await snapshot(page),audit=auditSnapshot(journal.baseline,after,plan,journal);
      fs.writeFileSync(`softmouse-litters-${plan.runId}-verification.json`,JSON.stringify({verifiedAt:new Date().toISOString(),runId:plan.runId,action,...audit,results,records:after},null,2));
      await litterRows(page);await page.screenshot({path:`softmouse-litters-${plan.runId}-verified.png`,fullPage:true});
    }
    stage('action_complete',{action});
  } catch(e) {
    stage('stopped',{message:e.message});
    try {stage('post_attempt_litters',{records:await litterRows(page)});}catch(readError){stage('read_failed',{message:readError.message});}
    throw e;
  }finally{fs.unlinkSync(lock);}
}
module.exports={normalize,litterRows,matchLitter,openLitter,createLitter,ensurePups,editPups,destinationGroups,allocate,resolveDestinations,verifyWeaning,weanLitter,allowedCageConfirmation,auditSnapshot,today,hash};
if(require.main===module)main().then(()=>process.exit(0)).catch(e=>{console.error(e.stack);process.exit(1);});
