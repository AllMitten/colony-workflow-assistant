'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {normalize,destinationGroups,allowedCageConfirmation}=require('./softmouse-litters.cjs');
const example=()=>JSON.parse(fs.readFileSync('softmouse-litters-closed-practice.json','utf8'));
test('birth records need dates and a mating reference, without pup details',()=>{
  const source=example();delete source.litters[0].weaning;
  const plan=normalize(source);assert.equal(plan.litters[0].tag,'TEST-LITTER-L1');
  assert.equal(plan.litters[0].weaning,undefined);assert.equal(plan.litters[0].matingCageTag,'EXAMPLE-PARENT');
});
test('weaning preserves omitted identifiers/comments and keeps rack separate from cage tag',()=>{
  const plan=normalize(example()),l=plan.litters[0];
  assert.equal(l.weaning.pups[0].tag,null);assert.equal(l.weaning.pups[1].comment,null);
  assert.equal(l.weaning.pups[0].altId,'I-A');assert.equal(l.weaning.pups[1].altId,'I-B');
  const groups=destinationGroups(l,{pupIds:['1','2','3'],pupSids:['11','12','13']});
  assert.equal(groups.length,3);assert.deepEqual(groups.map(g=>g.ids),[['1'],['2'],['3']]);
  assert.equal(l.weanDate,'2026-10-14');assert.equal(l.weaning.date,'2026-10-15');
});
test('wrong counts, impossible dates and unresolved sex stop before UI writes',()=>{
  const count=example();count.litters[0].weaning.count=4;assert.throws(()=>normalize(count),/count differs/);
  const date=example();date.litters[0].birthDate='2026-02-30';assert.throws(()=>normalize(date),/invalid date/);
  const sex=example();sex.litters[0].weaning.pups[0].sex='U';assert.throws(()=>normalize(sex),/M\/F/);
  const future=example();future.litters[0].weaning.date='2026-10-16';assert.throws(()=>normalize(future),/Actual wean date/);
});
test('conflicting destination sex, position and capacity are rejected during preparation',()=>{
  const mixed=example();mixed.litters[0].weaning.pups[2].cage={...mixed.litters[0].weaning.pups[0].cage};
  assert.throws(()=>normalize(mixed),/Mixed-sex/);
  const rack=example();rack.litters[0].weaning.pups[1].cage.tag=rack.litters[0].weaning.pups[0].cage.tag;
  assert.throws(()=>normalize(rack),/rack positions/);
  const full=example();full.litters[0].weaning.pups=Array.from({length:6},()=>({sex:'M',cage:{tag:'SAME',mode:'new',rackPosition:'I-A'}}));full.litters[0].weaning.count=6;
  assert.throws(()=>normalize(full),/capacity/);
});
test('existing-cage confirmation is allowed only for the exact verified destination tags',()=>{
  const message='The cage tag(s) KNOWN is/are already in use with an active cage in your facility, are you sure you want to use it again?';
  assert.equal(allowedCageConfirmation(message,['KNOWN']),true);
  assert.equal(allowedCageConfirmation(message,[]),false);
  assert.equal(allowedCageConfirmation(message,['OTHER']),false);
  assert.equal(allowedCageConfirmation('Validation failed',['KNOWN']),false);
});
