// Packaged helper: launch the reviewed app with npm start; legacy standalone runs are disabled.
if (require.main === module) throw new Error('Launch this package with npm start. Standalone legacy scripts are disabled.');
'use strict';
// Reconcile real mating records after normal-form animal/cage creation.
const fs = require('node:fs');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { readRows, fieldValue, selectLabel } = require('./softmouse-batch.cjs');
const { clickFill, setCalendarDate, dateISO, selectedLabel } = require('./softmouse-one-male.cjs');
function historyComment(mating) {
  return [mating.comment, `Source mating SID: ${mating.sourceSid}.`,
    mating.litters.length ? 'Historical litters (source summaries; reference only):\n' + mating.litters.map(l => l.raw).join('\n') : '']
    .filter(Boolean).join('\n');
}
function expectedIds(profile, records, mating) {
  const id = key => {
    const mouse = profile.mice.find(m => m.key === key);
    const matches = records.filter(r => fieldValue(r.fields, 'physicaltag') === mouse.tag);
    assert.equal(matches.length, 1, `Missing or duplicated breeder ${mouse.tag}`);
    assert.equal(fieldValue(matches[0].fields, 'cagetag'), mouse.cageTag, 'Breeder housing differs');
    return matches[0].id;
  };
  return { male: id(mating.sireKey), females: mating.damKeys.map(id) };
}
async function matingRows(page) {
  await page.getByRole('link', { name: 'Matings', exact: true }).first().click();
  await page.waitForLoadState('networkidle');
  if (!await page.locator('#filterClear').isVisible()) await page.locator('#editOpenCloseImage').click();
  await page.locator('#filterClear').click();
  await page.locator('#matingState + button').click();
  const all = page.locator('.ui-multiselect-menu:visible label').filter({ hasText: /^All$/ });
  if (!await all.locator('input').isChecked()) await all.click();
  assert.ok(await page.locator('#matingState').evaluate(e => Array.from(e.options).filter(o => o.value !== 'All').every(o => o.selected)));
  await page.locator('#filterApply').click(); await page.waitForLoadState('networkidle');
  return readRows(page.locator('#matinglist_table tr.jqgrow'));
}
async function createMating(page, mating, ids, profile, stage) {
  const url = new URL('https://www.softmouse.net/smdb/mating/mating.do');
  url.searchParams.set('reqCode', 'initCreateMating');
  url.searchParams.set('males', ids.male); url.searchParams.set('females', ids.females.join(','));
  await page.goto(url.href);
  await page.locator(`#malemouseTable tr[id="${ids.male}"] input[type="checkbox"]`).check();
  for (const female of ids.females) await page.locator(`#femalemouseTable tr[id="${female}"] input[type="checkbox"]`).check();
  await setCalendarDate(page, page.locator('#setupDate'), mating.setupDate, () => page.locator('#setupDate').click());
  await selectLabel(page.locator('#mouselineId'), mating.litterStrain);
  await clickFill(page.locator('#matingTag'), mating.tag);
  await clickFill(page.locator('#comment'), historyComment(mating));
  await page.getByRole('button', { name: 'Add', exact: true }).click();
  const preview = page.locator('#batchPreviewTable tr.jqgrow'); await preview.first().waitFor();
  assert.equal(await preview.count(), 1, 'Unexpected mating preview size');
  const text = await preview.innerText();
  for (const key of [mating.sireKey, ...mating.damKeys]) assert.ok(text.includes(profile.mice.find(m => m.key === key).tag), 'Mating preview omitted breeder');
  await page.locator('#cb_batchPreviewTable').check();
  stage('mating_creation_attempt', { sourceSid: mating.sourceSid, ids });
  await page.locator('#submitBatches').click(); await page.waitForLoadState('networkidle');
}
async function editMating(page, mating, row, stage) {
  const link = page.locator(`#matinglist_table tr[id="${row.id}"]`).locator('a[href*="initEditMating"]').first();
  await link.click(); await page.locator('#setupDate').waitFor();
  const tag = page.locator('input[name*="matingTag"]');
  assert.equal(await tag.count(), 1, 'Mating tag editor is ambiguous');
  if (await tag.inputValue() === mating.tag
    && await selectedLabel(page.locator('#selectmouselineid')) === mating.litterStrain
    && dateISO(await page.locator('#setupDate').inputValue()) === mating.setupDate
    && await page.locator('#comment').inputValue() === historyComment(mating)) {
    stage('mating_edit_already_matches', { sourceSid: mating.sourceSid, id: row.id });
    return;
  }
  await clickFill(tag, mating.tag);
  await selectLabel(page.locator('#selectmouselineid'), mating.litterStrain);
  await setCalendarDate(page, page.locator('#setupDate'), mating.setupDate, () => page.locator('#setupDate').click());
  await clickFill(page.locator('#comment'), historyComment(mating));
  stage('mating_edit_attempt', { sourceSid: mating.sourceSid, id: row.id });
  await page.locator('#savestay').click(); await page.waitForLoadState('networkidle');
}
async function addDams(page, mating, missingIds, stage) {
  await page.getByText('Add Animal to Mating', { exact: true }).filter({ visible: true }).click();
  await page.waitForLoadState('networkidle');
  for (const id of missingIds) await page.locator(`#mouseTable tr[id="${id}"] input[type="checkbox"]`).check();
  assert.equal(await page.locator('#mouseTable tr.jqgrow input:checked').count(), missingIds.length, 'Unexpected breeder selection');
  await setCalendarDate(page, page.locator('#dateMatedaddmouse2mating'), mating.setupDate,
    () => page.locator('#dateMatedaddmouse2mating').click());
  stage('additional_dam_save_attempt', { sourceSid: mating.sourceSid, missingIds });
  // Submit preserves the separate source cage; Submit + Move would rehouse it.
  await page.locator('#addMouseActionApply').click(); await page.waitForLoadState('networkidle');
}
async function main() {
  const args = process.argv.slice(2), arg = k => { const i = args.indexOf(k); return i < 0 ? null : args[i + 1]; };
  assert.ok(args.includes('--save') && args.includes('--authorized-practice'));
  const profile = JSON.parse(fs.readFileSync(arg('--plan') || 'softmouse-profile-R261014A.json', 'utf8'));
  const journalPath = `softmouse-profile-${profile.namespace}-matings.json`;
  const journal = fs.existsSync(journalPath) ? JSON.parse(fs.readFileSync(journalPath, 'utf8')) : { planHash: profile.planHash, actions: [] };
  assert.equal(journal.planHash, profile.planHash);
  const stage = (status, details) => {
    journal.actions.push({ status, ...details, at: new Date().toISOString() });
    fs.writeFileSync(journalPath, JSON.stringify(journal, null, 2)); console.log(status, details.sourceSid);
  };
  const browser = await chromium.connectOverCDP(arg('--cdp') || 'http://127.0.0.1:9222');
  const pages = browser.contexts().flatMap(c => c.pages()).filter(p => p.url().includes('softmouse.net'));
  assert.equal(pages.length, 1); const page = pages[0]; page.setDefaultTimeout(20000);
  let dialogError = '';
  page.on('dialog', async d => { dialogError = d.message(); await d.dismiss(); });
  const { findRecords } = require('./softmouse-one-male.cjs');
  const animals = await findRecords(page.context(), 'mouse', '', { allowPages: true, details: true });
  assert.equal(animals.length, profile.mice.length, 'Destination animal count differs before mating reconciliation');
  for (const mating of profile.matings) {
    const ids = expectedIds(profile, animals, mating);
    let rows = await matingRows(page);
    let matches = rows.filter(r => fieldValue(r.fields, 'maleId') === ids.male);
    assert.ok(matches.length <= 1, 'Multiple matings for one imported sire; reconcile before retry');
    if (!matches.length) {
      await createMating(page, mating, ids, profile, stage);
      rows = await matingRows(page); matches = rows.filter(r => fieldValue(r.fields, 'maleId') === ids.male);
      assert.equal(matches.length, 1, 'Mating save outcome not verified; creation will not be blindly repeated');
    }
    const actualDams = fieldValue(matches[0].fields, 'femaleIds').match(/\d+/g) || [];
    assert.ok(actualDams.every(id => ids.females.includes(id)), 'Unexpected existing dam');
    await editMating(page, mating, matches[0], stage);
    const missing = ids.females.filter(id => !actualDams.includes(id));
    if (missing.length) await addDams(page, mating, missing, stage);
    assert.ok(!dialogError, dialogError);
    rows = await matingRows(page); matches = rows.filter(r => fieldValue(r.fields, 'maleId') === ids.male);
    assert.equal(matches.length, 1);
    const fields = matches[0].fields;
    assert.deepEqual((fieldValue(fields, 'femaleIds').match(/\d+/g) || []).sort(), [...ids.females].sort(), 'Saved mating dams differ');
    assert.equal(fieldValue(fields, 'mouseline'), mating.litterStrain);
    assert.equal(dateISO(fieldValue(fields, 'setupdate')), mating.setupDate);
    assert.equal(fieldValue(fields, 'state'), 'Active');
    assert.equal(fieldValue(fields, 'comment'), historyComment(mating).replace(/\s+/g, ' ').trim());
    stage('mating_verified', { sourceSid: mating.sourceSid, id: matches[0].id, ids, fields });
  }
  const all = await matingRows(page); assert.equal(all.length, profile.matings.length, 'Final mating count differs');
  stage('all_matings_verified', { sourceSid: 'all', count: all.length });
}
module.exports = { historyComment, expectedIds, matingRows, createMating, editMating, addDams, main };
if (require.main === module) main().then(() => process.exit(0)).catch(e => { console.error(e.stack); process.exit(1); });
