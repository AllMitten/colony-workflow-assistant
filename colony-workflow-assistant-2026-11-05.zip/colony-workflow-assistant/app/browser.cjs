'use strict';
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const {chromium}=require('playwright');
const {ROOT}=require('./store.cjs');
class BrowserSession{
  constructor(){this.context=null;this.page=null;this.starting=null;this.dialogError='';}
  async open(){
    if(this.page&&!this.page.isClosed()){await this.page.bringToFront();return this.page;}
    if(this.starting)return this.starting;
    this.starting=this.launch();try{return await this.starting;}finally{this.starting=null;}
  }
  async launch(){
    if(process.env.SOFTMOUSE_ATTACH_PORT){
      this.connection=await chromium.connectOverCDP('http://127.0.0.1:'+Number(process.env.SOFTMOUSE_ATTACH_PORT));
      this.context=this.connection.contexts().find(c=>c.pages().some(p=>p.url().startsWith('https://www.softmouse.net/')));
      if(!this.context)throw Error('The shared SoftMouse browser has no SoftMouse tab');
      this.page=this.context.pages().find(p=>p.url().startsWith('https://www.softmouse.net/'));
      this.page.setDefaultTimeout(20000);this.attachDialogs(this.page);this.context.on('page',p=>this.attachDialogs(p));
      return this.page;
    }
    const dir=path.join(ROOT,'lab-data','browser');fs.mkdirSync(dir,{recursive:true});
    const port=Number(process.env.SOFTMOUSE_BROWSER_PORT||9333);
    const downloads=fs.mkdtempSync(path.join(os.tmpdir(),'softmouse-lab-downloads-'));
    this.context=await chromium.launchPersistentContext(dir,{headless:false,acceptDownloads:true,downloadsPath:downloads,viewport:{width:1500,height:900},args:['--remote-debugging-port='+port,'--remote-debugging-address=127.0.0.1','--start-maximized']});
    this.managedBrowser=this.context.browser();
    this.page=this.context.pages()[0]||await this.context.newPage();
    this.page.setDefaultTimeout(20000);this.attachDialogs(this.page);
    this.context.on('page',p=>this.attachDialogs(p));
    this.context.on('close',()=>{this.page=null;this.context=null;});
    await this.page.goto('https://www.softmouse.net/HomePage.do');await this.page.waitForLoadState('networkidle');
    return this.page;
  }
  attachDialogs(page){page.on('dialog',async d=>{
    const message=d.message();
    const approved=this.confirmationTags?.length&&d.type()==='confirm'&&require('../softmouse-litters.cjs').allowedCageConfirmation(message,this.confirmationTags);
    this.onDialog?.({message,accepted:!!approved});
    if(!approved)this.dialogError=message;
    try{if(approved)await d.accept();else await d.dismiss();}catch(e){this.dialogError=e.message;}
  });}
  check(){if(this.dialogError)throw Error('SoftMouse displayed a message requiring review: '+this.dialogError);}
  async reset(){this.dialogError='';this.confirmationTags=[];this.check();}
  async profiles(){
    const page=await this.open();
    await page.goto('https://www.softmouse.net/HomePage.do');
    await page.waitForLoadState('networkidle');
    if(!await page.locator('a[href*="ownerCode="]').count())try{await page.locator('a[href*="ownerCode="]').first().waitFor({timeout:8000});}catch{}
    const links=await page.locator('a[href*="ownerCode="]').evaluateAll(es=>es.map(e=>({name:e.textContent.trim(),id:new URL(e.href).searchParams.get('ownerCode')})).filter(x=>x.name&&/^\d+$/.test(x.id)));
    if(!links.length&&await page.locator('#signout').count()){
      await page.goto('https://www.softmouse.net/smdb/mouse/list.do');await page.waitForLoadState('networkidle');
      const choices=await page.locator('select#ownerId option,select#ownerIds option').evaluateAll(es=>es.map(e=>({id:e.value,name:e.textContent.trim().replace(/\s*\(Me\)\s*$/,'')})).filter(p=>/^\d+$/.test(p.id)&&p.name));links.push(...choices);
    }
    const unique=[...new Map(links.map(x=>[x.id,x])).values()];
    if(!unique.length)return {signedIn:false,profiles:[],message:'Sign in manually in the SoftMouse window, then refresh profiles.'};
    return {signedIn:true,profiles:unique};
  }
  async assertProfile(profile){const state=await this.profiles();if(!state.profiles.some(p=>p.id===profile.id&&p.name===profile.name))throw Error('Selected profile is no longer available in this signed-in account. Nothing will be saved.');}
}
async function visibleClick(page,locator){
  if(!await locator.isVisible()){
    for(const cls of ['button.dr-breakout-btnicons','button.dr-breakout-btn']){
      const toggle=page.locator(cls);if(await toggle.count()&&await toggle.first().isVisible()){await toggle.first().click();if(await locator.isVisible())break;}
    }
  }
  await locator.click();
}
module.exports={BrowserSession,visibleClick};
