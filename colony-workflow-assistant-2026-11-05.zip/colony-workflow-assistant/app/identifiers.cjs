'use strict';
const invisible=/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/;
function cageKey(value){return String(value).trim().toUpperCase().replace(/^[A-Z]{1,3}(?=\d+$)/,'');}
module.exports={invisible,cageKey};
