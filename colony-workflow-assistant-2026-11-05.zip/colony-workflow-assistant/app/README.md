# SoftMouse Lab

A local Windows app for three reviewed colony operations: adding cage cards, recording births, and weaning litters. SoftMouse remains visible while Playwright fills its normal forms. No bulk import is used.

## Start and sign in

1. Double-click **Start Colony Workflow.cmd** in the project folder, or run `npm start`.
2. Click **Open SoftMouse window**. Sign into SoftMouse in that window.
3. Click **Refresh profiles**. Select the exact destination name and numeric profile ID.
4. Choose a workflow and enter its data or load a prepared JSON file.
5. Click **Check input & prepare backups**. This reads the selected profile and downloads four official Excel exports.
6. Review the proposed mice, cages, dates and destinations. Download the backups if desired. Type the selected profile name exactly and confirm to save.
7. Wait for **Verified**. Read the operation history if the app stops or reports an error.

Allow several minutes for the four exports and full verification; time depends on profile and batch size. The progress popup describes the current step. Reviews expire after 15 minutes and require fresh preparation. Leave the SoftMouse window untouched while a run is working.

Node.js and the project's Playwright dependency/browser must already be installed. Development checks: `npm test`. In Windows PowerShell with script execution disabled, use `npm.cmd start` / `npm.cmd test`, or the double-click launcher. The app binds only to `127.0.0.1`; its usual address is `http://127.0.0.1:4317`. Keep the terminal open while it runs. The launcher reopens an already running app. Browser login state is stored in `lab-data/browser`; SoftMouse may require a new sign-in after a restart. Passwords are not stored in operation inputs or source code. Do not share that browser directory.

For a fresh copy, install Node.js, then run these commands from the project folder before launching:

```powershell
npm.cmd ci
npx.cmd playwright install chromium
```

## What the three workflows do

**New cage cards** accepts the prepared cage JSON used by this project. Each mouse has its own tag, DOB, sex, strain, protocol, rack position and comment. Cage membership refers to mouse keys. Explicit mating assignments create matings. This operation never adds litters. Existing cage cards or digital IDs cause a stop; this is an addition workflow, not an overwrite workflow.

**Add litters** needs the source mating cage card, DOB and planned wean date. A litter tag and comment are optional. The app resolves the parents from the active mating and saves a birth record with **zero individual pups**. An existing litter with the same parents and DOB causes a stop. For multiple dams sharing the source cage, maternity remains unknown: all possible dams are retained in SoftMouse, shown at review, and named in the litter comment. This follows [SoftMouse's documented group-litter behavior](https://softmousefaq.com/index.php/How%20To%20Create%20New%20Litters). Dams in separate cages, or requests to select one mother from several, stop for individual review.

**Wean litters** needs a unique source litter, actual wean date and M/F/Unknown counts. Create the individual assignment rows, enter any known physical tag, destination cage card and rack position, and choose whether the destination cage is new or existing. Select same-sex rows and use **Group selected** to give them one destination. **Ungroup selected** clears their destinations for reassignment. Comments are optional; omitted comments preserve an existing pup's comment.

If a litter has zero pups, the app creates the supplied cohort at weaning. If pups already exist, their number and sexes must agree exactly. Existing physical markings cannot be overwritten. An existing digital ID is retained; a previously uncoded pup receives one when this operation first saves its individual details. The app weans the whole supplied cohort; partial litter weaning and sex correction are not supported. Any ambiguity stops the operation. Physical tags such as `,'..,.'` are literal strings and retain their punctuation. Unknown-sex animals use `U` and have separate destination cages.

## Short instructions

Add litters and Wean litters accept short text under **Short instructions**. Conversion searches accessible profiles for a unique source cage and produces JSON for review; it does not save records. See [format and matching rules](SHORT-INSTRUCTIONS.md). A litter DOB is required for weaning. Unknown physical tags may be blank; IDs are assigned during preparation. Only placeholder examples in app/examples are included in this source package. Site-specific showcase inputs are not distributed.

## JSON input contract

Use UTF-8 JSON, with dates as **YYYY-MM-DD**, cage cards/tags as **strings** (preserve leading zeros), sex as `M`, `F`, or `U`, and numeric counts as integers. All labels, including strain, protocol and rack position, must match an existing SoftMouse choice exactly. The app does not guess or silently create missing catalog entries.

Editable example files are in [examples](examples/). Replace their example identifiers and dates before preparing; they are not approved batches.

Each prepared operation has this envelope:

```json
{
  "schemaVersion": 1,
  "operation": "add_litters",
  "profile": {"id": "99999", "name": "Practice Profile"},
  "asOf": "2026-10-24",
  "data": {
    "litters": [{
      "cageTag": "SOURCE-CAGE",
      "birthDate": "2026-10-03",
      "weanDate": "2026-10-24",
      "tag": "EXAMPLE-L1",
      "comment": "Optional litter comment"
    }]
  }
}
```

The profile in a file must match the UI selection in both ID and name. Do not reuse the example's destination without checking the signed-in account. Omit `profile` to use the explicitly selected UI profile. `asOf` defaults to the current New York date. Examples are documentation, not approved batches.

For **add_cages**, `data` contains:

```json
{
  "mice": [{
    "key": "m1", "tag": "EXAMPLE-M1", "sex": "M", "dob": "2026-08-01",
    "state": "Stock", "strain": "Example Strain", "protocol": "EXAMPLE-PROTOCOL",
    "altId": "I-A", "comment": "Parent cage 04301233.", "allele": "",
    "cageTag": "EXAMPLE-C1"
  }],
  "cages": [{"tag": "EXAMPLE-C1", "members": ["m1"]}],
  "matings": []
}
```

`altId` is the rack position. Each mouse must occur in exactly one cage. Physical tags are optional and may repeat. The app reserves a permanent nine-character i/I/| digital ID during preparation. Review shows the physical tag, digital ID and final stored tag. The physical portion is limited to 15 characters so the combined value fits SoftMouse?s 25-character field. New cage mice use M/F, with state Stock/Mating. For a mating add a record with `tag`, `sourceSid`, `sireKey`, `damKeys`, `litterStrain`, `setupDate`, `comment`, and `litters: []`; its breeders must all have state Mating and share a cage. At most two dams are supported for this creation path. A single cage may hold at most five adults. Genotype `+/-` represents heterozygous; an empty allele means no genotype is assigned. No historical litter input is accepted here.

For **wean_litters**, `data` contains:

```json
{
  "litters": [{
    "cageTag": "SOURCE-CAGE", "tag": "EXAMPLE-L1",
    "birthDate": "2026-10-03", "date": "2026-10-24",
    "counts": {"male": 1, "female": 0, "unknown": 1},
    "pups": [
      {"sex": "M", "tag": ",'..,.'", "destination": {
        "tag": "EXAMPLE-WM", "rackPosition": "I-A", "mode": "new"
      }},
      {"sex": "U", "tag": "'.,'..'", "comment": "Optional comment", "destination": {
        "tag": "EXAMPLE-WU", "rackPosition": "I-B", "mode": "new"
      }}
    ]
  }]
}
```

Litter DOB is required for every weaning. `litterId` may additionally identify the exact SoftMouse record. `existingMouseId` may identify an existing pup, but it must match the litter, known physical tag and sex. Existing mice with the same physical tag require an explicit `existingMouseId` if matching them is ambiguous. For multiple litters use **Use prepared operation JSON**. Counts must equal the rows exactly. Destination groups must have the same sex, rack and new/existing choice, and stay within five animals including current residents. Existing destinations must be active non-breeding cages.

## Backups, history and recovery

Before any approved operation, four official XLSX exports are saved under:

`lab-data/backups/<profile ID>/<operation ID>/`

Names use Windows-safe timestamps, for example `MouseList-10-24-2026-14-46-00.xlsx`. A manifest records profile, counts and SHA-256 hashes. The app checks workbook structure and record counts. It rereads the profile immediately before saving and stops if the baseline changed after review. Backups capture the list exports, not attachments or a full SoftMouse database image; they are not an automatic undo.

`lab-data/operations/<operation ID>/` contains the immutable submitted input, resolved record IDs, append-only hash-linked events, before/after evidence, verification results and screenshot. The UI provides file links and a Code 39 **operation barcode**. Search history by that barcode, source/destination cage card, physical tag or profile. Existing cage barcodes are recorded when supplied by SoftMouse and never changed. Mouse IDs and optional numeric Code 39 barcode links appear in operation history. The hash chain detects accidental changes; it is not a signed, tamper-proof compliance archive.

**Do not rerun an operation that stopped after a save.** SoftMouse may have committed some steps. The app marks it **Needs review**, reads current records when possible, and blocks automatic replay. Inspect the saved records and `post-attempt.json`; prepare only the verified missing work as a fresh operation. A stop request prevents subsequent steps; it cannot cancel a save already accepted by SoftMouse. There is no automatic rollback.

One narrow recovery is supported through prepared weaning JSON: `resumeWeaned: true` on a litter completes cage moves for a cohort that is already weaned. It requires the exact saved date, counts, sexes and physical tags, with every pup still in the source cage. It takes fresh backups and requires a new review. It never creates pups or repeats weaning. Partially moved cohorts remain blocked for individual reconciliation.

Back up `lab-data/mouse-identities.json` and its `.initialized` marker with the operation evidence. This registry is the shared ID allocation authority across profiles. Never reset it or initialize independent installations for the same colony; see MOUSE-IDS.md.

Only one operation may use the workspace at a time. If an operation lock remains after a crash, review the interrupted history and confirm no runner is active before removing `lab-data/operation.lock`. Never remove a live lock. Restarted reviews require fresh preparation. Do not click or edit the SoftMouse window while the app is working.

## Source map and release status

| File | Purpose |
| --- | --- |
| `server.cjs` / `public/` | Local UI, review, progress, history and file access |
| `contracts.cjs` | Input validation and canonical operation format |
| `browser.cjs` | Shared visible browser and dialog handling |
| `softmouse.cjs` / `xlsx.cjs` | Profile-scoped reads and official backup verification |
| `runner.cjs` | Reviewed workflow execution and post-save checks |
| `store.cjs` | Operation IDs, barcode, evidence and history integrity |
| Root `softmouse-*.cjs` | Existing form-filling and verification helpers |

For development tools, `lab-data/instance.json` records the running app URL, process ID and shared browser's CDP port. Connect inspection tools to that browser only while the runner is idle. The default app/browser ports are 4317/9333; `SOFTMOUSE_PORT` and `SOFTMOUSE_BROWSER_PORT` can override them. Never attach to an unrelated older browser for a save operation.

Read `ACCEPTANCE.md` for the actual checks performed and outstanding limitations. All three main workflows have completed practice-account saves; treat this as a candidate for supervised pilot review. The permanent i/I/| digital-ID implementation is documented in [Mouse IDs](MOUSE-IDS.md). See [setup and approval walkthrough](SETUP-AND-APPROVAL.md) for installation and presentation guidance. A single-profile practice test cannot prove that every multi-user permissions configuration behaves identically.


## Fast mode

Fast mode is unchecked by default and resets on page reload. Tick it and click **Run** after pasting short instructions. The app identifies the unique source profile, converts the text, creates a draft, validates it, takes the four official Excel backups, saves and verifies without a review dialog or typed-profile confirmation. Prepared JSON and regular forms can also use Fast mode with an explicitly selected matching profile.

The Run click authorizes that submitted input and resolved profile. Ambiguous matches, missing data, failed exports, changed baselines, identity/capacity checks and uncertain saves still stop the operation. Fast mode uses the ordinary guarded save path and never retries a save automatically. Restarted operations require reconciliation; no background continuation is scheduled. Fast mode removes manual steps, not backup/verification time. History records the mode and input hash. Use the standard unchecked mode when a manual review is wanted.


## Launch stress checks (November 2)

See [stress-test report](STRESS-TEST-REPORT.md) and ../VALIDATION.md for the packaged test scope and remaining acceptance limits. Historical run records are excluded.

Per-operation limits: 250 new mice, 100 new cages, 100 matings, 50 litters, or 200 weanlings. Individual sex-count and five-animal cage limits also apply. Split larger jobs into reviewed batches. Short text accepts one operation message at a time; use JSON for batches. Identifiers with surrounding whitespace or invisible/control characters are rejected. Stock cages must have one sex and consistent rack positions; breeding cages require explicit mating assignments.

New work overlapping an earlier uncertain save is blocked even if its comment or date of entry changes. Inspect the named operation and reconcile actual saved records first. Explicit whole-cohort weaning recovery remains supported; there is no general automatic repair for partly created adult cages. Restore history/registry from verified evidence rather than deleting records or resetting IDs. Progress supports up to 30 tabs; close unused tabs. A stale page after server restart requires reload. A network-uncertain submission disables repeat starts until a terminal status is observed or history is checked.

Invalid plans no longer consume ID reservations. Valid prepared plans still reserve codes permanently, even if canceled. Existing IDs can be retained when the pool is full. Registry consistency and case-sensitive ID lookup are checked.

Run `npm.cmd test` for all checks, or `npm.cmd run test:stress` for the focused subset. These tests use local servers/isolated browser fixtures and do not write to SoftMouse.


The selected SoftMouse account must permit every requested feature. The current practice account's Free edition disables protocol assignment; the app now stops with that capability error rather than silently dropping a requested protocol or trying to enable the field. Explicitly blank protocol input can stay blank in supported basic entry. A complete protocol-bearing lab workflow requires an account/edition with that feature enabled.
