'use strict';
function matches(state,input,resolved,query){
 const q=String(query||'').trim();if(!q)return true;
 if(/^[iI|]{9}$/.test(q)){
  const mice=[...(input?.data?.mice||[]),...(input?.data?.litters||[]).flatMap(l=>l.pups||[]),...(resolved?.data?.mice||[]),...(resolved?.litters||[]).flatMap(l=>l.pups||[])];
  return mice.some(m=>m.digitalCode===q||m.tag===q||m.tag?.endsWith(' '+q));
 }
 return JSON.stringify({id:state.id,profile:state.profile,operation:state.operation,input,resolved}).toLowerCase().includes(q.toLowerCase());
}
module.exports={matches};
