'use strict';
const fs=require('node:fs');const path=require('node:path');const {spawn}=require('node:child_process');
const file=path.join(__dirname,'../lab-data/instance.json');
(async()=>{if(fs.existsSync(file))try{const s=JSON.parse(fs.readFileSync(file,'utf8'));if(/^http:\/\/127\.0\.0\.1:\d+$/.test(s.url)){const r=await fetch(s.url+'/api/state',{signal:AbortSignal.timeout(1500)});if(r.ok){spawn('rundll32.exe',['url.dll,FileProtocolHandler',s.url],{windowsHide:true,stdio:'ignore'}).unref();return;}}}catch{}require('./server.cjs');})();
