'use strict';
const {test}=require('node:test'),a=require('node:assert/strict');
const short=require('../short-input.cjs');
const p={id:'1',name:'Practice'},q={id:'2',name:'Other'};
const row=(id,fields)=>({id,fields:Object.fromEntries(Object.entries(fields).map(([k,v])=>['grid_'+k,v]))});
const cages=[row('10',{cagetag:'CCB11111'})];
const litters=[row('20',{litterstate:'Active',mothercagetag:'CCB11111',dateofbirth:'10-01-2026',littertag:'L1'})];
const read=async(kind,profile)=>profile.id!=='1'?[]:({cages,litters,matings:[row('30',{state:'Active',cagetag:'CCB11111'})]})[kind];
test('short dates accept US variants and ISO, reject impossible or incomplete dates',()=>{
 for(const d of ['1/1/26','01/01/2026','1-1-26','2026-01-01'])a.equal(short.date(d),'2026-01-01');
 for(const d of ['2/29/26','4/31/26','1/1','tomorrow','26/1/1'])a.throws(()=>short.date(d));
 a.equal(short.date('1/2/26'),'2026-01-02');
});
test('cage matching ignores numeric prefixes and case but preserves leading zero identity',()=>{
 a.equal(short.cageKey(' ccb11111 '),short.cageKey('11111'));a.notEqual(short.cageKey('CCB011111'),short.cageKey('11111'));a.equal(short.cageKey('IT28-7A38-C1'),'IT28-7A38-C1');
});
test('birth short input binds the unique source profile and saved mating ID',async()=>{
 const parsed=short.parse(' LITTER\r\n11111\r\n10/1/26\r\n10-22-2026\r\ncomment: Practice birth');const r=await short.convert(parsed,[p,q],read);
 a.equal(r.complete,true);a.deepEqual(r.input.profile,p);a.deepEqual(r.input.data.litters,[{cageTag:'CCB11111',matingId:'30',birthDate:'2026-10-01',weanDate:'2026-10-22',comment:'Practice birth'}]);
});
test('duplicate source cages across profiles stop even when one spelling is exact',async()=>{
 await a.rejects(()=>short.convert(short.parse('litter\nCCB11111\n10/1/26\n10/22/26'),[p,q],async(kind,profile)=>kind==='cages'?[row(profile.id,{cagetag:profile.id==='1'?'CCB11111':'11111'})]:[]),/ambiguous across/);
});
test('weaning keeps punctuation tags and resolves existing destination by prefix',async()=>{
 const parsed=short.parse("wean\nDOB: 10/1/26\n11111\n10/22/26\n22222\n2m\nAlt ID: I-A\nM tags: ,'..,.'; '.''.'.\ncomment: retain punctuation");
 const r=await short.convert(parsed,[p],async(k,pr)=>k==='cages'?[...cages,row('11',{cagetag:'CCB22222'})]:read(k,pr));
 a.equal(r.complete,true);const l=r.input.data.litters[0];a.equal(l.litterId,'20');a.equal(l.pups[0].tag,",'..,.'");a.equal(l.pups[1].tag,"'.''.'.");a.deepEqual(l.pups[0].destination,{tag:'CCB22222',rackPosition:'I-A',mode:'existing'});a.equal(l.pups[1].comment,'retain punctuation');
});
test('missing physical tags produce a valid draft; IDs are assigned later during preparation',async()=>{
 const r=await short.convert(short.parse('wean\nDOB: 10/1/26\n11111\n10/22/26\n22222\n2M\nI-A'),[p],read);
 a.equal(r.complete,true);a.equal(r.issues.length,0);a.ok(r.input.data.litters[0].pups.every(p=>p.tag===''));
});
test('multiple active litters require a discriminator; foreign destinations stop',async()=>{
 const parsed=short.parse('wean\nDOB: 10/1/26\n11111\n10/22/26\n22222\n1M\nI-A\nM: TEST');
 await a.rejects(()=>short.convert(parsed,[p],async(k,pr)=>k==='litters'?[...litters,row('21',{litterstate:'Active',mothercagetag:'CCB11111',dateofbirth:'10-01-2026',littertag:'L2'})]:read(k,pr)),/Multiple active litters/);
 await a.rejects(()=>short.convert(parsed,[p,q],async(k,pr)=>pr.id==='2'&&k==='cages'?[row('90',{cagetag:'CCB22222'})]:read(k,pr)),/another profile/);
});
test('mixed sexes, tag-count discrepancies, count typos and conflicting headers stop',async()=>{
 a.throws(()=>short.parse('wean\nDOB: 10/1/26\n11111\n10/22/26\n22222\n1M 1F\nI-A'),/one sex only/);
 await a.rejects(()=>short.convert(short.parse('wean\nDOB: 10/1/26\n11111\n10/22/26\n22222\n2M\nI-A\nM: only-one'),[p],read),/tags must match/);
 a.throws(()=>short.sexCounts('2M threeF'));a.throws(()=>short.sexCounts('2M 1M'));a.throws(()=>short.parse('litter\n11111\n10/1/26\n10/22/26','wean_litters'));
});
