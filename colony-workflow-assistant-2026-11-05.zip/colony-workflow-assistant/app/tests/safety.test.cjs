'use strict';
const {test}=require('node:test');const a=require('node:assert/strict');
const {inspectRequest}=require('../request-guard.cjs');const {resolve,auditUnrelated}=require('../runner.cjs');const {verifyWorkbook,fingerprint}=require('../softmouse.cjs');
const profile={id:'99999',name:'Practice Profile'};
const row=(id,fields)=>({id,fields:Object.fromEntries(Object.entries({cagebarcode:'',...fields}).map(([k,v])=>['grid_'+k,v]))});
const request=(body,method='POST',url='https://www.softmouse.net/mating/newgrouplitter')=>({postData:()=>JSON.stringify(body),method:()=>method,url:()=>url});
test('request guard examines nested JSON owners and record IDs',()=>{
 const ids=new Set(['12']);a.equal(inspectRequest(request([{ownerId:'99999',matingId:'12'}]),profile,ids,true,false),true);
 a.throws(()=>inspectRequest(request([{ownerId:'7',matingId:'12'}]),profile,ids,true,false),/another profile/);
 a.throws(()=>inspectRequest(request([{ownerId:'99999',matingId:'99'}]),profile,ids,true,false),/outside/);
 a.throws(()=>inspectRequest(request([]),profile,ids,false,false),/before profile/);
 a.throws(()=>inspectRequest(request([]),profile,ids,true,true),/Stop/);
});
test('ending or deleting through GET cannot bypass request guard',()=>{a.throws(()=>inspectRequest(request({},'GET','https://www.softmouse.net/smdb/mouse/endmouse.do?mouseId=12'),profile,new Set(['12']),true,false),/outside/);});
test('static help assets do not trigger mutation protection',()=>{a.equal(inspectRequest(request({},'GET','https://www.softmouse.net/js/smdb/mating/RetireBreeder.js'),profile,new Set(),false,false),false);});
const before=()=>({strains:[],matings:[],mice:[row('1',{sex:'M',physicaltag:'',cageid:'source'})],cages:[row('source',{cagetag:'C1',residentmouseids:'1',cagestate:'Active'})],litters:[row('2',{mothercagetag:'C1',dateofbirth:'10-01-2026',weandate:'10-22-2026',litterstate:'Active',pupmouseid:'1',fatherid:'s1',motherid:'d1'})]});
const plan=()=>({operation:'wean_litters',profile,asOf:'2026-10-24',data:{litters:[{cageTag:'C1',litterId:'2',date:'2026-10-24',counts:{male:1,female:0,unknown:0},pups:[{sex:'M',tag:",'..,.'",destination:{tag:'NEW',rackPosition:'I-A',mode:'new'}}]}]}});
const catalog={racks:[{label:'I-A',id:'1'}]};
test('existing pup discrepancies and wrong source cage stop during preparation',()=>{
 const p=plan();p.data.litters[0].counts={male:0,female:1,unknown:0};a.throws(()=>resolve(p,before(),catalog),/disagree/);
 const b=before();b.cages.push(row('other',{cagetag:'OTHER'}));const wrong=plan();wrong.data.litters[0].cageTag='OTHER';a.throws(()=>resolve(wrong,b,catalog),/does not belong/);
});
test('physical tags cannot overwrite an existing pup identity',()=>{const b=before();b.mice[0].fields.grid_physicaltag='KEEP';a.throws(()=>resolve(plan(),b,catalog),/identity conflicts/);});
test('successful resolution binds the existing pup without losing punctuation',()=>{const p=resolve(plan(),before(),catalog);a.equal(p.litters[0].pups[0].existingMouseId,'1');a.equal(p.litters[0].pups[0].tag,",'..,.'");});
test('already-weaned recovery requires an explicit flag, exact date, source cage and physical tags',()=>{
 const b=before();b.litters[0].fields.grid_litterstate='Weaned';const p=plan();a.throws(()=>resolve(p,b,catalog),/state does not match/);p.data.litters[0].resumeWeaned=true;
 b.mice[0].fields.grid_cagetag='C1';b.mice[0].fields.grid_physicaltag=",'..,.'";b.mice[0].fields.grid_weandate='10-24-2026';b.mice[0].fields.grid_mousestate='Weanling';b.litters[0].fields.grid_weandate='10-24-2026';a.equal(resolve(p,b,catalog).litters[0].existingIds.length,1);
 b.mice[0].fields.grid_cagetag='ALREADY-MOVED';a.throws(()=>resolve(p,b,catalog),/entire cohort/);
});
test('unrelated changes are rejected even when the target operation succeeds',()=>{const b=before(),after=structuredClone(b);after.mice[0].fields.grid_physicaltag='CHANGED';a.throws(()=>auditUnrelated(b,after,{mice:{},cages:{},matings:{},litters:{}}),/Unrelated/);});
test('same-size Excel backup from another profile cannot pass identity verification',()=>{const rows=[row('1',{physicaltag:'A',sex:'M',dateofbirth:'01-01-2026',cagetag:'C',mouseline:'Example Strain'})];const parsed={headers:['Physical Tag','Sex','Date of Birth','Cage Tag','Strain'],rows:[['A','Male','01-01-2026','C','Example Strain']]};verifyWorkbook('mice',parsed,rows);parsed.rows[0][0]='OTHER';a.throws(()=>verifyWorkbook('mice',parsed,rows),/identities differ/);});
test('baseline includes actual cage assignment while ignoring rendered age',()=>{const b=before(),after=structuredClone(b);after.mice[0].fields.grid_age='new';a.equal(fingerprint(b),fingerprint(after));after.mice[0].fields.grid_cageid='changed';a.notEqual(fingerprint(b),fingerprint(after));});
test('unknown maternity retains both possible dams in one cage and rejects separated dams',()=>{
 const b={strains:[],cages:[row('1',{cagetag:'C1'})],matings:[row('10',{cagetag:'C1',state:'Active',mouseline:'Example Strain',maleId:'100',femaleIds:'101 102',setupdate:'01-01-2026'})],litters:[],mice:[row('100',{cageid:'1',physicaltag:'SIRE'}),row('101',{cageid:'1',physicaltag:'DAM-A'}),row('102',{cageid:'1',physicaltag:'DAM-B'})]};
 const p={operation:'add_litters',profile,asOf:'2026-10-24',data:{litters:[{cageTag:'C1',birthDate:'2026-10-24',weanDate:'2026-11-14',tag:'L1',comment:'Original comment'}]}};
 const l=resolve(p,b,{}).litters[0];a.deepEqual(l.damIds,['101','102']);a.equal(l.maternity,'unknown');a.match(l.comment,/Original comment\nMaternity unknown/);
 b.mice[2].fields.grid_cageid='2';a.throws(()=>resolve(p,b,{}),/separate cages/);
});
