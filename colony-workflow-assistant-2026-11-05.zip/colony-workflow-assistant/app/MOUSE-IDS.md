# Permanent mouse IDs

Every new individual mouse receives a nine-character ID using `i`, `I`, and `|`. There are 19,683 possible IDs. Physical ear-punch tags are optional and may repeat. Birth records create no individual pups, so no IDs are needed until pups are added for weaning. New adult cage entry also assigns IDs.

The actual SoftMouse physical-tag field stores `ear-punch ID`, for example `,'..,.' iI|IiiI||`. Without a known physical tag, the field contains only the ID. The physical portion is limited to 15 characters; a space plus the nine-character ID must fit the 25-character field. The app rejects excessive length rather than truncating data. Surrounding whitespace is rejected.

Existing digital IDs are reused when matching existing pups. Known physical markings are never silently removed or changed. If multiple existing pups share the supplied markings, specify `existingMouseId`; the program stops instead of assigning the wrong identity. Counts and sexes must still match the litter. ID allocation does not backfill unrelated existing adults.

## Registry and recovery

`lab-data/mouse-identities.json` is the single allocation authority for this installation, shared across profiles. Codes are allocated sequentially in base three, case-sensitively: 0=i, 1=I, 2=|. A reservation is permanent even if preparation fails or a review is abandoned. Gaps are expected; an allocated code is never recycled. Exhaustion stops the operation.

Before allocation the app reads mice in every profile discoverable by this login, checks existing codes and binds them to profile/mouse record IDs. Duplicate codes or conflicting ownership stop preparation. Unknown/inaccessible profiles cannot be inspected. Do not run independent ID registries against the same colony or copy only source code to a second active installation. One registry must remain the authority. Code uniqueness across unrelated installations/accounts is not guaranteed.

Registry updates use a local exclusive lock and atomic file replacement. A leftover registry lock is a reason to inspect a crashed process, not to delete/reset IDs. Its `.initialized` marker makes a missing registry fail closed after initialization. Reservations and bindings are copied to operation evidence as `identities-before.json`, `identities-reserved.json` and, after success, `identities-bound.json`. Restore the current registry and marker together with operation data when migrating or recovering the installation. Do not replace them with an old snapshot while newer reservations may exist. These local files are not an enterprise database or tamper-proof service.

The reviewed plan contains physical markings, digital IDs and exact saved tags. Before saving, the app checks that its reservations still belong to the operation or the matched existing mouse. After a successful save it binds codes to the actual SoftMouse record IDs. A partial save still requires record reconciliation; a future preparation can observe the saved codes and bind them without creating replacements.

## Barcode images

The i/I/| string itself is text. History offers a real Code 39 SVG barcode for each ID. Its encoded value is the corresponding nine **numeric base-three digits**, not the visual i/I/| string. Example: scanner output `000000100` maps to `iiiiiiIii`. Preserve all nine digits, including leading zeros. Scan strings need a caller that converts numeric digits back to visual IDs; automatic scanner-to-UI entry is not integrated in this release. Operation barcodes remain separate and encode OP identifiers.

UI inputs and review preserve exact case and punctuation. Do not substitute lowercase L for uppercase I or change pipe characters when copying an ID. Mouse IDs are searchable in operation history through resolved plans.
