'use strict';
class ProgressStream{
 constructor(build,{interval=1000,maxClients=30,maxBufferedBytes=1024*1024}={}){this.build=build;this.maxClients=maxClients;this.maxBufferedBytes=maxBufferedBytes;this.clients=new Set();this.last='';this.timer=setInterval(()=>this.publish(),interval);this.timer.unref();}
 add(req,res){if(this.clients.size>=this.maxClients){res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'Too many open app tabs. Close unused tabs and reconnect.'}));return;}res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});this.clients.add(res);req.on('close',()=>this.clients.delete(res));if(this.last)res.write('data: '+this.last+'\n\n');}
 publish(){if(!this.clients.size)return;let value;try{value=JSON.stringify(this.build());}catch(e){value=JSON.stringify({error:'Progress/history unavailable: '+e.message});}const packet=value===this.last?': heartbeat\n\n':'data: '+value+'\n\n';this.last=value;for(const res of this.clients){try{if(res.writableLength>this.maxBufferedBytes){res.end();this.clients.delete(res);}else res.write(packet);}catch{this.clients.delete(res);}}}
 close(){clearInterval(this.timer);for(const res of this.clients)res.end();this.clients.clear();}
}
module.exports={ProgressStream};
