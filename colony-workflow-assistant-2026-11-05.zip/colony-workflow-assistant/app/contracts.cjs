'use strict';
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {invisible,cageKey}=require('./identifiers.cjs');
const record=v=>!!v&&typeof v==='object'&&!Array.isArray(v);
const LIMITS={mice:250,cages:100,matings:100,litters:50,weanlings:200};
const digest=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York'}).format(new Date());
function check(condition,message){assert.ok(condition,message);}
function text(value,label,max=2000){check(typeof value==='string',`${label} must be text`);check(value.length<=max,`${label} is too long`);return value;}
function required(value,label,max=25){text(value,label,max);check(value.trim().length>0,`${label} is required`);check(value===value.trim(),`${label}: remove surrounding whitespace`);check(!invisible.test(value),`${label} contains invisible or control characters`);return value;}
function date(value,label){check(/^\d{4}-\d{2}-\d{2}$/.test(value||''),`${label}: use YYYY-MM-DD`);check(new Date(value+'T12:00:00Z').toISOString().slice(0,10)===value,`${label} is invalid`);return value;}
function physicalTag(mouse){mouse.tag=mouse.tag??'';text(mouse.tag,'Physical tag',25);check(!invisible.test(mouse.tag),'Physical tag contains invisible or control characters');check(mouse.tag===mouse.tag.trim(),'Remove surrounding whitespace from the physical tag');const saved=/^(?:(.{1,15}) )?[iI|]{9}$/.test(mouse.tag);check(saved||mouse.tag.length<=15,'Physical tag exceeds 15 characters; space is needed for its digital ID');check(!mouse.digitalCode&&!mouse.physicalTag,'Supply the physical tag only; digital IDs are assigned by the program');return mouse.tag;}
function unique(values,label){check(new Set(values).size===values.length,`${label} contains duplicates`);}
function counts(pups){return {male:pups.filter(p=>p.sex==='M').length,female:pups.filter(p=>p.sex==='F').length,unknown:pups.filter(p=>p.sex==='U').length};}
function validate(raw,profile){
  check(raw&&typeof raw==='object'&&!Array.isArray(raw),'Input must be a JSON object');
  check(raw.schemaVersion===undefined||raw.schemaVersion===1,'Unsupported operation schema version');
  check(['add_cages','add_litters','wean_litters'].includes(raw.operation),'Choose one of the three supported operations');
  check(profile&&/^\d+$/.test(profile.id),'Select a profile from the signed-in account');
  required(profile.name,'Profile name',150);
  if(raw.profile){check(String(raw.profile.id)===profile.id,'Input profile ID does not match the selected profile');check(raw.profile.name===profile.name,'Input profile name does not match the selected profile');}
  const asOf=date(raw.asOf||today(),'Operation date');check(asOf<=today(),'Operation date cannot be in the future');
  const plan={schemaVersion:1,operation:raw.operation,profile:{id:profile.id,name:profile.name},asOf,data:structuredClone(raw.data)};
  check(record(plan.data),'Operation data must be an object');
  if(plan.operation==='add_cages'){
    const p=plan.data;check(Array.isArray(p.mice)&&p.mice.length>0,'Provide at least one mouse');check(Array.isArray(p.cages)&&p.cages.length>0,'Provide at least one cage');
    check(p.mice.length<=LIMITS.mice&&p.cages.length<=LIMITS.cages,'Batch limit: at most 250 mice and 100 cages');check(p.mice.every(record)&&p.cages.every(record),'Each mouse and cage must be an object');check(p.matings===undefined||Array.isArray(p.matings),'Matings must be an array');check((p.matings||[]).length<=LIMITS.matings&&(p.matings||[]).every(record),'Provide at most 100 mating objects');
    check(!p.mice.some(m=>m.sireKey||m.damKey),'Explicit pedigree editing is outside the new cage workflow; retain source parent details in comments');
    check(!p.litters?.length&&!(p.matings||[]).some(m=>m.litters?.length),'Adding cages does not create litter records; remove litter input');
    if(p.ownerId)check(String(p.ownerId)===profile.id,'Prepared cage input belongs to another owner');
    if(p.owner)check(p.owner===profile.name,'Prepared cage input owner name differs');
    p.matings=p.matings||[];
    unique(p.mice.map(m=>required(m.key,'Mouse key',80)),'Mouse keys');p.mice.forEach(physicalTag);unique(p.cages.map(c=>cageKey(required(c.tag,'Cage card'))),'Cage cards');
    for(const m of p.mice){check(['M','F'].includes(m.sex),'New cage mice require M or F');date(m.dob,'Mouse DOB');check(m.dob<=asOf,'Mouse DOB is in the future');check(['Stock','Mating'].includes(m.state),'New cage states must be Stock or Mating');required(m.strain,'Strain',150);text(m.protocol??'','Protocol',150);text(m.altId??'','Rack position',100);text(m.comment??'','Mouse comment');m.protocol=m.protocol??'';m.altId=m.altId??'';m.comment=m.comment??'';m.allele=m.allele??'';check(['','+/-','+/+','-/-','+','-','WT','fl/+','fl/-','fl/fl'].includes(m.allele),'Unsupported genotype');}
    const members=p.cages.flatMap(c=>{check(Array.isArray(c.members)&&c.members.length>0,'Each cage needs members');check(c.members.length<=5,'This release supports cages of at most five adults');return c.members;});
    unique(members,'Cage membership');check(members.length===p.mice.length&&members.every(k=>p.mice.some(m=>m.key===k)),'Each mouse must belong to exactly one cage');
    for(const c of p.cages)for(const k of c.members){const m=p.mice.find(m=>m.key===k);check(m.cageTag===c.tag,'Mouse cage card and cage membership differ');}
    for(const c of p.cages){const ms=c.members.map(k=>p.mice.find(m=>m.key===k));check(new Set(ms.map(m=>m.altId)).size===1,'A cage has conflicting rack positions');if(ms.every(m=>m.state==='Stock'))check(new Set(ms.map(m=>m.sex)).size===1,'Stock cage mixes sexes; use separate cages or specify a mating');}
    const breeders=[];for(const m of p.matings){required(m.tag,'Mating tag');date(m.setupDate,'Mating setup');check(m.setupDate<=asOf,'Mating setup is in the future');required(m.litterStrain,'Litter strain',150);check(Array.isArray(m.damKeys)&&m.damKeys.length>0&&m.damKeys.length<=2,'A mating supports one sire and one or two dams');const sire=p.mice.find(x=>x.key===m.sireKey);check(sire?.sex==='M','Mating sire is missing or not male');for(const k of m.damKeys){const dam=p.mice.find(x=>x.key===k);check(dam?.sex==='F','Mating dam is missing or not female');check(dam.cageTag===sire.cageTag,'Breeders must share the intended cage');check(dam.dob<=m.setupDate,'Dam DOB follows mating setup');}check(sire.dob<=m.setupDate,'Sire DOB follows mating setup');breeders.push(m.sireKey,...m.damKeys);m.comment=m.comment??'';text(m.comment,'Mating comment');m.litters=[];}
    unique(breeders,'Breeder membership');unique(p.matings.map(m=>m.tag),'Mating tags');check(p.mice.every(m=>(m.state==='Mating')===breeders.includes(m.key)),'Mating-state mice and mating assignments differ');
  }else{
    const rows=plan.data.litters;check(Array.isArray(rows)&&rows.length>0,'Provide at least one litter');check(rows.length<=LIMITS.litters,'Batch limit: at most 50 litters');check(rows.every(record),'Each litter must be an object');
    const identity=[];let totalPups=0;
    for(const l of rows){required(l.cageTag,'Source cage card');if(l.litterId)check(/^\d+$/.test(String(l.litterId)),'Invalid litter ID');if(l.tag)required(l.tag,'Litter tag');if(l.matingId)check(/^\d+$/.test(String(l.matingId)),'Invalid mating ID');
      if(plan.operation==='add_litters'){check(!l.damId&&!l.damIds&&!l.motherId&&!l.motherIds&&(!l.maternity||l.maternity==='unknown'),'Individual mother selection requires a separately reviewed workflow');date(l.birthDate,'Litter DOB');date(l.weanDate,'Planned wean date');check(l.birthDate<=asOf&&l.weanDate>=l.birthDate,'Invalid litter date order');check(l.pups===undefined||(Array.isArray(l.pups)&&l.pups.length===0),'Do not provide pups when adding a litter');l.comment=l.comment??'';text(l.comment,'Litter comment');identity.push([l.cageTag,l.matingId||'',l.birthDate].join('|'));}
      else{if(l.resumeWeaned!==undefined)check(typeof l.resumeWeaned==='boolean','resumeWeaned must be true or false');date(l.date,'Actual wean date');check(l.date<=asOf,'Wean date cannot be in the future');check(l.counts&&['male','female','unknown'].every(k=>Number.isInteger(l.counts[k])&&l.counts[k]>=0&&l.counts[k]<=25),'Each sex count must be an integer from zero to 25');check(Array.isArray(l.pups)&&l.pups.length>0,'Assign each weanling to a cage');check(l.pups.every(record),'Each pup must be an object');totalPups+=l.pups.length;check(totalPups<=LIMITS.weanlings,'Batch limit: at most 200 weanlings');check(JSON.stringify(counts(l.pups))===JSON.stringify({male:l.counts.male,female:l.counts.female,unknown:l.counts.unknown}),'Sex counts do not match the individual assignments');
        identity.push(l.litterId?`id:${l.litterId}`:[l.cageTag,l.tag||'',l.birthDate||''].join('|'));date(l.birthDate,'Litter DOB');check(l.date>=l.birthDate,'Wean date precedes litter DOB');
        for(const p of l.pups){check(['M','F','U'].includes(p.sex),'Weanling sex must be M, F, or U');physicalTag(p);if(p.existingMouseId)check(/^\d+$/.test(String(p.existingMouseId)),'Invalid existing mouse ID');const d=p.destination;check(d&&['new','existing'].includes(d.mode),'Choose a new or existing destination cage');required(d.tag,'Destination cage card');required(d.rackPosition,'Destination rack position',100);if(p.comment!==undefined)text(p.comment,'Mouse comment');}
        const groups=new Map();for(const p of l.pups){const d=p.destination;if(!groups.has(d.tag))groups.set(d.tag,[]);groups.get(d.tag).push(p);}for(const [tag,ps]of groups){check(ps.length<=5,`Destination ${tag} exceeds five animals`);check(new Set(ps.map(p=>p.sex)).size===1,`Destination ${tag} mixes sexes; use separate cages`);check(new Set(ps.map(p=>p.destination.rackPosition)).size===1,`Destination ${tag} has conflicting rack positions`);check(new Set(ps.map(p=>p.destination.mode)).size===1,`Destination ${tag} has conflicting new/existing choices`);}
      }
    }
    unique(identity,'Litter assignments');
  }
  return plan;
}
function summary(plan){return plan.operation==='add_cages'?{mice:plan.data.mice.length,cages:plan.data.cages.length,matings:plan.data.matings.length,litters:0}:plan.operation==='add_litters'?{litters:plan.data.litters.length,pups:0}:{litters:plan.data.litters.length,weanlings:plan.data.litters.reduce((n,l)=>n+l.pups.length,0),...Object.fromEntries(['male','female','unknown'].map(k=>[k,plan.data.litters.reduce((n,l)=>n+l.counts[k],0)]))};}
module.exports={LIMITS,validate,summary,digest,today,check,counts};
