'use strict';
// Deterministic text-to-draft conversion. No writes to SoftMouse and no guessing.
const {check,validate,today}=require('./contracts.cjs');
const {v,dateISO}=require('./softmouse.cjs');
const field=(r,k)=>v(r.fields,k);
function date(value){
 value=String(value).trim();let y,m,d,match;
 if((match=/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/.exec(value)))[,y,m,d]=match;
 else if((match=/^(\d{1,2})[-/](\d{1,2})[-/](\d{2}|\d{4})$/.exec(value))){[,m,d,y]=match;if(y.length===2)y='20'+y;}
 else throw Error('Use a complete month/day/year date, or YYYY-MM-DD: '+value);
 const iso=`${y}-${m.padStart(2,'0')}-${d.padStart(2,'0')}`;
 check(!Number.isNaN(Date.parse(iso+'T12:00:00Z'))&&new Date(iso+'T12:00:00Z').toISOString().slice(0,10)===iso,'Invalid date: '+value);return iso;
}
const {cageKey}=require('./identifiers.cjs');
function value(line,label){return line.replace(new RegExp('^(?:'+label+')\\s*:\\s*','i'),'').trim();}
function sexCounts(line){
 const parts=[...line.toUpperCase().matchAll(/(\d+)\s*([MFU])/g)];
 check(parts.length&&line.toUpperCase().replace(/\d+\s*[MFU]/g,'').replace(/[\s,;+]/g,'')==='','Use counts such as 2M 3F 0U');
 const result={male:0,female:0,unknown:0},seen=new Set();
 for(const p of parts){check(!seen.has(p[2]),'A sex count appears twice');seen.add(p[2]);check(Number(p[1])<=25,'Each sex count must be between zero and 25');result[{M:'male',F:'female',U:'unknown'}[p[2]]]=Number(p[1]);}
 check(Object.values(result).reduce((a,b)=>a+b,0)>0,'A destination needs at least one pup');return result;
}
function parse(text,operation){
 check(typeof text==='string'&&text.length<=20000,'Provide at most 20,000 characters of short instructions');
 const lines=text.replace(/\r\n?/g,'\n').split('\n').map(s=>s.trim()).filter(Boolean);
 const header=/^(litter|birth|wean|weaning)$/i.exec(lines[0]||'');
 if(header){const inferred=/^(litter|birth)$/i.test(header[1])?'add_litters':'wean_litters';check(!operation||operation===inferred,'Instruction heading differs from selected workflow');operation=inferred;lines.shift();}
 check(['add_litters','wean_litters'].includes(operation),'Choose Add litters or Wean litters');
 check(lines.length>=3,'Provide source cage and dates');
 let earlyDOB;
 if(operation==='wean_litters'){const positions=lines.map((line,i)=>/^dob\s*:/i.test(line)?i:-1).filter(i=>i>=0);check(positions.length<=1,'Litter DOB appears twice');if(positions.length){earlyDOB=date(value(lines.splice(positions[0],1)[0],'dob'));}else if(/^\d{1,4}[-/]\d{1,2}[-/]\d{2,4}$/.test(lines[0]||'')){earlyDOB=date(lines.shift());}}
 const source=value(lines.shift(),'cage|parent|source(?: cage)?');check(source&&source.length<=25,'Invalid source cage');
 if(operation==='add_litters'){
  check(!lines.some((line,i)=>/^(litter|birth|wean|weaning)$/i.test(line)&&lines.length-i>=4),'Paste one operation message at a time; use batch JSON for multiple litters');
  const birthDate=date(value(lines.shift(),'dob|birth(?: date)?')),weanDate=date(value(lines.shift(),'wean(?: date)?|planned wean(?: date)?'));
  return {operation,source,birthDate,weanDate,comment:lines.join('\n').replace(/^comment\s*:\s*/i,'')};
 }
 const actualDate=date(value(lines.shift(),'date|wean(?:ed)?(?: date)?'));let birthDate=earlyDOB,tag;const destinations=[];
 while(lines.length){
  if(/^dob\s*:/i.test(lines[0])){check(!birthDate,'Litter DOB appears twice');birthDate=date(value(lines.shift(),'dob'));continue;}
  if(/^litter\s*:/i.test(lines[0])){check(!tag,'Litter tag appears twice');tag=value(lines.shift(),'litter');check(tag,'Litter tag is empty');continue;}
  check(lines.length>=3,'Each destination needs a cage, sex counts and rack position');
  const destination=value(lines.shift(),'destination|cage');check(destination&&destination.length<=25,'Invalid destination cage');
  const counts=sexCounts(value(lines.shift(),'counts')),rackPosition=value(lines.shift(),'rack|alt(?: id)?');check(rackPosition,'Rack position is required');
  const group={tag:destination,counts,rackPosition,tags:{}};
  while(lines.length&&/^(comment|[MFU](?:\s+tags)?)\s*:/i.test(lines[0])){
   const line=lines.shift(),m=/^([MFU])(?:\s+tags)?\s*:\s*(.*)$/i.exec(line);
   if(m){const sex=m[1].toUpperCase();check(!group.tags[sex],'Tag list appears twice for '+sex);group.tags[sex]=m[2].split(';').map(x=>x.trim());}
   else{check(group.comment===undefined,'Group comment appears twice');group.comment=value(line,'comment');}
  }
  check(Object.values(counts).filter(n=>n>0).length===1,'Each destination must contain one sex only: use xM, yF or zU');destinations.push(group);
 }
 check(birthDate,'Litter DOB is required. Put DOB: month/day/year directly below wean.');check(destinations.length,'Provide at least one destination cage');return {operation,source,date:actualDate,birthDate,tag,destinations};
}
function matches(rows,key){return rows.filter(r=>cageKey(field(r,'cagetag'))===cageKey(key));}
async function convert(parsed,profiles,read){
 const inventories=[];
 // Read every profile accessible to this login; never infer ownership from prefix.
 for(const profile of profiles)inventories.push({profile,cages:await read('cages',profile)});
 const sources=inventories.flatMap(p=>matches(p.cages,parsed.source).map(cage=>({...p,cage})));
 check(sources.length===1,sources.length?'Source cage is ambiguous across accessible profiles: '+sources.map(s=>s.profile.name+' ('+s.profile.id+'): '+field(s.cage,'cagetag')).join('; '):'Source cage was not found in accessible profiles: '+parsed.source);
 const selected=sources[0],profile=selected.profile,cageTag=field(selected.cage,'cagetag'),issues=[];
 const input={schemaVersion:1,operation:parsed.operation,profile,asOf:today(),data:{litters:[]}};
 if(parsed.operation==='add_litters'){
  const matings=(await read('matings',profile)).filter(r=>field(r,'state')==='Active'&&field(r,'cagetag').split(/\s+/).includes(cageTag));
  check(matings.length===1,'Source cage needs one unambiguous active mating');
  input.data.litters.push({cageTag,matingId:matings[0].id,birthDate:parsed.birthDate,weanDate:parsed.weanDate,comment:parsed.comment});
 }else{
  const litters=(await read('litters',profile)).filter(r=>field(r,'litterstate')==='Active'&&field(r,'mothercagetag').split(/\s+/).includes(cageTag)&&(!parsed.birthDate||dateISO(field(r,'dateofbirth'))===parsed.birthDate)&&(!parsed.tag||field(r,'littertag')===parsed.tag));
  check(litters.length===1,litters.length?'Multiple active litters match. Add DOB: month/day/year or Litter: tag.':'No matching active litter in the source cage');
  const litter={cageTag,litterId:litters[0].id,birthDate:dateISO(field(litters[0],'dateofbirth')),date:parsed.date,counts:{male:0,female:0,unknown:0},pups:[]};
  const seenDestinations=new Set();
  for(const group of parsed.destinations){
   const key=cageKey(group.tag);check(!seenDestinations.has(key),'Destination appears twice: '+group.tag);seenDestinations.add(key);
   const found=matches(selected.cages,group.tag);check(found.length<=1,'Destination cage is ambiguous: '+group.tag);
   if(!found.length)check(!inventories.filter(p=>p.profile.id!==profile.id).some(p=>matches(p.cages,group.tag).length),'Destination belongs to another profile: '+group.tag);
   const destination={tag:found.length?field(found[0],'cagetag'):group.tag,rackPosition:group.rackPosition,mode:found.length?'existing':'new'};
   for(const [sex,label]of [['M','male'],['F','female'],['U','unknown']]){
    const count=group.counts[label];litter.counts[label]+=count;
    if(group.tags[sex])check(group.tags[sex].length===count&&group.tags[sex].every(Boolean),`Destination ${group.tag}: ${sex} tags must match its count`);
    for(let i=0;i<count;i++){const tag=group.tags[sex]?.[i]||'';litter.pups.push({sex,tag,destination:{...destination},...(group.comment!==undefined?{comment:group.comment}:{})});}
   }
  }
  input.data.litters.push(litter);
 }
 // Physical tags are optional; permanent IDs are reserved only at preparation.
 validate(input,profile);
 return {input,issues,complete:issues.length===0,scannedProfiles:inventories.map(p=>p.profile)};
}
module.exports={date,cageKey,sexCounts,parse,convert};
