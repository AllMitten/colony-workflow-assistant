# Short instructions

Use **Short instructions → Convert to JSON** under Add litters or Wean litters. Conversion reads accessible profiles and lists; it does not create records or authorize a save. Review the generated JSON, then use the existing backup/review/save process.

## Birth

```text
litter
CCB11111
10/1/26
10/22/26
Optional comment
```

Lines: operation, parent cage, DOB, planned wean date, optional comment. Comments can span lines. The source cage must resolve to one active mating. Births have zero individual pups.

## Weaning

```text
wean
DOB: 10/1/26
CCB11111
10/22/26
CCB22222
2M
I-A
M tags: TAG1; TAG2
comment: Optional comment for these two mice
CCB33333
1F
I-B
F tags: TAG3
```

Lines: operation, required litter DOB, parent cage, actual wean date, then repeated destination blocks. Each block is destination cage, sex counts, rack position (Alt ID), optional tag lists, optional comment. The block comment applies to its pups. Use separate destination cages for different sexes in the current release.

Always provide `DOB: ...`, preferably directly below `wean`. An unlabeled date directly below `wean` is also accepted. A `Litter: exact-tag` line can further distinguish two active litters from the same cage and DOB. The converter never selects the oldest or newest silently.

Tag lists use **semicolons**, because punctuation such as commas, apostrophes and periods belongs to physical ear-punch tags. `M tags: ,'..,.'; '.''.'.` contains two literal tags. `M:`, `F:` and `U:` are also accepted. Tags must match the sex counts. Tag lists are optional. If omitted, physical tags stay blank and the app reserves permanent i/I/| IDs at preparation. Birth records create no individual pups or IDs. Known physical markings are retained as a prefix to the ID; see MOUSE-IDS.md.

## Normalization and limits

- `1/1/26`, `01/01/2026`, `1-1-26` and `2026-01-01` mean the same date. Slash/dash dates with the year last use **US month/day/year**; `1/2/26` means January 2. Two-digit years mean 2000–2099. A year is required; impossible dates fail.
- Numeric cage tags accept a one-to-three-letter prefix, case-insensitively: `CCB11111` matches `11111`. Leading zeros are preserved. Non-numeric tags such as `IT28-7A38-C1` require the full tag (case-insensitive matching).
- Prefix removal is a lookup rule only. The saved source/existing destination uses its exact SoftMouse tag. Multiple matches across or within accessible profiles stop with an error, even if one spelling is exact.
- A profile need not appear in the message. Conversion scans profiles discoverable by this signed-in account and binds the unique source cage's profile into the JSON. It cannot access profiles the account cannot view. Real multi-profile behavior still needs supervised acceptance.
- Existing destinations are matched within the source profile; known destinations in another profile stop. A destination absent from all scanned cages is treated as new and retains its supplied tag. The result shows `new` or `existing` for review.
- Blank lines, surrounding spaces, header case and lowercase sex letters are accepted. Use one sex per destination, e.g. `2M`, `3F` or `1U`. Zero counts for other sexes may be included, but mixing positive M/F/U counts in one cage is rejected. Unspecified sex counts mean zero. Arbitrary spelling correction, omitted years, inferred cage digits and free-form natural-language interpretation are not supported.
- No Slack connection or automatic execution is enabled. This module provides deterministic conversion for future integrations. A message is input, not authority to bypass profile checks, backups or confirmation.

This source distribution includes only placeholder JSON examples in app/examples. These text examples also use placeholder cages; do not submit them as real instructions.


## Fast mode

Fast mode is unchecked by default and resets on page reload. Tick it and click **Run** after pasting short instructions. The app identifies the unique source profile, converts the text, creates a draft, validates it, takes the four official Excel backups, saves and verifies without a review dialog or typed-profile confirmation. Prepared JSON and regular forms can also use Fast mode with an explicitly selected matching profile.

The Run click authorizes that submitted input and resolved profile. Ambiguous matches, missing data, failed exports, changed baselines, identity/capacity checks and uncertain saves still stop the operation. Fast mode uses the ordinary guarded save path and never retries a save automatically. Restarted operations require reconciliation; no background continuation is scheduled. Fast mode removes manual steps, not backup/verification time. History records the mode and input hash. Use the standard unchecked mode when a manual review is wanted.
