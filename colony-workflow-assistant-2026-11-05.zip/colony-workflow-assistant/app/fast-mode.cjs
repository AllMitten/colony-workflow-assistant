'use strict';
const {check}=require('./contracts.cjs');
function authorize(store,op,{fastMode,inputHash}){
 const state=store.get(op);
 check(fastMode===true,'Fast mode must be explicitly selected');
 check(state.status==='draft','Fast mode requires a fresh draft; completed or interrupted operations cannot be replayed');
 check(!state.fastAuthorizedAt,'Fast mode was already authorized for this operation; do not replay the request');
 check(typeof inputHash==='string'&&inputHash===state.inputHash,'Fast mode input differs from the submitted draft');
 store.update(op,{executionMode:'fast',fastAuthorizedAt:new Date().toISOString(),fastAuthorizedInputHash:inputHash});
 store.event(op,'fast_mode_authorized',{profile:state.profile,inputHash,message:'Fast mode selected: validate, back up, save and verify without manual review.'});
}
async function execute(store,runner,op){
 try{
  const state=store.get(op);
  check(state.executionMode==='fast'&&state.fastAuthorizedInputHash===state.inputHash,'Fast mode authorization is missing or changed');
  const prepared=await runner.prepare(op);
  check(!runner.stop,'Stopped before saving');
  const ready=store.get(op);
  check(ready.status==='ready'&&ready.inputHash===state.fastAuthorizedInputHash,'Prepared input does not match fast mode authorization');
  check(ready.profile.id===state.profile.id&&ready.profile.name===state.profile.name,'Profile changed during preparation');
  store.event(op,'fast_mode_validated',{profile:ready.profile,message:'Backups and validation passed. Continuing to save in fast mode.'});
  // Use the same protected run path as reviewed mode: token expiry, frozen
  // input/assignments, fresh baseline, request guard and saved-record checks.
  return await runner.run(op,prepared.token,ready.profile.name);
 }catch(e){
  const state=store.get(op);
  if(['draft','ready','validating'].includes(state.status)){
   store.update(op,{status:'blocked',approvalTokenHash:null,error:e.message,message:'Stopped: '+e.message});
   store.event(op,'fast_mode_stopped',{message:e.message});
  }
  // No retry, rollback, confirmation bypass, or restart continuation.
  throw e;
 }
}
module.exports={authorize,execute};
