'use strict';
const {check}=require('./contracts.cjs');
function inspectRequest(request,profile,allowedIds,commit,stopped){
 const u=new URL(request.url());if(u.hostname!=='www.softmouse.net')return false;
 if(request.method()==='GET'&&/\.(?:js|css|png|jpe?g|gif|svg|ico|woff2?|ttf|map)$/i.test(u.pathname))return false;
 const values=[...u.searchParams];const body=request.postData()||'';
 const visit=(value,key='')=>{if(Array.isArray(value)){for(const v of value)visit(v,key);}else if(value&&typeof value==='object'){for(const [k,v]of Object.entries(value))visit(v,k);}else values.push([key,String(value??'')]);};
 if(body.trim().startsWith('{')||body.trim().startsWith('['))visit(JSON.parse(body));else for(const [k,v]of new URLSearchParams(body)){if(/^[\[{]/.test(v.trim())){try{visit(JSON.parse(v));}catch{values.push([k,v]);}}else values.push([k,v]);}
 const dangerous=/(?:delete|disband|sacrifice|euthan|archive|transfer|retire|endmouse|endcage|endlitter)/i;
 const readEndpoint=/(?:list|filter|search|check|lookup|get|permission|columns|validate)/i.test(u.pathname.split('/').at(-1));
 check((!dangerous.test(u.pathname)||readEndpoint)&&!values.some(([k,v])=>/^reqCode$|^dispatch$/i.test(k)&&dangerous.test(v)),'Ending, deleting or transferring records is outside these workflows: '+u.pathname);
 if(request.method()==='GET')check(!values.some(([k,v])=>/^(?:reqCode|dispatch|action)$/i.test(k)&&/^(?:save|create|update|apply|wean|add)/i.test(v)),'Unexpected save through a navigation URL');
 const write=request.method()!=='GET'&& !/\/(?:[^/]*(?:list|filter|search|check|lookup|get|permission|columns|validate)[^/]*)$/i.test(u.pathname)&& !/^\/cdn-cgi\//.test(u.pathname);
 if(!write)return false;
 check(commit,'Save blocked before profile, backup and confirmation checks');check(!stopped,'Stop requested');
 for(const [key,val]of values){
  if(/(?:^|\.)(?:ownerId|litterOwnerId|ownerCode|switchedOwnerId)$/i.test(key)&&val&&val!=='-1')check(val===profile.id,'A save targeted another profile');
  if(/^(?:mouseIds?|litterIds?|matingIds?|cageIds?)$/i.test(key)&&val)for(const id of val.split(/[,\s]+/).filter(Boolean))check(['0','-1'].includes(id)||allowedIds.has(id),'A save targeted a record outside the verified profile: '+key);
 }
 return true;
}
module.exports={inspectRequest};
