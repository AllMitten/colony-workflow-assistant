# Stress checks

The bundled test suite covers input boundaries, calendar cases, duplicate handling, ID allocation, local history/load, UI mistakes, and interrupted/uncertain requests using synthetic data. The remote SoftMouse service is not load-tested. Run npm.cmd test for the full packaged suite or npm.cmd run test:stress for the focused subset. Original run evidence and lab data are not distributed. Read ../VALIDATION.md for actual package results and remaining limits.
