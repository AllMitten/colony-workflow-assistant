'use strict';
// Read cached Excel values for backup verification. Never executes formulas/macros.
const fs=require('node:fs');
const zlib=require('node:zlib');
const assert=require('node:assert/strict');
const xml=s=>s.replace(/&(?:amp|lt|gt|quot|apos);|&#(?:x[\da-f]+|\d+);/gi,x=>({'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&apos;':"'"}[x]??String.fromCodePoint(parseInt(x.slice(2,-1).replace(/^x/i,''),/^&#x/i.test(x)?16:10))));
function read(file){
 const b=fs.readFileSync(file);assert.ok(b.length>22&&b.readUInt32LE(0)===0x04034b50,'Backup is not an XLSX workbook');
 let end=-1;for(let p=b.length-22;p>=Math.max(0,b.length-65557);p--)if(b.readUInt32LE(p)===0x06054b50){end=p;break;}assert.ok(end>=0,'Invalid workbook ZIP');
 const count=b.readUInt16LE(end+10);let offset=b.readUInt32LE(end+16);const files=new Map();
 for(let n=0;n<count;n++){assert.equal(b.readUInt32LE(offset),0x02014b50);const method=b.readUInt16LE(offset+10),size=b.readUInt32LE(offset+20),nameLen=b.readUInt16LE(offset+28),extra=b.readUInt16LE(offset+30),comment=b.readUInt16LE(offset+32),start=b.readUInt32LE(offset+42),name=b.subarray(offset+46,offset+46+nameLen).toString();if(name==='xl/sharedStrings.xml'||/^xl\/worksheets\/sheet\d+\.xml$/.test(name)){const dataStart=start+30+b.readUInt16LE(start+26)+b.readUInt16LE(start+28);const compressed=b.subarray(dataStart,dataStart+size);files.set(name,(method===8?zlib.inflateRawSync(compressed,{maxOutputLength:50*1024*1024}):compressed).toString('utf8'));}offset+=46+nameLen+extra+comment;}
 const texts=s=>[...s.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(m=>xml(m[1])).join('');
 const strings=[...(files.get('xl/sharedStrings.xml')||'').matchAll(/<si(?:\s[^>]*)?>([\s\S]*?)<\/si>/g)].map(m=>texts(m[1]));
 const sheets=[...files.keys()].filter(s=>/^xl\/worksheets\//.test(s)).sort();assert.equal(sheets.length,1,'Expected one worksheet in the exported backup');const rows=[];
 for(const row of files.get(sheets[0]).matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>/g)){const values=[];for(const cell of row[1].matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)){const ref=/\br="([A-Z]+)\d+"/.exec(cell[1]);if(!ref)continue;let col=0;for(const x of ref[1])col=col*26+x.charCodeAt(0)-64;const body=cell[2]||'',type=/\bt="([^"]+)"/.exec(cell[1])?.[1],raw=/<v[^>]*>([\s\S]*?)<\/v>/.exec(body)?.[1]||'';values[col-1]=type==='s'?strings[Number(raw)]||'':type==='inlineStr'?texts(body):xml(raw);}rows.push(values);}
 assert.ok(rows.length,'Backup has no header row');return {headers:rows[0],rows:rows.slice(1).filter(r=>r.some(x=>String(x||'').trim()))};
}
module.exports={read};
