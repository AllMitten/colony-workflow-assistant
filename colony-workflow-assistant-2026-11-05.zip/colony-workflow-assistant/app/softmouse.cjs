'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const {visibleClick}=require('./browser.cjs');
const {readRows,fieldValue:v,selectLabel}=require('../softmouse-batch.cjs');
const {clickFill,setCalendarDate,dateISO}=require('../softmouse-one-male.cjs');
const {digest}=require('./contracts.cjs');
const store=require('./store.cjs');
const CONFIG={
 strains:{path:'/smdb/mouseline/list.do?reqCode=gotoMouselinelist',grid:'mouseline_table',name:'StrainList',state:'mouselineStateId',export:'exportMouseLineMenuButton',header:'Name'},
 mice:{path:'/smdb/mouse/list.do',grid:'mouseTable',name:'MouseList',state:'mouseStates',export:'exportMouseMenuButton',header:'Physical Tag'},
 matings:{path:'/smdb/mating/list.do?reqCode=gotoMatingList',grid:'matinglist_table',name:'BreedingList',state:'matingState',export:'exportMatingMenuButton',header:'Mating SID'},
 litters:{path:'/smdb/litter/list.do',grid:'litter_table',name:'LitterList',state:'litterStates',export:'exportLitterMenuButton',header:'Litter SID'},
 cages:{path:'/smdb/cage/list.do',grid:'cage_table',name:'CageList',state:'cageStates'}
};
async function setOwner(page,profile){
 const plural=page.locator('select#ownerIds, select#ownerId[multiple]');
 if(await plural.count()){
   const button=plural.locator('xpath=following-sibling::button[1]');await button.click();const menu=page.locator('.ui-multiselect-menu:visible');
   const boxes=menu.locator('input[type="checkbox"]');let found=false;
   for(const box of await boxes.all()){const value=await box.inputValue();const desired=value===profile.id;if(desired)found=true;if(await box.isChecked()!==desired)await box.setChecked(desired);}
   assert.ok(found,'Selected profile is unavailable in this list filter');await button.click();
   assert.deepEqual(await plural.evaluate(e=>Array.from(e.selectedOptions).map(o=>o.value)),[profile.id]);
 }else{
   const one=page.locator('#ownerId');assert.ok(await one.count(),'Cannot identify the list owner filter');await one.click();await one.selectOption(profile.id);assert.equal(await one.inputValue(),profile.id);
 }
}
async function waitGrid(page,cfg,data){
 assert.ok(Array.isArray(data.list),'SoftMouse returned an invalid grid');
 await page.waitForFunction(({grid,ids})=>{const rows=Array.from(document.querySelectorAll(`#${grid} tr.jqgrow`));return rows.length===ids.length&&rows.every((r,i)=>r.id===ids[i]);},{grid:cfg.grid,ids:data.list.map(r=>String(r.id))});
}
function gridResponse(page,cfg,pageNumber){return page.waitForResponse(async r=>{if(r.request().resourceType()!=='xhr')return false;const u=new URL(r.url());const segment=cfg.path.split('/')[2];if(!u.pathname.toLowerCase().includes('/'+segment.toLowerCase()+'/'))return false;if(pageNumber&&Number(u.searchParams.get('page')||new URLSearchParams(r.request().postData()||'').get('page'))!==pageNumber)return false;try{const data=await r.json();return data.records!==undefined&&Array.isArray(data.list);}catch{return false;}});}
async function list(page,kind,profile){
 const cfg=CONFIG[kind];await page.goto('https://www.softmouse.net'+cfg.path+(kind==='strains'?'&ownerCode='+profile.id:''));
 await page.locator('#editOpenCloseImage').waitFor();await page.waitForLoadState('networkidle');
 const clear=page.locator('#filterClear, #clearFilter');
 if(!await clear.isVisible())await page.locator('#editOpenCloseImage').click();
 await clear.click();await setOwner(page,profile);
 const state=page.locator('#'+cfg.state);
 if(await state.count()){
   const button=page.locator('#'+cfg.state+' + button');
   if(await button.count()){await button.click();const all=page.locator('.ui-multiselect-menu:visible label').filter({hasText:/^All$/});if(await all.count()&&!await all.locator('input').isChecked())await all.click();await button.click();}
   else{const opts=await state.locator('option').evaluateAll(es=>es.map(o=>({v:o.value,t:o.textContent.trim()})));const all=opts.find(o=>/^all$/i.test(o.t));if(all)await state.selectOption(all.v);}
 }
 if(kind==='mice'&&await page.locator('#filterMode + button').count()){
   await page.locator('#filterMode + button').click();const all=page.locator('.ui-multiselect-menu:visible label').filter({hasText:/^All$/});if(await all.count()&&!await all.locator('input').isChecked())await all.click();await page.locator('#filterMode + button').click();
 }
 const responseP=gridResponse(page,cfg);await page.locator('#filterApply, #applyFilter').click();const response=await responseP;assert.ok(response.ok(),'Unable to read '+kind);const first=await response.json();assert.equal(Number(first.page||1),1,'List did not reset to page one');await waitGrid(page,cfg,first);
 const rows=await readRows(page.locator('#'+cfg.grid+' tr.jqgrow'));
 for(let n=2;n<=Number(first.total||0);n++){const next=page.locator(`#next_t_${cfg.grid}_toppager`);const rp=gridResponse(page,cfg,n);await next.click();const res=await rp;assert.ok(res.ok());const data=await res.json();assert.equal(Number(data.records),Number(first.records),'Records changed while reading pages');await waitGrid(page,cfg,data);const more=await readRows(page.locator('#'+cfg.grid+' tr.jqgrow'));assert.ok(more.every(r=>!rows.some(old=>old.id===r.id)),'Duplicate list pages');rows.push(...more);}
 assert.equal(rows.length,Number(first.records),'Incomplete '+kind+' list');
 for(const r of rows){const owner=Object.entries(r.fields).find(([key])=>/_ownerid$/i.test(key));if(owner)assert.equal(owner[1],profile.id,`Another profile appeared in the ${kind} list`);}
 return rows;
}
async function snapshot(page,profile,stage=()=>{}){const result={};for(const kind of Object.keys(CONFIG)){stage('reading',{message:'Checking '+CONFIG[kind].name.replace('List',' list')+' for '+profile.name+'.'});result[kind]=await list(page,kind,profile);}return result;}
function business(snapshot){const omit=/_(?:age|fage|mage|timeSinceSetup|timeSinceLastLitter|daysSinceLastLitter|color|colorrow|cb)$/i;return Object.fromEntries(Object.entries(snapshot).sort().map(([k,rows])=>[k,rows.map(r=>({id:r.id,fields:Object.fromEntries(Object.entries(r.fields).filter(([name])=>!omit.test(name)).sort(([a],[b])=>a.localeCompare(b)))})).sort((a,b)=>a.id.localeCompare(b.id))]));}
function fingerprint(snapshot){return digest(business(snapshot));}
async function openNew(page,profile){await page.goto('https://www.softmouse.net/smdb/mouse/list.do');await visibleClick(page,page.getByRole('link',{name:'New Animals',exact:true}));await page.locator('#ownerId').waitFor();await page.locator('#ownerId').click();await page.locator('#ownerId').selectOption(profile.id);await page.waitForLoadState('networkidle');assert.equal(await page.locator('#ownerId').inputValue(),profile.id);assert.equal(await page.locator('#batchPreviewTable tr.jqgrow').count(),0,'An unfinished animal preview must be reviewed first');}
async function catalogs(page,profile){await openNew(page,profile);const options=selector=>page.locator(selector+' option').evaluateAll(es=>es.map(e=>({id:e.value,label:e.textContent.trim()})));return {strains:await options('#mouselineId'),protocols:await options('#protocolId'),racks:await options('#mouseEarmarkId'),capabilities:{protocols:await page.locator('#protocolId').isEnabled()}};}
function requireCatalog(catalog,label,field){assert.equal(catalog.filter(x=>x.label===label).length,1,`Missing or ambiguous ${field}: ${label||'(blank)'}`);}
async function submitWeaning(page,litterId){
 // SoftMouse starts an AJAX save and then reloads this same URL. An already-idle
 // document is not evidence that either event finished; subscribe before click.
 const [response]=await Promise.all([
  page.waitForResponse(r=>new URL(r.url()).pathname==='/mouse/wean'&&r.request().method()==='POST',{timeout:30000}),
  page.waitForNavigation({waitUntil:'networkidle',timeout:30000}),
  page.locator('#weanPupsActionApply').click()
 ]);
 assert.ok(response.ok(),'SoftMouse rejected the weaning request');
 const u=new URL(page.url());assert.equal(u.pathname,'/smdb/litter/edit.do');assert.equal(u.searchParams.get('litterId'),String(litterId),'Weaning returned to a different litter');
}
function verifyWorkbook(kind,parsed,rows){
 const columns={strains:[['Name','name']],mice:[['Physical Tag','physicaltag'],['Sex','sex'],['Date of Birth','dateofbirth'],['Cage Tag','cagetag'],['Strain','mouseline']],matings:[['Mating SID','matingsid'],['Litter Strain','mouseline'],['Set up Date','setupdate']],litters:[['Litter SID','littersid'],['Date of Birth','dateofbirth'],['Wean Date','weandate'],['Strain','mouseline']]}[kind];
 const norm=(value,key)=>{let s=String(value??'').replace(/\s+/g,' ').trim();if(key==='sex')s=({Male:'M',Female:'F',Unknown:'U'})[s]||s;return s;};
 const indices=columns.map(([label])=>{const i=parsed.headers.indexOf(label);assert.ok(i>=0,'Missing export column: '+label);return i;});
 const exported=parsed.rows.map(r=>JSON.stringify(columns.map(([,key],i)=>norm(r[indices[i]],key)))).sort();
 const expected=rows.map(r=>JSON.stringify(columns.map(([,key])=>norm(v(r.fields,key),key)))).sort();
 assert.deepEqual(exported,expected,'Excel backup identities differ from the selected profile inventory');
}
async function downloadList(session,kind,profile,op,rows){
 const page=session.page,cfg=CONFIG[kind];
 // The official export popup performs the download after preparing its workbook.
 const popupP=session.context.waitForEvent('page');popupP.catch(()=>{});let timer,listener,popup;
 const downloadP=new Promise((resolve,reject)=>{listener=p=>{p.once('download',d=>resolve({p,d}));};session.context.once('page',listener);timer=setTimeout(()=>{session.context.off('page',listener);reject(Error('Excel export timed out for '+kind));},120000);timer.unref();});downloadP.catch(()=>{});
 try{let target=page.locator('#'+cfg.export);
 if(!await target.count()){
   const observed=await page.locator('span[title]').evaluateAll(es=>es.filter(e=>/^Export .*spreadsheet/i.test(e.title)).map(e=>e.closest('a')?.id).filter(Boolean));assert.equal(observed.length,1,'Cannot uniquely identify the official Excel export');target=page.locator('#'+observed[0]);
 }
 await visibleClick(page,target);popup=await popupP;
 const {d}=await downloadP;const filename=d.suggestedFilename();assert.ok(/\.xlsx$/i.test(filename),'SoftMouse did not export XLSX');const dir=path.join(store.DATA,'backups',profile.id,op);fs.mkdirSync(dir,{recursive:true});const file=path.join(dir,cfg.name+'-'+store.stamp()+'.xlsx');
   try{await d.saveAs(file);assert.equal(await d.failure(),null,'Workbook download failed');}
   catch{const resource=new URL(d.url());assert.equal(resource.origin,'https://www.softmouse.net');assert.equal(resource.pathname,'/export/downLoadFile','Unexpected export resource');const response=await session.context.request.get(resource.href);assert.ok(response.ok(),'Official export file could not be downloaded');fs.writeFileSync(file,await response.body());}
   const parsed=require('./xlsx.cjs').read(file);assert.ok(parsed.headers.includes(cfg.header),'Unexpected workbook columns for '+kind);assert.equal(parsed.rows.length,rows.length,'Excel backup row count does not match the selected profile inventory');verifyWorkbook(kind,parsed,rows);return {kind,file:path.relative(store.ROOT,file),rows:parsed.rows.length,sha256:crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),sourceFilename:filename,profile};}
 finally{clearTimeout(timer);session.context.off('page',listener);if(popup&&!popup.isClosed())await popup.close();}
}
async function backups(session,profile,op,stage){const snapshot={};const manifest={operationId:op,profile,createdAt:new Date().toISOString(),files:[]};for(const kind of ['strains','mice','matings','litters']){stage('backup_progress',{message:'Saving '+CONFIG[kind].name.replace('List',' list')+' Excel backup.'});snapshot[kind]=await list(session.page,kind,profile);manifest.files.push(await downloadList(session,kind,profile,op,snapshot[kind]));}snapshot.cages=await list(session.page,'cages',profile);manifest.fingerprint=fingerprint(snapshot);const dir=path.join(store.DATA,'backups',profile.id,op);store.atomic(path.join(dir,'manifest.json'),manifest);store.atomic(path.join(dir,'snapshot.json'),snapshot);return {manifest,snapshot};}
async function selectProtocol(locator,label){if(await locator.isDisabled()){const current=await locator.locator('option:checked').innerText();assert.ok(!label&&current.trim()==='', 'Protocol assignment is disabled in this account/edition. Requested protocol was not omitted.');return;}await selectLabel(locator,label);}
async function previewMice(page,profile,mice){
 await openNew(page,profile);
 for(let i=0;i<mice.length;i++){const m=mice[i];await page.getByRole('button',{name:'Reset',exact:true}).click();assert.equal(await page.locator('#ownerId').inputValue(),profile.id);for(const [sel,sex]of [['#sizeMale','M'],['#sizeFemale','F'],['#sizeUnknown','U']])await clickFill(page.locator(sel),m.sex===sex?'1':'0');await selectLabel(page.locator('#mouselineId'),m.strain);await selectProtocol(page.locator('#protocolId'),m.protocol||'');await setCalendarDate(page,page.locator('#birthDatePicker'),m.dob,()=>page.locator('#birthDatePicker').click());await clickFill(page.locator('#tagPrefix'),m.tag);await clickFill(page.locator('#tagStartIndex'),'');await selectLabel(page.locator('#mouseEarmarkId'),m.altId||'');await clickFill(page.locator('#comment'),m.comment||'');if(m.allele){await selectLabel(page.locator('#alleleId'),m.allele);await page.getByRole('button',{name:/Add to Genotype/}).click();}else assert.equal(await page.locator('#genotype option').count(),0);
 await page.getByRole('button',{name:'Add',exact:true}).click();await page.waitForFunction(n=>document.querySelectorAll('#batchPreviewTable tr.jqgrow').length===n,i+1);const rows=await readRows(page.locator('#batchPreviewTable tr.jqgrow'));for(const p of mice.slice(0,i+1))assert.equal(rows.filter(r=>require('../softmouse-batch.cjs').mouseMatches(r.cells,p)).length,1,'Animal preview differs from approved input');}
}
module.exports={CONFIG,setOwner,list,snapshot,business,fingerprint,openNew,catalogs,requireCatalog,backups,downloadList,verifyWorkbook,submitWeaning,selectProtocol,previewMice,v,clickFill,setCalendarDate,dateISO,selectLabel,readRows};
