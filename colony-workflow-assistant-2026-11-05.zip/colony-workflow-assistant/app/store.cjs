'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const ROOT=path.resolve(__dirname,'..');
const DATA=process.env.NODE_ENV==='test'&&process.env.SOFTMOUSE_TEST_DATA_DIR?path.resolve(process.env.SOFTMOUSE_TEST_DATA_DIR):path.join(ROOT,'lab-data');
for(const dir of ['operations','backups'])fs.mkdirSync(path.join(DATA,dir),{recursive:true});
function stamp(now=new Date()){const parts=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(now);const p=Object.fromEntries(parts.map(x=>[x.type,x.value]));return `${p.month}-${p.day}-${p.year}-${p.hour}-${p.minute}-${p.second}`;}
function id(){return 'OP-'+stamp()+'-'+crypto.randomBytes(4).toString('hex').toUpperCase();}
function safeId(value){if(!/^OP-[0-9-]+-[A-F0-9]{8}$/.test(value))throw Error('Invalid operation ID');return value;}
function directory(op){return path.join(DATA,'operations',safeId(op));}
function atomic(file,value){
 const temp=file+'.'+process.pid+'.'+crypto.randomBytes(4).toString('hex')+'.tmp';fs.writeFileSync(temp,JSON.stringify(value,null,2));
 for(let attempt=0;;attempt++)try{fs.renameSync(temp,file);return;}catch(e){
  if(!['EPERM','EACCES','EBUSY'].includes(e.code)||attempt>=14)throw e;
  // OneDrive/Windows indexing can briefly hold the destination open. Retry only
  // the local atomic rename, never a SoftMouse request or record creation.
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,Math.min(25*(attempt+1),200));
 }
}
function create(input,summary){const op=id(),dir=directory(op);fs.mkdirSync(dir);const record={id:op,status:'draft',operation:input.operation,profile:input.profile,summary,createdAt:new Date().toISOString(),inputHash:require('./contracts.cjs').digest(input),message:'Draft prepared. Nothing has been saved in SoftMouse.',events:0};atomic(path.join(dir,'input.json'),input);atomic(path.join(dir,'operation.json'),record);event(op,'draft_created',{message:record.message});return get(op);}
function get(op){return JSON.parse(fs.readFileSync(path.join(directory(op),'operation.json'),'utf8'));}
function input(op){return JSON.parse(fs.readFileSync(path.join(directory(op),'input.json'),'utf8'));}
function update(op,changes){const state={...get(op),...changes,updatedAt:new Date().toISOString()};atomic(path.join(directory(op),'operation.json'),state);return state;}
function event(op,type,details={}){const dir=directory(op),file=path.join(dir,'events.jsonl');const last=events(op).at(-1);const previous=last?.hash||'';const item={sequence:(last?.sequence||0)+1,at:new Date().toISOString(),type,...details,previousHash:previous};item.hash=crypto.createHash('sha256').update(JSON.stringify(item)).digest('hex');fs.appendFileSync(file,JSON.stringify(item)+'\n');update(op,{events:item.sequence,lastEventHash:item.hash,...(details.message?{message:details.message}:{})});return item;}
function events(op){const file=path.join(directory(op),'events.jsonl');return fs.existsSync(file)?fs.readFileSync(file,'utf8').trim().split('\n').filter(Boolean).map(s=>JSON.parse(s)):[];}
function list({strict=false}={}){return fs.readdirSync(path.join(DATA,'operations')).filter(x=>/^OP-/.test(x)).map(x=>{try{const state=get(x);if(strict&&(!state||state.id!==x||typeof state.createdAt!=='string'||!state.profile||typeof state.profile.id!=='string'))throw Error('Invalid operation metadata');return state;}catch(e){if(strict)throw Error('Operation history is unreadable: '+x+'. Restore or reconcile its evidence before continuing.');return null;}}).filter(Boolean).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));}
function resources(plan){const {cageKey}=require('./identifiers.cjs');return plan.operation==='add_cages'?(plan.data?.cages||[]).map(c=>'cage:'+cageKey(c.tag)):(plan.data?.litters||[]).map(l=>'litter:'+cageKey(l.cageTag)+'|'+l.birthDate);}
function assertNoUnreconciled(plan,exclude){const requested=new Set(resources(plan));for(const state of list({strict:true})){if(state.id===exclude||state.profile.id!==plan.profile.id||state.status!=='needs_review'||!state.approvedAt)continue;const prior=input(state.id);if(!resources(prior).some(r=>requested.has(r)))continue;const explicitRecovery=plan.operation==='wean_litters'&&prior.operation==='wean_litters'&&plan.data.litters.every(l=>l.resumeWeaned===true);if(!explicitRecovery)throw Error('Earlier operation '+state.id+' has an uncertain save for these cages/litters. Reconcile saved records before submitting overlapping work; automatic retry is blocked.');}}
function reconcileInterrupted(){for(const s of list())if(['backing_up','running','validating','ready'].includes(s.status)){update(s.id,{status:'needs_review',approvalTokenHash:null,message:'The app stopped or restarted during this operation. Check the saved records; automatic replay is blocked.'});event(s.id,'interrupted',{message:'Operation interrupted or review expired; automatic replay blocked.'});}}
function verifyChain(op){let previous='';for(const saved of events(op)){const {hash,...item}=saved;if(item.previousHash!==previous||crypto.createHash('sha256').update(JSON.stringify(item)).digest('hex')!==hash)return false;previous=hash;}return previous===(get(op).lastEventHash||'');}
// Code 39 encodes the operation ID. This barcode never changes cage barcodes.
const PATTERNS={'0':'nnnwwnwnn','1':'wnnwnnnnw','2':'nnwwnnnnw','3':'wnwwnnnnn','4':'nnnwwnnnw','5':'wnnwwnnnn','6':'nnwwwnnnn','7':'nnnwnnwnw','8':'wnnwnnwnn','9':'nnwwnnwnn','O':'wnnnwnnwn','P':'nnwnwnnwn','A':'wnnnnwnnw','B':'nnwnnwnnw','C':'wnwnnwnnn','D':'nnnnwwnnw','E':'wnnnwwnnn','F':'nnwnwwnnn','-':'nwnnnnwnw','*':'nwnnwnwnn'};
function barcode(op){safeId(op);let x=12;const bars=[];for(const c of '*'+op+'*'){const p=PATTERNS[c];if(!p)throw Error('Barcode character unsupported');[...p].forEach((w,i)=>{const size=w==='w'?3:1;if(i%2===0)bars.push(`<rect x="${x}" y="8" width="${size}" height="56"/>`);x+=size;});x+=1;}return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${x+12} 86" role="img" aria-label="Operation ${op}"><rect width="100%" height="100%" fill="white"/><g fill="black">${bars.join('')}</g><text x="${(x+12)/2}" y="80" text-anchor="middle" font-family="monospace" font-size="10">${op}</text></svg>`;}
function mouseBarcode(code){const n=require('./mouse-identities.cjs').decode(code),payload=n.toString(3).padStart(9,'0');let x=12;const bars=[];for(const c of '*'+payload+'*'){[...PATTERNS[c]].forEach((w,i)=>{const size=w==='w'?3:1;if(i%2===0)bars.push(`<rect x="${x}" y="8" width="${size}" height="56"/>`);x+=size;});x++;}return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${x+12} 86" role="img" aria-label="Mouse ID ${code}"><rect width="100%" height="100%" fill="white"/><g fill="black">${bars.join('')}</g><text x="${(x+12)/2}" y="80" text-anchor="middle" font-family="monospace" font-size="12">${code}</text></svg>`;}
module.exports={ROOT,DATA,id,stamp,create,get,input,update,event,events,list,directory,atomic,verifyChain,reconcileInterrupted,barcode,mouseBarcode,assertNoUnreconciled};
