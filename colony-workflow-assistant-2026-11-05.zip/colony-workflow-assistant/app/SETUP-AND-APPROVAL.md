# Setup and review

Follow ../README.md to install and launch locally. Select the exact profile after signing in. Review supported workflow inputs in README.md and SHORT-INSTRUCTIONS.md. Agree an IT-approved workstation, permissions, local evidence storage, backup procedure, ID registry authority, operator training, and response to partial saves. Confirm with the vendor that the intended automation and subscription features are supported. Validate a small supervised set before unattended real-colony use.
