'use strict';
const fs=require('node:fs'),path=require('node:path');
const {check}=require('./contracts.cjs');
const store=require('./store.cjs');
const ALPHABET='iI|',CAPACITY=3**9;
function encode(n){check(Number.isInteger(n)&&n>=0&&n<CAPACITY,'Mouse ID pool exhausted or invalid');return n.toString(3).padStart(9,'0').replace(/[012]/g,c=>ALPHABET[Number(c)]);}
function decode(code){check(typeof code==='string'&&/^[iI|]{9}$/.test(code),'Invalid mouse digital ID');return parseInt([...code].map(c=>ALPHABET.indexOf(c)).join(''),3);}
function split(tag){const match=/^(?:(.{1,15}) )?([iI|]{9})$/.exec(String(tag||''));return match?{physicalTag:match[1]||'',digitalCode:match[2]}:{physicalTag:String(tag||''),digitalCode:null};}
function compose(physicalTag,code){decode(code);check(typeof physicalTag==='string'&&physicalTag.length<=15,'Physical tag exceeds 15 characters; nine ID characters and a space must fit the 25-character field');check(physicalTag===physicalTag.trim(),'Remove surrounding whitespace from the physical tag');return physicalTag?physicalTag+' '+code:code;}
function compatible(actual,requested){const a=split(actual),r=split(requested);return r.digitalCode?actual===requested:a.physicalTag===requested;}
class Registry{
 constructor(dir=store.DATA){this.file=path.join(dir,'mouse-identities.json');this.marker=this.file+'.initialized';this.lock=this.file+'.lock';fs.mkdirSync(dir,{recursive:true});}
 read(){if(!fs.existsSync(this.file)){check(!fs.existsSync(this.marker),'Mouse ID registry is missing. Restore it from backup; do not reset the ID pool.');return {version:1,next:0,entries:{}};}const r=JSON.parse(fs.readFileSync(this.file));check(r&&r.version===1&&Number.isInteger(r.next)&&r.next>=0&&r.next<=CAPACITY&&r.entries&&typeof r.entries==='object'&&!Array.isArray(r.entries),'Invalid mouse ID registry');for(const [code,e]of Object.entries(r.entries)){check(decode(code)<r.next,'Invalid mouse ID registry counter: restore a consistent backup');check(e&&typeof e==='object'&&['reserved','bound'].includes(e.status)&&typeof e.profileId==='string'&&/^\d+$/.test(e.profileId),'Invalid mouse ID registry entry');if(e.status==='bound')check(typeof e.mouseId==='string'&&/^\d+$/.test(e.mouseId),'Invalid bound mouse ID registry entry');}return r;}
 transaction(fn){let fd;try{fd=fs.openSync(this.lock,'wx');}catch(e){if(e.code==='EEXIST')throw Error('Mouse ID registry is locked; review any interrupted process before continuing');throw e;}try{fs.writeFileSync(fd,JSON.stringify({pid:process.pid,at:new Date().toISOString()}));const r=this.read(),result=fn(r);store.atomic(this.file,r);fs.writeFileSync(this.marker,'Permanent mouse IDs. Never reset or delete this registry.\n');return result;}finally{fs.closeSync(fd);fs.unlinkSync(this.lock);}}
 reserve(count,op,profileId){check(Number.isInteger(count)&&count>=0,'Invalid ID reservation count');return this.transaction(r=>{const result=[];while(result.length<count){check(r.next<CAPACITY,'Mouse ID pool exhausted. No IDs will be reused.');const code=encode(r.next++);if(r.entries[code])continue;r.entries[code]={op,profileId,at:new Date().toISOString(),status:'reserved'};result.push(code);}return result;});}
 observe(records){return this.transaction(r=>{const seen=new Set();for(const {tag,mouseId,profileId} of records){const {digitalCode:code}=split(tag);if(!code)continue;check(!seen.has(code),'A digital mouse ID appears on more than one record: '+code);seen.add(code);const prior=r.entries[code];check(!prior?.profileId||prior.profileId===profileId,'Mouse ID is registered to another profile: '+code);check(!prior?.mouseId||prior.mouseId===mouseId,'Mouse ID is registered to another mouse: '+code);r.entries[code]={...prior,profileId,mouseId,status:'bound',observedAt:new Date().toISOString()};r.next=Math.max(r.next,decode(code)+1);}return r;});}
 assertPlan(op,profileId,mice){const r=this.read();for(const m of mice){if(!m.digitalCode)continue;const e=r.entries[m.digitalCode];check(e&&e.profileId===profileId,'Mouse ID reservation is unavailable');check(e.mouseId?e.mouseId===m.existingMouseId:e.op===op,'Mouse ID reservation does not belong to this operation');}}
}
function assigner(registry,op,profileId,count,lazy=false){const codes=lazy?null:registry.reserve(count,op,profileId);let n=0;return (mouse,existing)=>{
 const requested=String(mouse.tag||''),saved=existing?split(existing.tag):null;
 if(existing){check(!existing.tag||compatible(existing.tag,requested),'Existing physical tag will not be overwritten');mouse.originalStoredTag=existing.tag;}
 const physicalTag=saved?.digitalCode?saved.physicalTag:requested;
 check(!split(physicalTag).digitalCode,'Do not supply a digital ID for a new mouse; the program assigns it');
 const digitalCode=saved?.digitalCode||(lazy?registry.reserve(1)[0]:codes[n++]);check(digitalCode,'Mouse ID reservation is incomplete');
 mouse.physicalTag=physicalTag;mouse.digitalCode=digitalCode;mouse.tag=compose(physicalTag,digitalCode);return mouse;
 };}
function planningAssigner(registry,op,profileId,count){
 const baseline=registry.read(),planned=structuredClone(baseline);let assigned=0;
 const virtual={reserve:n=>{check(Number.isInteger(n)&&n>=0&&n<=count,'Invalid ID planning count');const codes=[];while(codes.length<n){check(planned.next<CAPACITY,'Mouse ID pool exhausted. No IDs will be reused.');const code=encode(planned.next++);if(planned.entries[code])continue;planned.entries[code]={op,profileId,at:new Date().toISOString(),status:'reserved'};codes.push(code);}return codes;}};
 // Reserve virtually, then persist only after the entire plan validates. Codes
 // from valid but abandoned reviews remain permanently reserved after commit.
 const assign=assigner(virtual,op,profileId,count,true);
 return {assign:(...args)=>{check(assigned++<count,'ID planning capacity exceeded');return assign(...args);},commit:()=>registry.transaction(current=>{check(require('./contracts.cjs').digest(current)===require('./contracts.cjs').digest(baseline),'Mouse ID registry changed during validation; prepare again');current.next=planned.next;current.entries=planned.entries;})};
}
module.exports={ALPHABET,CAPACITY,encode,decode,split,compose,compatible,Registry,assigner,planningAssigner};
