'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const store=require('./store.cjs');
const {validate,summary}=require('./contracts.cjs');
const {BrowserSession}=require('./browser.cjs');
const {OperationRunner}=require('./runner.cjs');
const session=new BrowserSession(),runner=new OperationRunner(session);
const instanceId=crypto.randomUUID();
const token=crypto.randomBytes(32).toString('hex');const port=Number(process.env.SOFTMOUSE_PORT||4317);if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Invalid local port');
const origin='http://127.0.0.1:'+port;let profileState={signedIn:false,profiles:[]};const approvals=new Map();
const existingLock=path.join(store.DATA,'operation.lock');
if(fs.existsSync(existingLock)){const lock=JSON.parse(fs.readFileSync(existingLock));let alive=false;try{process.kill(lock.pid,0);alive=true;}catch(e){if(e.code!=='ESRCH')alive=true;}if(alive)throw Error('An operation is active in another app process. Use the already running app.');}
store.reconcileInterrupted();
const send=(res,status,value)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));};
async function body(req){let size=0,parts=[];for await(const chunk of req){size+=chunk.length;if(size>5*1024*1024)throw Error('Input exceeds 5 MB');parts.push(chunk);}return JSON.parse(Buffer.concat(parts).toString('utf8')||'{}');}
const progress=new (require('./progress-stream.cjs').ProgressStream)(()=>({instanceId,busy:runner.busy,operations:store.list({strict:true}).slice(0,40)}));
const errorMessage=e=>e.message.replace(/^AssertionError \[.*?\]: /,'');
const server=http.createServer(async(req,res)=>{
 try{
  if(!['127.0.0.1:'+port,'localhost:'+port].includes(req.headers.host))return send(res,403,{error:'Local access only'});
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  const url=new URL(req.url,origin),route=url.pathname;
  if(req.method==='POST'){
   if(req.headers.origin!==origin||req.headers['x-softmouse-token']!==token||!String(req.headers['content-type']).startsWith('application/json'))return send(res,403,{error:'This action must come from the local app'});
   const data=await body(req);
   if(route==='/api/browser'){if(runner.busy)throw Error('An operation is using SoftMouse');await session.open();return send(res,200,{opened:true});}
   if(route==='/api/profiles'){if(runner.busy)throw Error('Wait until the current operation finishes');profileState=await session.profiles();return send(res,200,profileState);}
   if(route==='/api/short-input'){
    if(runner.busy)throw Error('Wait until the current operation finishes');
    const short=require('./short-input.cjs'),parsed=short.parse(data.text,data.operation);
    runner.busy=true;
    try{
     await session.reset();profileState=await session.profiles();
     if(!profileState.signedIn)throw Error('Sign in, then refresh profiles');
     const result=await short.convert(parsed,profileState.profiles,(kind,profile)=>require('./softmouse.cjs').list(session.page,kind,profile));
     result.input.data.shortInstructions=data.text;
     return send(res,200,result);
    }finally{runner.busy=false;}
   }
   if(route==='/api/drafts'){
    if(runner.busy)throw Error('Wait until the current operation finishes');const profile=profileState.profiles.find(p=>p.id===String(data.profileId));if(!profile)throw Error('Refresh profiles and select the destination');const plan=validate(data.input,profile);store.assertNoUnreconciled(plan);const state=store.create(plan,summary(plan));return send(res,201,state);
   }
   const action=/^\/api\/operations\/(OP-[0-9-]+-[A-F0-9]{8})\/(prepare|run|stop|fast)$/.exec(route);
   if(action){const [,id,verb]=action;
    if(verb==='fast'){if(runner.busy)throw Error('Another operation is active');const fast=require('./fast-mode.cjs');fast.authorize(store,id,data);send(res,202,{accepted:true});fast.execute(store,runner,id).catch(e=>console.error('Fast mode stopped: '+errorMessage(e)));return;}
    if(verb==='prepare'){if(store.get(id).status!=='draft')throw Error('Create a fresh draft before preparing again');if(runner.busy)throw Error('Another operation is active');send(res,202,{accepted:true});runner.prepare(id).then(result=>approvals.set(id,result.token)).catch(e=>{if(store.get(id).status==='draft'){store.update(id,{status:'blocked',error:errorMessage(e),message:errorMessage(e)});store.event(id,'preparation_not_started',{message:errorMessage(e)});}});return;}
    if(verb==='run'){const s=store.get(id);if(s.status!=='ready'||runner.busy)throw Error('Operation is not ready');if(data.profileName!==s.profile.name)throw Error('Type the selected profile name exactly');if(!approvals.has(id)||approvals.get(id)!==data.approvalToken)throw Error('Approval is invalid or expired');approvals.delete(id);send(res,202,{accepted:true});runner.run(id,data.approvalToken,data.profileName).catch(e=>{if(['ready','validating'].includes(store.get(id).status)){store.update(id,{status:'blocked',approvalTokenHash:null,message:'Pre-save check failed: '+errorMessage(e),error:errorMessage(e)});store.event(id,'pre_save_check_failed',{message:errorMessage(e)});}});return;}
    if(verb==='stop'){if(!runner.busy||runner.currentOp!==id)throw Error('This operation is not running');runner.stop=true;store.event(id,'stop_requested',{message:'Stop requested. Waiting for the current step to finish safely.'});return send(res,200,{requested:true});}
   }
   return send(res,404,{error:'Unknown action'});
  }
  if(req.method!=='GET')return send(res,405,{error:'Unsupported method'});
  if(route==='/api/state')return send(res,200,{instanceId,busy:runner.busy,browserOpen:!!session.page&&!session.page.isClosed(),profiles:profileState.profiles,signedIn:profileState.signedIn,localDate:require('./contracts.cjs').today()});
  if(route==='/api/mouse-barcode'){const svg=store.mouseBarcode(url.searchParams.get('code'));res.writeHead(200,{'Content-Type':'image/svg+xml','Cache-Control':'no-store'});res.end(svg);return;}
  if(route==='/api/history'){const q=url.searchParams.get('q')||'';return send(res,200,store.list({strict:true}).filter(s=>!q||require('./history-search.cjs').matches(s,store.input(s.id),fs.existsSync(path.join(store.directory(s.id),'resolved.json'))?JSON.parse(fs.readFileSync(path.join(store.directory(s.id),'resolved.json'))):null,q)));}

  const op=/^\/api\/operations\/(OP-[0-9-]+-[A-F0-9]{8})(?:\/(events|barcode|files))?$/.exec(route);
  if(op){const [,id,kind]=op;const state=store.get(id);
   if(kind==='events')return send(res,200,{events:store.events(id),chainValid:store.verifyChain(id)});
   if(kind==='barcode'){res.writeHead(200,{'Content-Type':'image/svg+xml','Cache-Control':'no-store'});res.end(store.barcode(id));return;}
   if(kind==='files'){const dir=store.directory(id);return send(res,200,fs.readdirSync(dir).filter(n=>/\.(?:json|jsonl|png|md)$/.test(n)));}
   const resolvedFile=path.join(store.directory(id),'resolved.json'),backupFile=path.join(store.directory(id),'backup-manifest.json');return send(res,200,{...state,resolved:fs.existsSync(resolvedFile)?JSON.parse(fs.readFileSync(resolvedFile)):null,backupFiles:fs.existsSync(backupFile)?JSON.parse(fs.readFileSync(backupFile)).files:[],approvalToken:state.status==='ready'?approvals.get(id):undefined,chainValid:store.verifyChain(id)});
  }
  const download=/^\/files\/(OP-[0-9-]+-[A-F0-9]{8})\/([^/]+)$/.exec(route);
  if(download){const [,id,encoded]=download,name=decodeURIComponent(encoded);if(path.basename(name)!==name||!/^[-\w.]+\.(json|jsonl|png|md|xlsx)$/.test(name))throw Error('Invalid file name');const state=store.get(id);let file=path.join(store.directory(id),name);if(!fs.existsSync(file)&&state.backupDirectory)file=path.join(store.ROOT,state.backupDirectory,name);const root=path.resolve(file);if(!root.startsWith(store.DATA+path.sep)||!fs.statSync(root).isFile())throw Error('File unavailable');res.writeHead(200,{'Content-Type':name.endsWith('.png')?'image/png':'application/octet-stream','Content-Disposition':'attachment; filename="'+name+'"','Cache-Control':'no-store'});fs.createReadStream(root).pipe(res);return;}
  if(route==='/api/stream'){progress.add(req,res);return;}

  const staticFiles={'/':'index.html','/app.js':'app.js','/style.css':'style.css'};
  if(staticFiles[route]){let value=fs.readFileSync(path.join(__dirname,'public',staticFiles[route]),'utf8');if(route==='/')value=value.replace('LOCAL_SESSION_TOKEN',token).replace('LOCAL_SERVER_INSTANCE',instanceId);res.writeHead(200,{'Content-Type':route==='/'?'text/html; charset=utf-8':route.endsWith('.js')?'text/javascript; charset=utf-8':'text/css; charset=utf-8','Cache-Control':'no-store'});res.end(value);return;}
  send(res,404,{error:'Not found'});
 }catch(e){send(res,400,{error:errorMessage(e)});}
});
server.listen(port,'127.0.0.1',()=>{store.atomic(path.join(store.DATA,'instance.json'),{pid:process.pid,url:origin,browserPort:Number(process.env.SOFTMOUSE_ATTACH_PORT||process.env.SOFTMOUSE_BROWSER_PORT||9333)});console.log('SoftMouse Lab is ready: '+origin);if(!process.argv.includes('--no-open'))spawn('rundll32.exe',['url.dll,FileProtocolHandler',origin],{windowsHide:true,stdio:'ignore'}).unref();});
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'SoftMouse Lab is already running at '+origin:e.message);process.exitCode=1;});
server.on('close',()=>progress.close());
module.exports={server,session,runner};
