// Packaged helper: launch the reviewed app with npm start; legacy standalone runs are disabled.
if (require.main === module) throw new Error('Launch this package with npm start. Standalone legacy scripts are disabled.');
'use strict';
// Normal SoftMouse forms only. Never uses the bulk-import feature or write APIs.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const shared = require('./softmouse-batch.cjs');
const { dateISO, findRecords, clickFill, setCalendarDate } = require('./softmouse-one-male.cjs');
const { readRows, fieldValue, selectLabel } = shared;
async function inventory(context, plan) {
  const result = { mice: {}, cages: {}, mouseFields: {} };
  const all = await findRecords(context, 'mouse', '', { allowPages: true, details: true });
  for (const m of plan.mice) {
    const rows = all.filter(r => fieldValue(r.fields, 'physicaltag') === m.tag);
    result.mice[m.tag] = rows.map(r => r.cells);
    result.mouseFields[m.tag] = rows.map(r => r.fields);
  }
  for (const c of plan.cages) result.cages[c.tag] = await findRecords(context, 'cage', c.tag, { allowPages: true, exact: true });
  return result;
}
function cagePlan(profile, cage) {
  const mice = cage.members.map(key => profile.mice.find(m => m.key === key));
  assert.ok(mice.every(Boolean));
  const autoMating = mice.some(m => m.sex === 'M') && mice.some(m => m.sex === 'F')
    && new Set(mice.map(m => m.strain)).size === 1;
  const state = autoMating ? 'Mating' : 'Stock';
  const plannedCage = { key: cage.sourceTag, tag: cage.tag, state, mice,
    strain: mice[0].strain, protocol: mice[0].protocol };
  return { runId: profile.namespace, owner: 'Practice Profile', setupDate: '2026-10-14', mice, cages: [plannedCage] };
}
function verifyMice(plan, records, allowUnassigned = false) {
  for (const mouse of plan.mice) {
    assert.equal(records.mice[mouse.tag].length, 1, `Expected one saved mouse ${mouse.tag}`);
    const fields = records.mouseFields[mouse.tag][0];
    for (const [column, expected] of [['physicaltag', mouse.tag], ['sex', mouse.sex], ['mouseline', mouse.strain],
      ['mouseearmark', mouse.altId], ['protocol', mouse.protocol], ['comment', mouse.comment]])
      assert.equal(fieldValue(fields, column), expected, `${mouse.tag}: ${column} differs`);
    assert.equal(dateISO(fieldValue(fields, 'dateofbirth')), mouse.dob, `${mouse.tag}: DOB differs`);
    const expectedGenotype = mouse.allele ? `(${mouse.allele})` : '';
    assert.equal(fieldValue(fields, 'genotype'), expectedGenotype, `${mouse.tag}: genotype differs`);
    if (!allowUnassigned) assert.equal(fieldValue(fields, 'cagetag'), mouse.cageTag, `${mouse.tag}: cage differs`);
  }
}
async function createOneCage(page, context, plan, stage, checkError) {
  let records = await inventory(context, plan);
  const cage = plan.cages[0];
  if (records.cages[cage.tag].length) {
    assert.equal(records.cages[cage.tag].length, 1, 'Duplicate cage tags detected');
    verifyMice(plan, records);
    assert.equal(Number(records.cages[cage.tag][0].find(v => v === String(plan.mice.length))), plan.mice.length);
    stage('cage_verified_existing', { cage: cage.tag, records });
    return records;
  }
  const anySaved = plan.mice.some(m => records.mice[m.tag].length);
  if (anySaved) {
    verifyMice(plan, records, true);
    for (const mouse of plan.mice) assert.equal(fieldValue(records.mouseFields[mouse.tag][0], 'cagetag'), '', 'Resume requires unassigned animals.');
    // All-state search is complete or fails closed if it spans pages. Select
    // exact verified database IDs, never a select-all that includes other cages.
    const commonPrefix = plan.mice.map(m => m.tag).reduce((prefix, tag) => {
      while (!tag.startsWith(prefix)) prefix = prefix.slice(0, -1);
      return prefix;
    });
    await findRecords(context, 'mouse', commonPrefix);
    const ids = plan.mice.map(m => fieldValue(records.mouseFields[m.tag][0], 'id'));
    for (const id of ids) await page.locator(`#jqg_mouseTable_${id}`).check();
    assert.equal(await page.locator('#mouseTable tr.jqgrow input:checked').count(), ids.length);
    stage('resume_existing_unassigned', { cage: cage.tag, ids });
    await page.getByRole('link', { name: 'Move Animals', exact: true }).click();
  } else {
    await shared.preview(page, plan, checkError);
    const previewRows = await readRows(page.locator('#batchPreviewTable tr.jqgrow'));
    assert.equal(previewRows.length, plan.mice.length);
    await page.locator('#cb_batchPreviewTable').check();
    stage('animals_save_attempt', { cage: cage.tag, mouseTags: plan.mice.map(m => m.tag) });
    await page.getByRole('button', { name: /^Create Animals and Move them(?: into Cages)?$/ }).click();
  }
  await page.waitForURL(u => u.pathname === '/smdb/cage/alloc.do' && u.searchParams.get('dispatch') === 'setup');
  checkError();
  await assignProfileCage(page, plan, stage, checkError);
  await page.getByText('Done', { exact: true }).click();
  records = await inventory(context, plan);
  verifyMice(plan, records);
  assert.equal(records.cages[cage.tag].length, 1, 'Expected exactly one saved cage');
  stage('cage_verified', { cage: cage.tag, records });
  return records;
}
async function assignProfileCage(page, plan, stage, checkError) {
  const rows = page.locator('#cageAssignmentTable tr.jqgrow');
  await rows.first().waitFor(); await page.waitForLoadState('networkidle');
  const current = await readRows(rows), cage = plan.cages[0];
  let males = 0, females = 0;
  for (const row of current) {
    const composition = fieldValue(row.fields, 'composition');
    males += Number(/(\d+)M/.exec(composition)?.[1] || 0);
    females += Number(/(\d+)F/.exec(composition)?.[1] || 0);
    assert.match(fieldValue(row.fields, 'currentCageTags'), /not yet assigned/i);
  }
  assert.equal(males, plan.mice.filter(m => m.sex === 'M').length, 'Allocation male count differs');
  assert.equal(females, plan.mice.filter(m => m.sex === 'F').length, 'Allocation female count differs');
  const residentText = current.map(r => fieldValue(r.fields, 'residentTags')).join(', ');
  for (const m of plan.mice) {
    const escaped = m.tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    assert.match(residentText, new RegExp(`(^|,\\s*)${escaped}($|,\\s*)`), `Missing allocation member ${m.tag}`);
  }
  for (const box of await rows.locator('input[type="checkbox"]').all()) await box.check();
  if (current.length > 1) { await page.getByRole('button', { name: 'Group', exact: true }).click(); await rows.nth(1).waitFor({ state: 'detached' }); }
  assert.equal(await rows.count(), 1);
  const row = rows.first();
  await row.locator('input[type="checkbox"]').check();
  await clickFill(row.locator('input[name="cageTag"]'), cage.tag);
  const entryDate = row.locator('input[name="entercageDate"]');
  if (dateISO(await entryDate.inputValue()) !== plan.setupDate)
    await setCalendarDate(page, entryDate, plan.setupDate, () => row.getByRole('img', { name: '...', exact: true }).click());
  assert.equal(dateISO(await entryDate.inputValue()), plan.setupDate);
  assert.equal(await row.locator('select[name="cageProtocolId"]').evaluate(e => e.options[e.selectedIndex]?.textContent.trim() || ''), cage.protocol);
  stage('cage_save_attempt', { cage: cage.tag });
  await page.getByRole('button', { name: 'Create / Update Cages', exact: true }).click();
  await page.waitForURL(u => u.pathname === '/smdb/cage/alloc.do' && u.searchParams.get('dispatch') === 'result');
  checkError();
  const summary = page.getByText(cage.tag, { exact: true }).locator('xpath=ancestor::tr[1]');
  await summary.waitFor(); const text = await summary.innerText();
  assert.match(text, /NEW/);
  for (const m of plan.mice) assert.ok(text.includes(m.tag), `Move Summary missing ${m.tag}`);
}
async function main() {
  const args = process.argv.slice(2);
  const arg = k => { const i = args.indexOf(k); return i < 0 ? null : args[i + 1]; };
  const profilePath = path.resolve(arg('--plan') || 'softmouse-profile-R261014A.json');
  const profile = JSON.parse(fs.readFileSync(profilePath, 'utf8'));
  assert.equal(profile.historyPolicy, 'summary-comments', 'Resolve historical litter policy before saving.');
  assert.ok(args.includes('--save') && args.includes('--authorized-practice'), 'Saving requires explicit practice flags.');
  const journalPath = path.resolve(`softmouse-profile-${profile.namespace}-run.json`);
  let journal = fs.existsSync(journalPath) ? JSON.parse(fs.readFileSync(journalPath, 'utf8'))
    : { planHash: profile.planHash, actions: [], records: {} };
  assert.equal(journal.planHash, profile.planHash, 'Input changed under the same run ID.');
  const stage = (status, details = {}) => {
    journal.status = status; journal.updatedAt = new Date().toISOString();
    journal.actions.push({ status, ...details, at: journal.updatedAt });
    if (details.cage && details.records) journal.records[details.cage] = details.records;
    fs.writeFileSync(journalPath, JSON.stringify(journal, null, 2));
    console.log(`${status}${details.cage ? `: ${details.cage}` : ''}`);
  };
  const browser = await chromium.connectOverCDP(arg('--cdp') || 'http://127.0.0.1:9222');
  const pages = browser.contexts().flatMap(c => c.pages()).filter(p => p.url().includes('softmouse.net'));
  assert.equal(pages.length, 1, 'Use exactly one SoftMouse tab in the shared Playwright session.');
  const page = pages[0], context = page.context();
  page.setDefaultTimeout(20000); page.setDefaultNavigationTimeout(30000);
  let blocked = '';
  const checkError = () => { if (blocked) throw new Error(blocked); };
  page.on('dialog', async d => {
    blocked = `SoftMouse validation: ${d.message()}`;
    console.log(blocked); await d.dismiss();
  });
  const only = arg('--cage');
  const cages = profile.cages.filter(c => !only || c.sourceTag === only);
  assert.ok(cages.length, 'No matching cages in input');
  const completed = new Set();
  const priorCages = cages.filter(c => journal.records[c.tag]?.cages?.[c.tag]?.length === 1);
  if (priorCages.length) {
    const allMice = await findRecords(context, 'mouse', '', { allowPages: true, details: true });
    const allCages = await findRecords(context, 'cage', '', { allowPages: true, details: true });
    for (const cage of priorCages) {
      const plan = cagePlan(profile, cage), records = { mice: {}, mouseFields: {} };
      const foundCages = allCages.filter(r => Object.entries(r.fields).some(([k, v]) => k.toLowerCase().endsWith('_cagetag') && v === cage.tag));
      assert.equal(foundCages.length, 1, `Saved cage ${cage.tag} missing or duplicated`);
      for (const m of plan.mice) {
        const matches = allMice.filter(r => fieldValue(r.fields, 'physicaltag') === m.tag);
        records.mice[m.tag] = matches.map(r => r.cells); records.mouseFields[m.tag] = matches.map(r => r.fields);
      }
      verifyMice(plan, records); completed.add(cage.tag);
    }
    stage('completed_cages_reconciled', { cages: [...completed] });
  }
  for (const cage of cages) {
    if (completed.has(cage.tag)) continue;
    const plan = cagePlan(profile, cage);
    try { await createOneCage(page, context, plan, stage, checkError); }
    catch (error) {
      stage('inspection_required', { cage: cage.tag, error: error.message });
      try { stage('post_attempt_records', { cage: cage.tag, records: await inventory(context, plan) }); }
      catch (lookupError) { stage('lookup_failed', { error: lookupError.message }); }
      await page.screenshot({ path: `softmouse-profile-${profile.namespace}-error.png`, fullPage: true }).catch(() => {});
      throw error;
    }
  }
  stage('selected_cages_verified');
  console.log('Normal animal/cage forms verified. Mating/pedigree reconciliation is a separate required phase.');
}
module.exports = { cagePlan, verifyMice, inventory, assignProfileCage, createOneCage, main };
if (require.main === module) main().then(() => process.exit(0)).catch(e => { console.error(e.stack); process.exit(1); });
