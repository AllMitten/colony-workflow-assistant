// Packaged helper: launch the reviewed app with npm start; legacy standalone runs are disabled.
if (require.main === module) throw new Error('Launch this package with npm start. Standalone legacy scripts are disabled.');
'use strict';
// Practice-only, data-driven grouped cages and breeding pairs/trios.
// Preview: node softmouse-batch.cjs --input softmouse-practice-four.json --test-id UNIQUE
// Save: add --save --authorized-practice. Tools and script use the same CDP tab.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { chromium } = require('playwright');
const { dateISO, displayDate, findRecords, setCalendarDate, clickFill, selectedLabel, waitUntil } = require('./softmouse-one-male.cjs');
const clean = value => String(value ?? '').replace(/\s+/g, ' ').trim();
function normalizeAllele(value) {
  const v = clean(value);
  if (!v || /^not\s+specified$/i.test(v)) return '';
  if (/^(heterozygous|het|\+\/-)$/i.test(v)) return '+/-';
  assert.ok(['+', '-', '+/+', '-/-', 'WT', 'fl/+', 'fl/-', 'fl/fl'].includes(v), `Unknown allele: ${v}`);
  return v;
}
function validDate(value, label) {
  assert.match(value || '', /^\d{4}-\d{2}-\d{2}$/, `${label} must use YYYY-MM-DD.`);
  const parsed = new Date(`${value}T12:00:00Z`);
  assert.ok(Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value, `${label} is invalid.`);
}
function buildPlan(input, runId) {
  assert.match(runId, /^[a-z0-9_-]{1,12}$/i, 'Use a unique practice run ID of at most 12 characters.');
  validDate(input.setupDate, 'Setup date');
  assert.ok(clean(input.owner), 'Owner is required.');
  assert.ok(input.mice?.length && input.cages?.length, 'Mice and cages are required.');
  const cages = input.cages.map(c => ({ ...c, tag: `${runId}-${c.key}` }));
  assert.equal(new Set(cages.map(c => c.key)).size, cages.length, 'Duplicate cage keys.');
  cages.forEach(c => {
    assert.match(c.key, /^[a-z0-9_-]+$/i);
    assert.ok(['Stock', 'Mating'].includes(c.state), 'Cage state must be Stock or Mating.');
    assert.ok(clean(c.strain), 'Cage strain is required.');
    assert.ok(c.tag.length <= 25, 'Cage tag exceeds 25 characters.');
  });
  const mice = input.mice.map(m => {
    // Prefix, rather than normalize, so every punctuation mark remains intact.
    assert.ok(typeof m.physicalTag === 'string' && m.physicalTag.length, 'Physical ID is required.');
    const tag = `${runId}-${m.physicalTag}`;
    assert.ok(tag.length <= 25, 'Physical tag exceeds the form limit.');
    validDate(m.dob, `DOB for ${tag}`);
    assert.ok(m.dob <= input.setupDate, `DOB follows setup date for ${tag}.`);
    assert.ok(['M', 'F'].includes(m.sex), `Sex must be M/F for ${tag}.`);
    assert.ok(clean(m.strain) && clean(m.protocol), `Strain and protocol required for ${tag}.`);
    const cage = cages.find(c => c.key === m.cage);
    assert.ok(cage, `Unknown cage for ${tag}.`);
    return { ...m, tag, cageTag: cage.tag, allele: normalizeAllele(m.allele), comment: m.comment || '' };
  });
  assert.equal(new Set(mice.map(m => m.tag)).size, mice.length, 'Duplicate physical IDs in this batch.');
  cages.forEach(c => {
    c.mice = mice.filter(m => m.cage === c.key);
    assert.ok(c.mice.length > 0 && c.mice.length <= 5, 'Each practice cage must contain 1–5 mice.');
    assert.equal(new Set(c.mice.map(m => m.protocol)).size, 1, 'Cage members must share a protocol.');
    c.protocol = c.mice[0].protocol;
    if (c.state === 'Mating') {
      assert.equal(c.mice.filter(m => m.sex === 'M').length, 1, 'A breeding pair/trio needs exactly one male.');
      assert.ok([1, 2].includes(c.mice.filter(m => m.sex === 'F').length), 'A breeding pair/trio needs one or two females.');
    }
  });
  return { runId, owner: input.owner, setupDate: input.setupDate, mice, cages };
}
async function selectLabel(field, label) {
  const options = await field.locator('option').evaluateAll(es => es.map(e => ({ value: e.value, text: e.textContent.trim() })));
  const optionsMatched = options.filter(o => o.text === label);
  assert.equal(optionsMatched.length, 1, `Expected one option named ${label}.`);
  await field.click();
  await field.selectOption(optionsMatched[0].value);
  assert.equal(await selectedLabel(field), label);
  return optionsMatched[0].value;
}
async function readRows(locator) {
  return locator.evaluateAll(es => {
    const text = node => node.nodeName === 'BR' ? ' ' : node.nodeType === 3 ? node.textContent : Array.from(node.childNodes).map(text).join('');
    return es.map(row => ({
    id: row.id,
    cells: Array.from(row.cells || []).map(cell => {
      const select = cell.querySelector('select');
      if (select) return select.options[select.selectedIndex]?.textContent.trim() || '';
      const input = cell.querySelector('input[type="text"]');
      return (input ? input.value : text(cell)).replace(/\s+/g, ' ').trim();
    }),
    fields: Object.fromEntries(Array.from(row.cells || []).map(cell => [
      cell.getAttribute('aria-describedby') || '',
      text(cell).replace(/\s+/g, ' ').trim()
    ]))
  })); });
}
function mouseMatches(cells, mouse, state = null) {
  return cells.includes(mouse.tag) && cells.includes(mouse.altId) && cells.includes(mouse.sex)
    && cells.some(c => dateISO(c) === mouse.dob) && cells.includes(mouse.strain)
    && cells.includes(mouse.protocol) && (!mouse.comment || cells.includes(mouse.comment))
    && (!mouse.allele || cells.some(c => c.includes(mouse.allele)))
    && (!state || (cells.includes(state) && cells.includes(mouse.cageTag)));
}
async function inventory(context, plan) {
  const result = { mice: {}, cages: {}, mouseFields: {} };
  for (const m of plan.mice) {
    result.mice[m.tag] = await findRecords(context, 'mouse', m.tag);
    const tab = context.pages().find(p => p.url().includes('softmouse.net'));
    result.mouseFields[m.tag] = (await readRows(tab.locator('#mouseTable tr.jqgrow'))).map(r => r.fields);
  }
  for (const c of plan.cages) result.cages[c.tag] = await findRecords(context, 'cage', c.tag);
  return result;
}
function fieldValue(fields, name) {
  const entry = Object.entries(fields).find(([key]) => key.endsWith(`_${name}`));
  assert.ok(entry, `Expected saved column ${name}.`);
  return entry[1];
}
function verifyMouseDetails(mouse, fields) {
  assert.equal(fieldValue(fields, 'comment'), mouse.comment, `Comment differs: ${mouse.tag}.`);
  const genotype = fieldValue(fields, 'genotype');
  if (mouse.allele) assert.ok(genotype.includes(mouse.allele), `Genotype differs: ${mouse.tag}.`);
  else assert.equal(genotype, '', `Unspecified genotype was populated: ${mouse.tag}.`);
}
function verifyInventory(plan, records) {
  for (const m of plan.mice) {
    const rows = records.mice[m.tag];
    assert.equal(rows.length, 1, `Expected exactly one saved mouse ${m.tag}.`);
    assert.ok(mouseMatches(rows[0], m, plan.cages.find(c => c.key === m.cage).state), `Saved mouse differs: ${m.tag}.`);
    verifyMouseDetails(m, records.mouseFields[m.tag][0]);
  }
  for (const c of plan.cages) {
    const rows = records.cages[c.tag];
    assert.equal(rows.length, 1, `Expected exactly one saved cage ${c.tag}.`);
    const row = rows[0];
    assert.ok(row.includes(c.tag) && row.includes(String(c.mice.length)) && row.includes(c.state)
      && row.includes(c.strain) && row.includes(c.protocol), `Saved cage differs: ${c.tag}.`);
    assert.ok(row.some(value => dateISO(value) === plan.setupDate), `Wrong cage date: ${c.tag}.`);
    for (const m of c.mice) assert.ok(row.some(value => value.includes(`${m.tag} [${m.sex}, ${displayDate(m.dob)},`)), `Missing cage member: ${m.tag}.`);
  }
}
async function verifyMatings(page, plan, records) {
  const verified = {};
  for (const cage of plan.cages.filter(c => c.state === 'Mating')) {
    await page.getByRole('link', { name: 'Matings', exact: true }).click();
    await page.locator('#matinglist_table').waitFor({ state: 'attached' });
    await page.waitForLoadState('networkidle');
    if (!await page.locator('#filterClear').isVisible()) await page.locator('#editOpenCloseImage').click();
    await page.locator('#filterClear').click();
    await page.locator('#matingState + button').click();
    const all = page.locator('.ui-multiselect-menu:visible label').filter({ hasText: /^All$/ });
    if (!await all.locator('input').isChecked()) await all.click();
    assert.ok(await page.locator('#matingState').evaluate(e => Array.from(e.options).filter(o => o.value !== 'All').every(o => o.selected)), 'Mating search must include all states.');
    // SoftMouse spells this filter parameter catetag, as observed in its UI.
    await clickFill(page.locator('input[name="catetag"]'), cage.tag);
    const rp = page.waitForResponse(r => {
      const url = new URL(r.url());
      return url.pathname === '/mating/listfiltermating.json' && url.searchParams.get('catetag') === cage.tag;
    });
    await page.locator('#filterApply').click();
    const response = await rp;
    assert.ok(response.ok(), 'Mating lookup failed.');
    const result = await response.json();
    assert.equal(Number(result.records), 1, 'Expected exactly one mating record for this cage.');
    assert.equal(result.list.length, 1);
    const rows = page.locator('#matinglist_table tr.jqgrow');
    await waitUntil('Mating lookup UI did not load', () => readRows(rows), observed =>
      observed.length === 1 && observed[0].cells.includes(cage.tag), () => {});
    const fields = (await readRows(rows))[0].fields;
    const male = cage.mice.find(m => m.sex === 'M');
    const females = cage.mice.filter(m => m.sex === 'F');
    assert.equal(fieldValue(fields, 'maleId'), fieldValue(records.mouseFields[male.tag][0], 'id'), 'Mating sire differs.');
    const savedFemaleIds = fieldValue(fields, 'femaleIds').match(/\d+/g) || [];
    assert.deepEqual(savedFemaleIds.sort(), females.map(m => fieldValue(records.mouseFields[m.tag][0], 'id')).sort(), 'Mating dams differ.');
    assert.equal(fieldValue(fields, 'mouseline'), cage.strain, 'Litter strain differs.');
    assert.equal(dateISO(fieldValue(fields, 'setupdate')), plan.setupDate, 'Mating setup date differs.');
    assert.equal(fieldValue(fields, 'state'), 'Active', 'Mating is not active.');
    verified[cage.tag] = fields;
    console.log(`Mating verified: ${fieldValue(fields, 'matingId')}, correct sire/dam(s), strain and date.`);
  }
  return verified;
}
async function preview(page, plan, checkError) {
  await page.locator('a.textdecoration[href="smdb/mouse/list.do"]').click();
  await page.getByRole('link', { name: 'New Animals', exact: true }).click();
  await page.locator('#sizeMale').waitFor();
  assert.ok((await selectedLabel(page.locator('#ownerId'))).includes(plan.owner), 'Unexpected owner.');
  const rows = page.locator('#batchPreviewTable tr.jqgrow');
  assert.equal(await rows.count(), 0, 'Preview must start empty.');
  for (let i = 0; i < plan.mice.length; i++) {
    const m = plan.mice[i];
    await page.getByRole('button', { name: 'Reset', exact: true }).click();
    await clickFill(page.locator('#sizeMale'), m.sex === 'M' ? '1' : '0');
    await clickFill(page.locator('#sizeFemale'), m.sex === 'F' ? '1' : '0');
    await clickFill(page.locator('#sizeUnknown'), '0');
    await selectLabel(page.locator('#mouselineId'), m.strain);
    await selectLabel(page.locator('#protocolId'), m.protocol);
    await setCalendarDate(page, page.locator('#birthDatePicker'), m.dob, () => page.locator('#birthDatePicker').click());
    await clickFill(page.locator('#tagPrefix'), m.tag);
    await clickFill(page.locator('#tagStartIndex'), '');
    await selectLabel(page.locator('#mouseEarmarkId'), m.altId);
    await clickFill(page.locator('#comment'), m.comment);
    if (m.allele) {
      if (m.gene) await selectLabel(page.locator('#geneId'), m.gene);
      await selectLabel(page.locator('#alleleId'), m.allele);
      await page.getByRole('button', { name: /Add to Genotype/ }).click();
      assert.ok((await page.locator('#genotype').innerText()).includes(m.allele), 'Allele was not added to genotype.');
    } else assert.equal(await page.locator('#genotype option').count(), 0, 'Unspecified genotype must be empty.');
    await page.getByRole('button', { name: 'Add', exact: true }).click();
    await waitUntil('Incorrect batch preview', () => readRows(rows), observed =>
      observed.length === i + 1 && plan.mice.slice(0, i + 1).every(expected => observed.filter(r => mouseMatches(r.cells, expected)).length === 1), checkError);
    console.log(`Preview verified: ${m.tag}, ${m.sex}, ${m.strain}, ${m.altId}, ${m.dob}.`);
  }
  return rows;
}
async function assignCages(page, plan, stage, checkError) {
  const rows = page.locator('#cageAssignmentTable tr.jqgrow');
  await rows.first().waitFor();
  await waitUntil('Unexpected allocation row count', () => rows.count(), n => n === plan.mice.length, checkError);
  await page.waitForLoadState('networkidle');
  for (const cage of plan.cages) {
    // Select only members of this intended cage, never all rows indiscriminately.
    for (const checkbox of await rows.locator('input[type="checkbox"]').all()) await checkbox.uncheck();
    const current = await readRows(rows);
    const indices = current.map((r, i) => cage.mice.some(m => r.cells.includes(m.tag)) ? i : -1).filter(i => i >= 0);
    assert.equal(indices.length, cage.mice.length, 'Allocation membership differs.');
    for (const i of indices) await rows.nth(i).locator('input[type="checkbox"]').check();
    if (indices.length > 1) {
      const before = current.length;
      await page.getByRole('button', { name: 'Group', exact: true }).click();
      await waitUntil('Grouping did not finish', () => rows.count(), n => n === before - indices.length + 1, checkError);
    }
    const grouped = await readRows(rows);
    const matches = grouped.map((r, i) => cage.mice.every(m => r.cells.some(v => v.includes(m.tag))) ? i : -1).filter(i => i >= 0);
    assert.equal(matches.length, 1, 'Expected one grouped row for this cage.');
    const row = rows.nth(matches[0]);
    const rowText = await row.innerText();
    const males = cage.mice.filter(m => m.sex === 'M').length;
    const females = cage.mice.length - males;
    const expected = [males ? `${males}M` : '', females ? `${females}F` : ''].filter(Boolean).join('+');
    assert.ok(rowText.replace(/\s/g, '').includes(`Adult:${expected}`), 'Grouped sex counts differ.');
    assert.ok(/not yet assigned/i.test(rowText), 'Unexpected existing cage allocation.');
    await clickFill(row.locator('input[name="cageTag"]'), cage.tag);
    const dates = row.locator('input');
    const values = await dates.evaluateAll(es => es.map(e => e.value));
    const dateIndices = values.map((value, i) => dateISO(value) ? i : -1).filter(i => i >= 0);
    assert.equal(dateIndices.length, 1, 'Enter Cage date is ambiguous.');
    const date = dates.nth(dateIndices[0]);
    if (dateISO(await date.inputValue()) !== plan.setupDate)
      await setCalendarDate(page, date, plan.setupDate, () => row.getByRole('img', { name: '...', exact: true }).click());
    assert.equal(dateISO(await date.inputValue()), plan.setupDate);
    assert.ok((await row.locator('select').evaluateAll(es => es.map(e => e.options[e.selectedIndex]?.textContent.trim()))).includes(cage.protocol), 'Allocation protocol differs.');
  }
  assert.equal(await rows.count(), plan.cages.length, 'Unexpected final cage count.');
  for (const checkbox of await rows.locator('input[type="checkbox"]').all()) await checkbox.check();
  stage('cage_save_attempted');
  await page.getByRole('button', { name: 'Create / Update Cages', exact: true }).click();
  await page.waitForURL(url => url.pathname === '/smdb/cage/alloc.do' && url.searchParams.get('dispatch') === 'result');
  checkError();
  for (const cage of plan.cages) {
    const row = page.getByText(cage.tag, { exact: true }).locator('xpath=ancestor::tr[1]');
    await row.waitFor();
    await waitUntil('Unexpected cage disposition in Move Summary', () => readRows(row), observed => {
      const values = observed[0]?.cells || [];
      return values.includes('NEW') && (values.includes('Stock') || (cage.state === 'Mating' && values.includes('Mating')));
    }, checkError);
    const content = clean(await row.innerText());
    for (const m of cage.mice) assert.ok(content.includes(`${m.tag} [${m.sex}, ${displayDate(m.dob)},`), 'Move Summary membership differs.');
  }
  stage('cages_saved_summary_verified');
}
async function moveExisting(page, context, plan, records) {
  for (const m of plan.mice) {
    assert.equal(records.mice[m.tag].length, 1, 'Expected exactly one existing mouse.');
    assert.ok(mouseMatches(records.mice[m.tag][0], m), 'Existing mouse differs from input.');
    verifyMouseDetails(m, records.mouseFields[m.tag][0]);
    assert.equal(fieldValue(records.mouseFields[m.tag][0], 'cagetag'), '', 'Resume is allowed only for unassigned mice.');
  }
  const found = await findRecords(context, 'mouse', `${plan.runId}-`);
  assert.equal(found.length, plan.mice.length, 'The run prefix includes unexpected mouse records.');
  assert.ok(plan.mice.every(m => found.filter(c => mouseMatches(c, m)).length === 1), 'Move selection differs.');
  await page.locator('#cb_mouseTable').check();
  assert.equal(await page.locator('#mouseTable tr.jqgrow input[type="checkbox"]:checked').count(), plan.mice.length);
  await page.getByRole('link', { name: 'Move Animals', exact: true }).click();
  await page.waitForURL(url => url.pathname === '/smdb/cage/alloc.do' && url.searchParams.get('dispatch') === 'setup');
}
async function createMatings(page, plan, stage, checkError) {
  for (const cage of plan.cages.filter(c => c.state === 'Mating')) {
    const row = page.getByText(cage.tag, { exact: true }).locator('xpath=ancestor::tr[1]');
    const existing = (await readRows(row))[0].cells;
    if (existing.includes('Mating')) {
      // SoftMouse can automatically establish a same-strain breeding cage.
      assert.ok(existing.includes(cage.strain), 'Automatic mating strain differs.');
      assert.equal(await row.getByRole('button', { name: 'Create New Mating', exact: true }).count(), 0);
      stage('automatic_mating_summary_verified', { matingCage: cage.tag });
      continue;
    }
    await selectLabel(row.locator('select'), cage.strain);
    stage('mating_save_attempted', { matingCage: cage.tag });
    await row.getByRole('button', { name: 'Create New Mating', exact: true }).click();
    await waitUntil('Mating creation was not confirmed', () => row.innerText(), value =>
      /\bMating\b/.test(value) && !value.includes('Create New Mating'), checkError);
    stage('mating_summary_verified', { matingCage: cage.tag });
  }
}
async function main() {
  const args = process.argv.slice(2);
  const arg = name => { const i = args.indexOf(name); return i < 0 ? null : args[i + 1]; };
  const runId = arg('--test-id') || `B${Date.now().toString(36).toUpperCase()}`;
  const inputPath = path.resolve(__dirname, arg('--input') || 'softmouse-practice-four.json');
  const plan = buildPlan(JSON.parse(fs.readFileSync(inputPath, 'utf8')), runId);
  const planHash = crypto.createHash('sha256').update(JSON.stringify(plan)).digest('hex');
  const journalPath = path.join(__dirname, `softmouse-batch-${runId}-run.json`);
  const save = args.includes('--save');
  assert.ok(!save || args.includes('--authorized-practice'), 'Saving requires --authorized-practice for this practice workflow.');
  let browser, context, page, fd, blocked = '', attempted = false;
  let record = { plan, planHash, actions: [] };
  const checkError = () => { if (blocked) throw new Error(blocked); };
  const stage = (status, details = {}) => {
    record = { ...record, ...details, status, updatedAt: new Date().toISOString() };
    record.actions.push({ status, ...details, at: record.updatedAt });
    fs.ftruncateSync(fd, 0);
    fs.writeSync(fd, JSON.stringify(record, null, 2), 0, 'utf8');
    fs.fsyncSync(fd);
    console.log(`Stage: ${status}`);
  };
  try {
    console.table(plan.mice.map(m => ({ tag: m.tag, sex: m.sex, dob: m.dob, strain: m.strain, cage: m.cageTag })));
    browser = await chromium.connectOverCDP(arg('--cdp') || 'http://127.0.0.1:9222');
    const candidates = browser.contexts().flatMap(c => c.pages()).filter(p => p.url().includes('softmouse.net'));
    assert.equal(candidates.length, 1, 'Expected one manually logged-in SoftMouse tab.');
    page = candidates[0]; context = page.context(); page.setDefaultTimeout(25000);
    page.on('dialog', dialog => {
      (async () => {
        console.log(`SoftMouse ${dialog.type()}: ${dialog.message()}`);
        blocked = `Unexpected ${dialog.type()}: ${dialog.message()}`;
        await dialog.dismiss();
      })().catch(e => { blocked = e.message; });
    });
    assert.ok(await page.locator('a.textdecoration[href="smdb/mouse/list.do"]').isVisible(), 'Log into the shared practice browser manually first.');
    const existing = await inventory(context, plan);
    if (fs.existsSync(journalPath)) {
      record = JSON.parse(fs.readFileSync(journalPath, 'utf8'));
      assert.equal(record.planHash, planHash, 'This run ID belongs to different input data.');
      const noCages = plan.cages.every(c => existing.cages[c.tag].length === 0);
      if (save && args.includes('--resume') && noCages) {
        // Animals are already saved. Select only those verified records and
        // continue cage assignment; never run the animal creation step again.
        fd = fs.openSync(journalPath, 'r+');
        attempted = true;
        stage('resuming_existing_unassigned_animals', { records: existing });
        await moveExisting(page, context, plan, existing);
        await assignCages(page, plan, stage, checkError);
        await createMatings(page, plan, stage, checkError);
        await page.getByText('Done', { exact: true }).click();
        const records = await inventory(context, plan);
        verifyInventory(plan, records);
        const matings = await verifyMatings(page, plan, records);
        stage('saved_records_verified', { records, matings });
        await page.screenshot({ path: path.join(__dirname, `softmouse-batch-${runId}-verified.png`), fullPage: true });
        console.log('SUCCESS: existing mice assigned to their verified stock and breeding cages.');
        return;
      }
      verifyInventory(plan, existing);
      const matings = await verifyMatings(page, plan, existing);
      fd = fs.openSync(journalPath, 'r+');
      stage('saved_records_verified', { records: existing, matings });
      await page.screenshot({ path: path.join(__dirname, `softmouse-batch-${runId}-verified.png`), fullPage: true });
      console.log('Existing batch verified; no save clicks performed.');
      return;
    }
    for (const [tag, rows] of Object.entries({ ...existing.mice, ...existing.cages })) assert.equal(rows.length, 0, `Identifier already exists: ${tag}.`);
    const rows = await preview(page, plan, checkError);
    await page.screenshot({ path: path.join(__dirname, `softmouse-batch-${runId}-preview.png`), fullPage: true });
    if (!save) { console.log('PREVIEW PASSED. No records saved.'); return; }
    const reviewed = await readRows(rows);
    assert.equal(reviewed.length, plan.mice.length);
    assert.ok(plan.mice.every(m => reviewed.filter(r => mouseMatches(r.cells, m)).length === 1));
    await page.locator('#cb_batchPreviewTable').check();
    fd = fs.openSync(journalPath, 'wx');
    attempted = true;
    stage('animal_creation_attempted');
    await page.getByRole('button', { name: /^Create Animals and Move them(?: into Cages)?$/ }).click();
    await page.waitForURL(url => url.pathname === '/smdb/cage/alloc.do' && url.searchParams.get('dispatch') === 'setup');
    checkError(); stage('animals_created_cages_pending');
    await assignCages(page, plan, stage, checkError);
    await createMatings(page, plan, stage, checkError);
    await page.getByText('Done', { exact: true }).click();
    const records = await inventory(context, plan);
    verifyInventory(plan, records);
    const matings = await verifyMatings(page, plan, records);
    stage('saved_records_verified', { records, matings });
    await page.screenshot({ path: path.join(__dirname, `softmouse-batch-${runId}-verified.png`), fullPage: true });
    console.log(`SUCCESS: ${plan.mice.length} mice, ${plan.cages.length} cages, and ${plan.cages.filter(c => c.state === 'Mating').length} breeding cage(s) saved and verified.`);
  } catch (error) {
    process.exitCode = 1;
    console.error(`STOPPED: ${blocked || error.message}`);
    if (page) console.error(`Page: ${page.url()}`);
    if (attempted) {
      try { stage('inspection_required', { error: blocked || error.message, observedRecords: await inventory(context, plan) }); }
      catch (lookupError) { console.error(`Record inspection failed: ${lookupError.message}. No save retry is permitted.`); }
    }
  } finally { if (fd !== undefined) fs.closeSync(fd); /* Shared browser remains open. */ }
}
module.exports = { normalizeAllele, buildPlan, mouseMatches, verifyInventory, verifyMatings,
  selectLabel, readRows, fieldValue, preview, assignCages, createMatings, inventory, main };
if (require.main === module) main().then(() => process.exit(process.exitCode || 0)).catch(e => { console.error(e); process.exit(1); });
