// Packaged helper: launch the reviewed app with npm start; legacy standalone runs are disabled.
if (require.main === module) throw new Error('Launch this package with npm start. Standalone legacy scripts are disabled.');
'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const { findRecords, dateISO } = require('./softmouse-one-male.cjs');
const { fieldValue } = require('./softmouse-batch.cjs');
const { matingRows, expectedIds, historyComment } = require('./softmouse-profile-matings.cjs');
function verifyAnimalRows(profile, rows, options = {}) {
  assert.equal(rows.length, profile.mice.length, 'Total animal count differs');
  const mapping = [];
  for (const m of profile.mice) {
    const matches = rows.filter(r => fieldValue(r.fields, 'physicaltag') === m.tag);
    assert.equal(matches.length, 1, `Expected exactly one animal ${m.tag}`);
    const r = matches[0], fields = r.fields;
    for (const [col, expected] of [['sex', m.sex], ['mouseline', m.strain], ['mouseearmark', m.altId],
      ['protocol', m.protocol], ['cagetag', m.cageTag], ['comment', m.comment],
      ['genotype', m.allele ? `(${m.allele})` : '']])
      assert.equal(fieldValue(fields, col), expected, `${m.tag}: ${col} differs`);
    assert.equal(dateISO(fieldValue(fields, 'dateofbirth')), m.dob, `${m.tag}: DOB differs`);
    const actualState = fieldValue(fields, 'mousestate');
    if (!options.skipState && !(options.auditWeanlingStock && m.state === 'Weanling' && actualState === 'Stock'))
      assert.equal(actualState, m.state, `${m.tag}: state differs`);
    for (const [role, col] of [['sire', 'fatherid'], ['dam', 'motherid']]) {
      if (!m[`${role}Key`] || options.skipParents) continue;
      const parent = profile.mice.find(p => p.key === m[`${role}Key`]);
      const parentRow = rows.find(r => fieldValue(r.fields, 'physicaltag') === parent.tag);
      assert.ok(parentRow, 'Expected parent missing');
      assert.equal(fieldValue(fields, col), parentRow.id, `${m.tag}: ${role} link differs`);
    }
    mapping.push({ sourceRow: m.sourceRow, sourceTag: m.sourceTag, targetTag: m.tag, targetId: r.id,
      sourceCageTag: m.sourceCageTag, targetCageId: fieldValue(fields, 'cageid'),
      sourceState: m.state, targetState: fieldValue(fields, 'mousestate') });
  }
  return mapping;
}
async function verify(page, profile, options = {}) {
  const mice = await findRecords(page.context(), 'mouse', '', { allowPages: true, details: true });
  const mapping = verifyAnimalRows(profile, mice, options);
  const cages = await findRecords(page.context(), 'cage', '', { allowPages: true, details: true });
  assert.equal(cages.length, profile.cages.length, 'Total cage count differs');
  for (const cage of profile.cages) {
    const ids = new Set(mapping.filter(m => m.sourceCageTag === cage.sourceTag).map(m => m.targetCageId));
    assert.equal(ids.size, 1, `Cage ${cage.tag} members were split`);
    assert.equal(mapping.filter(m => m.sourceCageTag === cage.sourceTag).length, cage.members.length);
    assert.ok(cages.some(c => ids.has(c.id)), `Missing cage ${cage.tag}`);
  }
  const matings = await matingRows(page);
  assert.equal(matings.length, profile.matings.length, 'Total mating count differs');
  for (const mating of profile.matings) {
    const ids = expectedIds(profile, mice, mating);
    const matches = matings.filter(r => fieldValue(r.fields, 'maleId') === ids.male);
    assert.equal(matches.length, 1, 'Mating missing or duplicated');
    const f = matches[0].fields;
    assert.equal(fieldValue(f, 'matingtag'), mating.tag, 'Mating source reference tag differs');
    assert.deepEqual((fieldValue(f, 'femaleIds').match(/\d+/g) || []).sort(), ids.females.sort(), 'Mating dams differ');
    assert.equal(dateISO(fieldValue(f, 'setupdate')), mating.setupDate);
    assert.equal(fieldValue(f, 'mouseline'), mating.litterStrain);
    assert.equal(fieldValue(f, 'state'), 'Active');
    assert.equal(fieldValue(f, 'comment'), historyComment(mating).replace(/\s+/g, ' ').trim());
  }
  return { verifiedAt: new Date().toISOString(), planHash: profile.planHash,
    counts: { mice: mice.length, cages: cages.length, matings: matings.length },
    complete: mapping.every(m => m.sourceState === m.targetState),
    stateDifferences: mapping.filter(m => m.sourceState !== m.targetState).map(m => ({ tag: m.targetTag, expected: m.sourceState, actual: m.targetState })),
    mapping, mice, cages, matings, unresolvedSourceParents: profile.fidelity.unresolvedParentTags };
}
async function main() {
  const profile = JSON.parse(fs.readFileSync(process.argv[2] || 'softmouse-profile-R261014A.json', 'utf8'));
  const cdpAt = process.argv.indexOf('--cdp');
  const browser = await chromium.connectOverCDP(cdpAt < 0 ? 'http://127.0.0.1:9222' : process.argv[cdpAt + 1]);
  const pages = browser.contexts().flatMap(c => c.pages()).filter(p => p.url().includes('softmouse.net'));
  assert.equal(pages.length, 1); pages[0].setDefaultTimeout(20000);
  const audit = process.argv.includes('--audit-weanling-stock');
  const result = await verify(pages[0], profile, { auditWeanlingStock: audit });
  const suffix = result.complete ? 'verification' : 'audit-incomplete';
  fs.writeFileSync(`softmouse-profile-${profile.namespace}-${suffix}.json`, JSON.stringify(result, null, 2));
  await pages[0].screenshot({ path: `softmouse-profile-${profile.namespace}-${result.complete ? 'verified' : 'audit-incomplete'}.png`, fullPage: true });
  console.log(result.complete ? 'Saved profile verified' : 'Saved profile audited with unresolved Weanling states', result.counts, result.stateDifferences);
  assert.ok(result.complete, 'Complete recreation is blocked by the recorded state differences; all other profile checks passed.');
}
module.exports = { verifyAnimalRows, verify, main };
if (require.main === module) main().then(() => process.exit(0)).catch(e => { console.error(e.stack); process.exit(1); });
