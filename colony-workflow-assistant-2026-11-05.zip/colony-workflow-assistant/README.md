# Colony workflow assistant

A local Windows application for three colony-record tasks in a visible SoftMouse browser: adding new cage cards/mice, recording minimal litters, and weaning whole litters into assigned cages. Uses normal forms, not bulk import. This is an independent lab-developed candidate for a supervised pilot, not a vendor-endorsed product.

## Download the package

If viewing the GitHub repository, download **colony-workflow-assistant-2026-11-05.zip** from its file list, then extract it. The application source, examples, tests, and operating guide are inside the archive. Extracted package users can skip this step.

## Install and start

Use Node.js 22 or newer on Windows. From the extracted colony-workflow-assistant folder:

```powershell
npm.cmd ci
npx.cmd playwright install chromium
npm.cmd start
```

Or use Start Colony Workflow.cmd after installing dependencies. Open http://127.0.0.1:4317, open the app-owned SoftMouse window, sign in, refresh profiles, and select the exact destination. The app's browser is shared by its script and inspection tools. Do not edit that browser during a run.

## Inputs and execution

Read [the operating guide](app/README.md), [short text instructions](app/SHORT-INSTRUCTIONS.md), and [mouse identity rules](app/MOUSE-IDS.md). The examples in app/examples use placeholders. Replace all example values with approved data and existing catalog choices; they are not ready-to-run lab instructions. JSON dates use YYYY-MM-DD, and identifiers are strings. Births create zero individual pups. Weaning requires source cage plus litter DOB, actual date, sex counts, and each pup's destination cage and rack.

Standard mode prepares four official Excel exports and a plan for review before saving. Fast mode is explicit opt-in and skips manual review while retaining validation, exports, baseline checks, and post-save verification. No blind save retries or automatic rollback. An uncertain save stops for reconciliation. Physical tag punctuation is preserved; the app assigns a separate permanent i/I/| ID suffix.

## Existing installations and data

This is a source-only distribution. It does NOT include credentials, signed-in browser state, colony exports, real operation inputs, history, screenshots, or the live mouse-ID registry. Runtime data is created locally under lab-data/. Do not run a fresh independent registry against a colony already managed by another installation. Migrate the current registry and its initialized marker plus operation evidence through an approved secure procedure; never reset IDs. GitHub is not the backup location for lab-data.

## Checks

```powershell
npm.cmd test
```

Tests use synthetic fixtures, isolated temporary state, local mock servers, and headless browsers. They do not require signing into SoftMouse. Historical reconstruction tests that depend on real exports are excluded from this distribution. See VALIDATION.md for this package's result and limits.

## Scope and release limits

Five animals per destination cage; same-sex stock/weaning groups; exact matching of profiles and catalog labels; whole-cohort weaning. General existing-animal movement, breeder selection from existing stock, genotype corrections, and animal-end workflows are outside the supported UI. Confirm account edition and permissions: requested protocols stop if protocol assignment is disabled. Full licensed and multi-profile acceptance, IT review, and vendor policy confirmation remain necessary.

Legacy helper modules at the repository root are required libraries. Their standalone command entry points are disabled in this package so historical default batches cannot be launched. Use npm start.

## Package contents and privacy

PACKAGE-MANIFEST.json lists included files and SHA-256 hashes. Source helpers and app logic are preserved except that historical standalone entry points are blocked and account-specific/example labels are replaced with placeholders. Actual local run records and site-specific demonstration JSONs are intentionally absent. No rights to vendor software or branding are claimed, and no open-source license is granted by this private package.
