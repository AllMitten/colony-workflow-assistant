// Packaged helper: launch the reviewed app with npm start; legacy standalone runs are disabled.
if (require.main === module) throw new Error('Launch this package with npm start. Standalone legacy scripts are disabled.');

/* One male, one new STOCK cage. Based on the supplied SoftMouse recording.
 * Preview: node softmouse-one-male.cjs
 * Create:  node softmouse-one-male.cjs --save
 * Uses the existing `playwright` package, not @playwright/test.
 * Login is manual. Optional fields retain the fresh form's defaults.
 */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline/promises');
const DATA = Object.freeze({tag:'EXAMPLE-M1',cageTag:'EXAMPLE-C1',dob:'2026-08-01',enterCageDate:'2026-11-05',strain:'Example Strain',strainId:'0',protocolId:'0',owner:'Practice Profile'});
const JOURNAL = path.join(__dirname, 'softmouse-one-male-run.json');
const text = x => String(x ?? '').replace(/\s+/g, ' ').trim();
const norm = x => text(x).replace(/[^a-z0-9]/gi, '').toLowerCase();
const displayDate = iso => { const [y,m,d] = iso.split('-'); return `${m}-${d}-${y}`; };
function dateISO(value) {
  const v = text(value);
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  const m = /^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/.exec(v);
  return m ? `${m[3]}-${m[1].padStart(2,'0')}-${m[2].padStart(2,'0')}` : null;
}
function previewMatches(cells, protocolName) {
  return cells.includes(DATA.tag) && cells.includes('M')
    && cells.some(c => dateISO(c) === DATA.dob)
    && cells.some(c => norm(c) === norm(DATA.strain)) && cells.includes(protocolName);
}
function summaryMatches(cells) {
  const animal = new RegExp(`^${DATA.tag}\\s*\\[\\s*M\\s*,\\s*${displayDate(DATA.dob)}\\s*,`);
  return cells.includes('NEW') && cells.includes(DATA.cageTag) && cells.includes('1')
    && cells.includes('Stock') && cells.some(c => norm(c) === norm(DATA.strain))
    && cells.some(c => animal.test(c));
}
async function cells(rows) {
  return rows.evaluateAll(elements => elements.map(row => Array.from(row.cells || [])
    .map(cell => cell.textContent.replace(/\s+/g,' ').trim())));
}
async function waitUntil(label, read, matches, checkError, timeout = 30000) {
  const until = Date.now() + timeout;
  let last;
  do {
    checkError();
    last = await read();
    if (matches(last)) return last;
    await new Promise(resolve => setTimeout(resolve, 250));
  } while (Date.now() < until);
  throw new Error(`${label}. Observed: ${JSON.stringify(last)}`);
}
async function selectedLabel(select) {
  return select.evaluate(e => e.options[e.selectedIndex]?.textContent.trim() || '');
}

async function clickFill(field, value) {
  await field.click();
  await field.fill(value);
  assert.equal(await field.inputValue(), value);
}

// Search through the UI, including ended records. Never infer absence from one
// unfiltered grid page. Fail closed if a filtered result spans multiple pages.
async function findRecords(context, kind, identifier, options = {}) {
  const lookup = context.pages().find(p => p.url().includes('/smdb/'));
  assert.ok(lookup, 'The manually logged-in SoftMouse tab is required.');
  lookup.setDefaultTimeout(20000);
  try {
    const animal = kind === 'mouse';
    await lookup.locator(`a.textdecoration[href="smdb/${kind}/list.do"]`).click();
    await lookup.waitForURL(url => url.pathname === `/smdb/${kind}/list.do`);
    const grid = animal ? '#mouseTable' : '#cage_table';
    // Empty accounts render an empty-state message instead of a jqGrid. The
    // filter and its validated response still provide a complete absence check.
    await lookup.locator('#editOpenCloseImage').waitFor({ state: 'visible' });
    // The initial grid request can still be applying saved filter defaults.
    // Finish that initialization before editing this search's parameters.
    await lookup.waitForLoadState('networkidle');
    await lookup.locator('#editOpenCloseImage').waitFor();
    if (!await lookup.locator('#filterClear').isVisible())
      await lookup.locator('#editOpenCloseImage').click();
    await lookup.locator('#filterClear').click();
    if (animal) {
      await lookup.locator('#filterMode + button').click();
      await lookup.locator('.ui-multiselect-menu:visible label').filter({ hasText: /^All$/ }).click();
      assert.equal(await lookup.locator('#filterMode').inputValue(), 'all');
      assert.ok(await lookup.locator('#mouseStates').evaluate(e =>
        Array.from(e.options).filter(o => o.value !== 'All').every(o => o.selected)),
        'Duplicate search must include all animal states.');
    } else {
      await lookup.locator('#cageStates + button').click();
      const all = lookup.locator('.ui-multiselect-menu:visible label').filter({ hasText: /^All$/ });
      if (!await all.locator('input').isChecked()) await all.click();
      assert.ok(await lookup.locator('#cageStates').evaluate(e =>
        Array.from(e.options).filter(o => o.value !== 'All').every(o => o.selected)),
        'Duplicate search must include all cage states.');
    }
    const fieldName = animal ? 'physicalTag' : 'cageTag';
    await clickFill(lookup.locator(`input[name="${fieldName}"]`), identifier);
    const responsePromise = lookup.waitForResponse(r => {
      const body = r.request().postData() || '';
      const url = new URL(r.url());
      const parameters = r.request().method() === 'GET' ? url.searchParams : new URLSearchParams(body);
      return url.pathname === (animal ? '/mouse/list.json' : '/cage/list.jqgrid')
        && (parameters.get(fieldName) ?? '') === identifier;
    });
    await lookup.locator('#filterApply').click();
    const response = await responsePromise;
    assert.ok(response.ok(), 'Record search failed.');
    const result = await response.json();
    assert.ok(Array.isArray(result.list), 'Unexpected search response.');
    assert.ok(options.allowPages || Number(result.total || 0) <= 1, 'Search spans multiple pages; stopping.');
    const rows = lookup.locator(`${grid} tr.jqgrow`);
    await waitUntil('Filtered UI did not finish loading', () => rows.count(),
      n => n === result.list.length, () => {});
    const read = () => rows.evaluateAll(es => {
      const text = node => node.nodeName === 'BR' ? ' ' : node.nodeType === 3 ? node.textContent : Array.from(node.childNodes).map(text).join('');
      return es.map(row => ({ id: row.id,
        cells: Array.from(row.cells).map(c => text(c).replace(/\s+/g, ' ').trim()),
        fields: Object.fromEntries(Array.from(row.cells).map(c => [c.getAttribute('aria-describedby') || '', text(c).replace(/\s+/g, ' ').trim()])) })); });
    const collected = await read();
    for (let pageNumber = 2; pageNumber <= Number(result.total || 0); pageNumber++) {
      const nextResponse = lookup.waitForResponse(r => {
        const url = new URL(r.url());
        const p = r.request().method() === 'GET' ? url.searchParams : new URLSearchParams(r.request().postData() || '');
        return url.pathname === (animal ? '/mouse/list.json' : '/cage/list.jqgrid')
          && (p.get(fieldName) ?? '') === identifier && Number(p.get('page')) === pageNumber;
      });
      await lookup.locator(`${grid === '#mouseTable' ? '#next_t_mouseTable_toppager' : '#next_t_cage_table_toppager'}`).click();
      const response = await nextResponse;
      assert.ok(response.ok(), 'Record search pagination failed.');
      const next = await response.json();
      assert.equal(Number(next.records), Number(result.records), 'Record count changed during pagination.');
      assert.equal(Number(next.page), pageNumber);
      await waitUntil('Paged UI did not finish loading', read, observed => observed.length === next.list.length
        && observed.every(r => !collected.some(prior => prior.id === r.id)), () => {});
      collected.push(...await read());
    }
    assert.equal(collected.length, Number(result.records), 'Search does not contain all matching records.');
    assert.equal(new Set(collected.map(r => r.id)).size, collected.length, 'Duplicate page records.');
    const matches = options.exact ? collected.filter(row => Object.entries(row.fields).some(([key, value]) =>
      key.toLowerCase().endsWith(`_${fieldName.toLowerCase()}`) && value === identifier)) : collected;
    const values = options.details ? matches : matches.map(r => r.cells);
    console.log(`${kind} lookup ${identifier}: ${values.length} matching record(s).`);
    return values;
  } finally { /* Keep the shared, authenticated tab open for inspection. */ }
}

async function inspectRecords(context) {
  // Sequential: the application saves filter preferences in this session.
  return { mice: await findRecords(context, 'mouse', DATA.tag),
    cages: await findRecords(context, 'cage', DATA.cageTag) };
}

async function verifySaved(context, protocolName) {
  const records = await inspectRecords(context);
  assert.equal(records.mice.length, 1, 'Expected exactly one saved mouse.');
  assert.ok(previewMatches(records.mice[0], protocolName), 'Saved mouse fields differ.');
  assert.ok(records.mice[0].includes(DATA.cageTag) && records.mice[0].includes('Stock'),
    'Saved mouse is not in the expected stock cage.');
  assert.equal(records.cages.length, 1, 'Expected exactly one saved cage.');
  const cage = records.cages[0];
  assert.ok(cage.includes(DATA.cageTag) && cage.includes('1') && cage.includes('Stock')
    && cage.some(c => norm(c) === norm(DATA.strain))
    && cage.some(c => c.includes(`${DATA.tag} [M, ${displayDate(DATA.dob)},`)),
    'Saved cage must contain exactly the expected male.');
  assert.ok(cage.some(c => dateISO(c) === DATA.enterCageDate), 'Saved cage setup date differs.');
  return records;
}

// Your video shows TWO months in one calendar. Match the recorded FIRST month/year
// dropdowns and FIRST day link, then verify the full selected date in the input.
async function setCalendarDate(page, input, iso, open) {
  const [year, month, day] = iso.split('-').map(Number);
  await open();
  const picker = page.locator('.ui-datepicker:visible');
  await picker.waitFor({ state: 'visible' });
  assert.equal(await picker.count(), 1, 'Expected one open calendar container.');
  const monthSelect = picker.locator('select.ui-datepicker-month').first();
  const yearSelect = picker.locator('select.ui-datepicker-year').first();
  await monthSelect.click();
  await monthSelect.selectOption(String(month - 1));
  await yearSelect.click();
  await yearSelect.selectOption(String(year));
  assert.equal(await monthSelect.inputValue(), String(month - 1));
  assert.equal(await yearSelect.inputValue(), String(year));
  // Adjacent-month days are also clickable: April's grid can start with a
  // March 30 link. Exclude those cells before selecting the first displayed
  // current-month day, retaining the month/year and final input assertions.
  const links = picker.locator('td:not(.ui-datepicker-other-month)').getByRole('link', { name: String(day), exact: true });
  await links.first().waitFor({ state: 'visible' });
  await links.first().click();
  assert.equal(dateISO(await input.inputValue()), iso, 'Calendar selected an unexpected date.');
}

async function main() {
  const { chromium } = require('playwright');
  const save = process.argv.includes('--save');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const ask = async message => (await rl.question(message)).trim();
  let browser, page, blocked = '', attempted = false, journalLock;
  const checkError = () => { if (blocked) throw new Error(blocked); };
  const writeStage = status => {
    fs.ftruncateSync(journalLock, 0);
    fs.writeSync(journalLock, JSON.stringify({ ...DATA, status, updatedAt: new Date().toISOString() }, null, 2), 0, 'utf8');
    fs.fsyncSync(journalLock);
  };
  try {
    if (fs.existsSync(JOURNAL)) throw new Error('A previous save attempt is recorded in softmouse-one-male-run.json. Inspect SoftMouse before another creation; do not blindly repeat it.');
    console.log(save ? '\nSAVE MODE' : '\nPREVIEW MODE - no mouse/cage records will be saved.');
    console.table({ mouse: { physicalTag: DATA.tag, sex: 'M', DOB: displayDate(DATA.dob),
      strain: DATA.strain, cage: DATA.cageTag, enterCageDate: displayDate(DATA.enterCageDate) } });
    browser = await chromium.launch({ headless: false, slowMo: 120 });
    page = await browser.newPage({ viewport: null });
    page.setDefaultTimeout(30000);
    page.on('dialog', dialog => {
      (async () => {
        const message = dialog.message();
        console.log(`\nSoftMouse ${dialog.type()}: ${message}`);
        if (dialog.type() === 'confirm' || dialog.type() === 'prompt'
          || /already.*(?:use|exist)|duplicate|\berror\b|\binvalid\b|\brequired\b|\bcannot\b/i.test(message)) {
          blocked = `Stopped at SoftMouse dialog: ${message}. No forced navigation or retries.`;
          await dialog.dismiss();
        } else await dialog.accept(); // Informational alert only.
      })().catch(error => { blocked = error.message; });
    });
    await page.goto('https://www.softmouse.net/HomePage.do');
    console.log('\nLog into your PRACTICE account in the browser. Do not manually add a mouse.');
    console.log(`Before saving, check that mouse ${DATA.tag} and cage ${DATA.cageTag} are unused.`);
    await ask('When logged in, press Enter here; the script will open New Animals itself: ');
    assert.ok(['softmouse.net','www.softmouse.net'].includes(new URL(page.url()).hostname));
    const animals = page.getByRole('link', { name: 'Animals', exact: true });
    if (!await animals.isVisible()) {
      await page.getByRole('link', { name: DATA.owner, exact: true }).click();
    }
    await animals.click();
    await page.getByRole('link', { name: 'New Animals', exact: true }).click();
    await page.locator('#sizeMale').waitFor({ state: 'visible' });
    const selectedOwners = await page.locator('select:visible').evaluateAll(selects =>
      selects.map(e => e.options[e.selectedIndex]?.textContent.trim() || ''));
    assert.ok(selectedOwners.some(o => o.includes(DATA.owner)), 'Expected Practice Profile as the selected owner.');
    const preview = page.locator('#batchPreviewTable tr.jqgrow');
    assert.equal(await preview.count(), 0, 'New Animals must start with an empty preview.');
    await page.locator('#sizeMale').fill('1');
    await page.locator('#sizeFemale').fill('0');
    assert.equal(await page.locator('#sizeMale').inputValue(), '1');
    assert.equal(await page.locator('#sizeFemale').inputValue(), '0');
    // Refuse an unexpected nonzero Unknown count if that field is present.
    const unknown = page.getByLabel(/#?\s*Unknown:?/i);
    if (await unknown.count() === 1) {
      await unknown.fill('0');
      assert.equal(await unknown.inputValue(), '0');
    }
    await page.locator('#mouselineId').selectOption(DATA.strainId);
    assert.equal(norm(await selectedLabel(page.locator('#mouselineId'))), norm(DATA.strain),
      'The recorded strain ID points to a different strain in this account.');
    await setCalendarDate(page, page.locator('#birthDatePicker'), DATA.dob,
      () => page.locator('#birthDatePicker').click());
    const tag = page.getByRole('textbox', { name: 'Input the part of the tag', exact: true });
    await tag.fill(DATA.tag);
    await page.locator('#protocolId').click();
    assert.equal(await tag.inputValue(), DATA.tag);
    await page.locator('#protocolId').selectOption(DATA.protocolId);
    const protocolName = await selectedLabel(page.locator('#protocolId'));
    assert.ok(protocolName, 'Recorded protocol is unavailable.');
    console.log(`Protocol: ${protocolName}. Optional fields retain the fresh form defaults.`);
    await page.getByRole('button', { name: 'Add', exact: true }).click();
    await waitUntil('Expected exactly one correct male preview row', () => cells(preview),
      rows => rows.length === 1 && previewMatches(rows[0], protocolName), checkError);
    console.log('\nPREVIEW PASSED: exactly one male, correct tag, DOB, strain and protocol.');
    if (!save) {
      console.log('No mouse or cage saved. Do not click Create manually in this preview.');
      await ask('Inspect the preview, then press Enter to close: ');
      return;
    }
    assert.equal(await ask(`Type CREATE to create mouse ${DATA.tag} and cage ${DATA.cageTag}: `), 'CREATE', 'Save canceled.');
    // Recheck after the user's review; never rely on a stale preview.
    const reviewed = await cells(preview);
    assert.ok(reviewed.length === 1 && previewMatches(reviewed[0], protocolName), 'Preview changed.');
    const previewCheckbox = preview.locator('input[type="checkbox"]');
    assert.equal(await previewCheckbox.count(), 1, 'Expected one preview selection checkbox.');
    await previewCheckbox.check();
    // Exclusive journal creation also prevents two copies of this script saving concurrently.
    journalLock = fs.openSync(JOURNAL, 'wx');
    attempted = true;
    writeStage('animal_creation_attempted');
    await page.getByRole('button', { name: /^Create Animals and Move them(?: into Cages)?$/ }).click();
    checkError();
    // Unlike the raw recording, do not force goto after a canceled creation dialog.
    await page.waitForURL(url => url.pathname === '/smdb/cage/alloc.do' && url.searchParams.get('dispatch') === 'setup');
    checkError();
    writeStage('animal_created_cage_pending');
    const allocation = page.locator('#cageAssignmentTable tr.jqgrow');
    await waitUntil('Expected only the new unassigned male on Move Animals', () => cells(allocation),
      rows => rows.length === 1 && rows[0].includes(DATA.tag)
        && rows[0].some(c => /Adult:\s*1M\b/.test(c))
        && rows[0].some(c => norm(c) === norm(DATA.strain))
        && rows[0].some(c => /not yet assigned/i.test(c)), checkError);
    const row = allocation;
    const rowCheckbox = row.locator('input[type="checkbox"]');
    assert.equal(await rowCheckbox.count(), 1);
    await rowCheckbox.check();
    const cage = row.locator('input[name="cageTag"]');
    assert.equal(await cage.count(), 1);
    await cage.fill(DATA.cageTag);
    assert.equal(await cage.inputValue(), DATA.cageTag);
    // The video shows one date-valued input in the cage row: Enter Cage.
    const inputs = row.locator('input');
    const values = await inputs.evaluateAll(elements => elements.map(e => e.value));
    const dateIndexes = values.map((v,i) => dateISO(v) ? i : -1).filter(i => i >= 0);
    assert.equal(dateIndexes.length, 1, 'Could not uniquely identify Enter Cage date.');
    const enterDate = inputs.nth(dateIndexes[0]);
    if (dateISO(await enterDate.inputValue()) !== DATA.enterCageDate) {
      await setCalendarDate(page, enterDate, DATA.enterCageDate,
        () => row.getByRole('img', { name: '...', exact: true }).click());
    }
    assert.equal(dateISO(await enterDate.inputValue()), DATA.enterCageDate);
    const cageProtocols = await row.locator('select').evaluateAll(selects =>
      selects.map(e => e.options[e.selectedIndex]?.textContent.trim() || ''));
    assert.ok(cageProtocols.includes(protocolName), 'Cage protocol differs from mouse protocol.');
    writeStage('cage_save_attempted');
    await page.getByRole('button', { name: 'Create / Update Cages', exact: true }).click();
    checkError();
    await page.waitForURL(url => url.pathname === '/smdb/cage/alloc.do' && url.searchParams.get('dispatch') === 'result');
    await waitUntil('Move Summary must confirm one NEW stock cage with the correct male',
      () => cells(page.locator('tr')), rows => rows.filter(summaryMatches).length === 1, checkError);
    writeStage('saved_and_move_summary_verified');
    console.log(`\nSAVED AND VERIFIED in Move Summary: NEW stock cage ${DATA.cageTag}, one male ${DATA.tag}, DOB ${displayDate(DATA.dob)}.`);
    await page.getByText('Done', { exact: true }).click();
    await ask('Finished. Press Enter to close the browser: ');
  } catch (error) {
    process.exitCode = 1;
    console.error(`\nSTOPPED: ${blocked || error.message}`);
    if (attempted) console.error('A save was attempted. Inspect SoftMouse before rerunning; partial records may exist. The journal blocks a repeat.');
    if (page && !page.isClosed()) {
      console.error(`Current page: ${page.url()}`);
      console.log('Leave the browser open if you need a screenshot.');
      try { await ask('Press Enter after inspection to close: '); } catch {}
    }
  } finally {
    if (journalLock !== undefined) fs.closeSync(journalLock);
    if (browser) await browser.close();
    rl.close();
  }
}
module.exports = { DATA, dateISO, displayDate, previewMatches, summaryMatches, findRecords, inspectRecords, verifySaved,
  setCalendarDate, clickFill, selectedLabel, waitUntil };
if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
