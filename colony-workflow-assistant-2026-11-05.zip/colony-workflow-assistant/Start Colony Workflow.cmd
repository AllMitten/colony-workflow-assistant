@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. See app\README.md for installation instructions.
  pause
  exit /b 1
)
node app\launch.cjs
if errorlevel 1 pause
