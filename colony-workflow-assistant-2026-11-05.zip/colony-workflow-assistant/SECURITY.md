# Runtime data and access

The local app binds to 127.0.0.1 and controls its own visible browser. Keep the workstation protected. Signed-in browser state, backups, operation inputs/history, screenshots, and the permanent identity registry are local runtime data. Do not commit or upload lab-data or credentials. The four list exports are not a full database backup or automatic rollback. A history hash chain detects accidental changes, but is not a signed compliance archive. Do not reset or independently duplicate the ID registry for the same colony.
