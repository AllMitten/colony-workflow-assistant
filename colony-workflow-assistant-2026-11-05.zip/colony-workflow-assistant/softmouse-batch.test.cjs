'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const input = require('./softmouse-practice-four.json');
const { buildPlan, normalizeAllele, verifyInventory } = require('./softmouse-batch.cjs');

test('punctuation IDs survive import unchanged and source cage cards do not become practice tags', () => {
  const plan = buildPlan(input, 'TESTA');
  assert.deepEqual(plan.mice.map(m => m.tag.slice('TESTA-'.length)), input.mice.map(m => m.physicalTag));
  assert.deepEqual(plan.cages.map(c => c.mice.map(m => m.sex)), [['M', 'M'], ['M', 'F']]);
  assert.ok(plan.cages.every(c => !c.tag.startsWith('CC')));
});
test('heterozygous is explicit +/-; unspecified remains unset', () => {
  for (const allele of ['heterozygous', 'HET', '+/-']) assert.equal(normalizeAllele(allele), '+/-');
  for (const allele of ['Not specified', '', null]) assert.equal(normalizeAllele(allele), '');
  assert.throws(() => normalizeAllele('probably heterozygous'), /Unknown allele/);
});
test('missing DOB, impossible dates, duplicate IDs, and invalid breeding groups stop before browser use', () => {
  const change = mutate => { const data = structuredClone(input); mutate(data); return data; };
  assert.throws(() => buildPlan(change(d => d.mice[0].dob = ''), 'TESTA'), /DOB/);
  assert.throws(() => buildPlan(change(d => d.mice[0].dob = '2026-02-30'), 'TESTA'), /invalid/);
  assert.throws(() => buildPlan(change(d => d.mice[1].physicalTag = d.mice[0].physicalTag), 'TESTA'), /Duplicate/);
  assert.throws(() => buildPlan(change(d => d.mice[3].sex = 'M'), 'TESTA'), /exactly one male/);
});
test('duplicate or missing saved mouse records prevent a success result', () => {
  const plan = buildPlan(input, 'TESTA');
  const records = { mice: Object.fromEntries(plan.mice.map(m => [m.tag, []])), cages: {} };
  assert.throws(() => verifyInventory(plan, records), /exactly one saved mouse/);
  records.mice[plan.mice[0].tag] = [[], []];
  assert.throws(() => verifyInventory(plan, records), /exactly one saved mouse/);
});
